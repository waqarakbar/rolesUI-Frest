<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">


            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                        </div>
                    </div>
                </div>

                <div class="card-body">


                    <div class="row">


                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <table class="table table-striped" >

                                    <thead>
                                    <tr>
                                        <th class="">S. No</th>
                                        <th>Department Type</th>
                                        <th>Closure Checklists</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->title); ?></td>
                                            <td>
                                                <?php if($item->closureSteps->count()<=0): ?>
                                                    <span class="badge badge-warning">Not configured</span>
                                                <?php else: ?>
                                                    <?php echo e($item->closureSteps->count()); ?>

                                                <?php endif; ?>
                                            </td>

                                            <td style="width: 150px">

                                                <a href="<?php echo e(route('ir.closure-configs.show', \Illuminate\Support\Facades\Crypt::encrypt($item->id))); ?>" class="btn btn-sm btn-success">
                                                    <i class="icon-cogs mr-1"></i> Config
                                                </a>




                                            </td>


                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>



                </div>


            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/closure_configs/index.blade.php ENDPATH**/ ?>