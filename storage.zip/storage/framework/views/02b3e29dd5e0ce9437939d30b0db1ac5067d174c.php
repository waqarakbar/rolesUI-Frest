<div class="row">
    <div class="col-12">


        <!-- Traffic sources -->
        <div class="card">
            <div class="card-header header-elements-inline">
                <h5 class="card-title"><?php if(isset($od_request)): ?> <strong><u><?php echo e($od_request->form->title); ?></u></strong> for <?php endif; ?> <em>Person of Interest</em></h5>
                <div class="header-elements">
                    <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                    </div>
                </div>
            </div>

            <div class="card-body">

                <div class="row">

                    <div class="col-md-2">
                        <?php if($entity->poiAttachments->count() > 0): ?>
                            <img src="<?php echo e(asset('uploads/pois/'.$entity->poiAttachments[0]->file)); ?>" alt="" style="width: 98%; border: 1px solid #ccc; padding: 2px">
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/no-picture.jpeg')); ?>" alt="" style="width: 98%; border: 1px solid #ccc; padding: 2px">
                        <?php endif; ?>
                    </div>

                    <div class="col-md-8">

                        <h5><strong><u><?php echo e($entity->name); ?></u></strong> &nbsp;&nbsp;<small>D/S/O</small>&nbsp;&nbsp; <strong><u><?php echo e($entity->father_name); ?></u></strong></h5>

                        <h6>
                            <strong>CNIC: </strong> <?php echo e($entity->cnic); ?> |
                            <strong>Passport: </strong> <?php echo e($entity->passport ?? "n/a"); ?> |
                            <strong>Other Registration: </strong> <?php echo e($entity->other_registration_no ?? "n/a"); ?>

                        </h6>

                        <h6>
                            <strong>Address: </strong> <?php echo e($entity->address); ?> <br>
                            <strong>District: </strong> <?php echo e($entity->district->title ?? "n/a"); ?> (<?php echo e($entity->province->title ?? "n/a"); ?>)
                            <br>
                            <strong>Contact#: </strong> <?php echo e($entity->contact_number); ?>

                        </h6>

                        <h6>
                            <strong>Affiliations:</strong> Affiliated to <?php echo e($entity->poiAffiliations->count()); ?> organization
                            <?php if($entity->poiAffiliations->count() > 0): ?>
                                <ol type="i">
                                    <?php $__currentLoopData = $entity->poiAffiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $af): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong><?php echo e($af->organization->title ?? ""); ?></strong> as <strong><?php echo e($af->designation->title ?? ""); ?></strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            <?php endif; ?>
                        </h6>

                    </div>

                </div>


               

            </div>

        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $("#poi_search_pdb").click(function(e){
            // $("#response_data").html("<div class='text-center pt-2 pb-2 alpha-brown mt-2'><i class='fa fa-2x fa-spinner'></i></div>")
            e.preventDefault();
            /*$.ajax({
                type: 'post',
                url: '<?php echo e(route('ir.search-poi-in-police-db')); ?>',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    person_id: '<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($entity->id)); ?>',
                    incident_id: '<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>'
                },
                success: function(res){
                    console.log(res);
                    // $("#response_data").html(res)
                }
            })*/
        })
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_requests/_partials/poi_entity.blade.php ENDPATH**/ ?>