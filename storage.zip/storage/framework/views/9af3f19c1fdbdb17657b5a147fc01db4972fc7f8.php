<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    
    <style>
        .card {
            border: unset;
            box-shadow: unset;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Evidences / Attachments -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => ['ir.form.step5-save', $formID],
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>


                            <input type="hidden" value="<?php echo e($formID); ?>" name="incident_id">

                            <?php
                                $place = null;
                                if($item->places->count() > 0){
                                    $place = $item->places[0];
                                }
                            ?>


                            <h6>
                                <span class="step-title">
                                    General Info
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>



                            <h6>
                                <span class="step-title">
                                    Complainants & evidences
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                            </fieldset>





                            <h6>
                                <span class="step-title">Person of Interest</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>





                            <h6>
                                <span class="step-title">Place of Interest</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step4', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>





                            <h6>
                                <span class="step-title">Mobility & Routes</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step5', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">



                                <?php if( $item->mobilities->count() == 0 ): ?>

                                    <div class="alert alert-warning">
                                        <span class="font-weight-semibold">Warning!</span> No mobilities have been added yet. <strong><a href="#" data-toggle="modal" data-target="#addMobility"> Click here</a></strong> to add mobility
                                    </div>

                                <?php else: ?>



                                    <div class="row">
                                        <div class="col-12">

                                            <button type="button" class="btn btn-warning btn-sm float-right" data-toggle="modal" data-target="#addMobility"> <i class="fa fa-plus-circle mr-1"></i> Add Mobility</button>

                                            <div class="table-responsive">
                                                <table class="table table-hover table-sm">

                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Type</th>
                                                        <th style="width: 50%">Mobility Details</th>
                                                        <th>Route Details</th>
                                                        
                                                        <th style="width: 130px"></th>
                                                    </tr>
                                                    </thead>

                                                    <tbody>
                                                    <?php $__currentLoopData = $item->mobilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><strong><?php echo e($mob->mobilityType->title ?? ""); ?></strong></td>
                                                            <td>

                                                                <?php if($mob->mobility_type_id == 1): ?>

                                                                    <span>
                                                                        <strong><?php echo e($mob->vehicleBrand->title ?? ""); ?> (<?php echo e($mob->vehicleType->title ?? ""); ?> <?php echo e($mob->vehicle_model ?? ""); ?>) | Color: <?php echo e($mob->color ?? ""); ?></strong> <br>
                                                                        <strong>Registration Status: </strong> <?php echo e($mob->vehicle_registration_status ?? ""); ?> <?php echo e($mob->vehicle_registration_no ?? ""); ?> / <strong>Chassis No.:</strong> <?php echo e($mob->vehicle_chassis_no ?? ""); ?> (Chassis Tempered: <?php echo e($mob->vehicle_chassis_tempered ?? ""); ?>)
                                                                    </span>

                                                                <?php elseif($mob->mobility_type_id == 2): ?>

                                                                    <span>
                                                                        <strong>Flight Type: </strong> <?php echo e($mob->flight_type ?? ""); ?> | <strong>Flight No.: </strong> <?php echo e($mob->flight_no ?? ""); ?> <br>
                                                                        <strong>Airport: </strong> <?php echo e($mob->airport_name ?? ""); ?> (<?php echo e($mob->flightOriginCountry->title ?? ""); ?> to <?php echo e($mob->flightDestinationCountry->title ?? ""); ?>)
                                                                    </span>

                                                                <?php elseif($mob->mobility_type_id == 3): ?>

                                                                    <span>
                                                                        <strong>Shipping Company: </strong> <?php echo e($mob->shipping_company ?? ""); ?> | <strong>Container No.:</strong> <?php echo e($mob->container_no ?? ""); ?>

                                                                    </span>

                                                                <?php elseif($mob->mobility_type_id == 4): ?>

                                                                    <span>
                                                                        <strong>Courier Company: </strong> <?php echo e($mob->courier_name ?? ""); ?> <br>
                                                                        <strong>From: </strong><?php echo e($mob->courier_origin_details ?? ""); ?> <br>
                                                                        <strong>To: </strong><?php echo e($mob->courier_destination_details ?? ""); ?>

                                                                    </span>

                                                                <?php elseif($mob->mobility_type_id == 5): ?>

                                                                    <span>
                                                                        <strong>Gadget Type: </strong> <?php echo e($mob->gadgettype->title ?? ""); ?> - <?php echo e($mob->gadget_manufacturer ?? ""); ?> (SR No. <?php echo e($mob->gadget_serial_no ?? ""); ?>)
                                                                    </span>

                                                                <?php endif; ?>

                                                            </td>
                                                            <td><?php echo e($mob->route_details ?? ""); ?></td>
                                                            
                                                            <td>

                                                                

                                                                <a href="<?php echo e(route('ir.incident.delete-mobility', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($mob->id)])); ?>" class="text-danger" title="Delete Mobility" onclick="return confirm('Are you sure you want to delete?')">
                                                                    <i class="icon-trash"></i>
                                                                </a>

                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>

                                                </table>
                                            </div>

                                        </div>
                                    </div>

                                <?php endif; ?>








                            </fieldset>





                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    <a href="<?php echo e(route('ir.form.step4', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Previous
                                    </a>

                                    <a href="<?php echo e(route('ir.form.step5', ['id' => $formID])); ?>" class="btn btn-info btn-sm">
                                        <i class="fa fas fa-save mr-1"></i> Save
                                    </a>


                                    <?php if($item->currentStatus->count() <= 0 or $item->currentStatus[0]->statusHistory->incident_status_id == 1): ?>
                                        <a href="<?php echo e(route('ir.incident.publish-incident', ['id' => $formID])); ?>" class="btn btn-success btn-sm">
                                            Save & Finish <i class="icon-checkbox-checked ml-1"></i>
                                        </a>

                                    <?php else: ?>
                                        <a href="<?php echo e(route('ir.incident.profile', ['id' => $formID])); ?>" class="btn btn-success btn-sm">
                                            Save & Finish <i class="icon-checkbox-checked ml-1"></i>
                                        </a>
                                    <?php endif; ?>



                                    
                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>
    <?php echo $__env->make("incidentreporting::incident-reporting.steps._partials.new_mobility_modal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <script>
        $(function (){
            $('.next-btn').trigger('click'); // first step
            $('.next-btn').trigger('click').trigger('click').trigger('click');
        });

        $(document).ready(function () {
            var CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/form5.blade.php ENDPATH**/ ?>