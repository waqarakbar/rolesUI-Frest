<?php $app_id = config('settings.app_id') ?>

<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript" src="<?php echo asset('assets/js/plugins/extensions/jquery_ui/core.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('assets/js/plugins/extensions/jquery_ui/effects.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('assets/js/plugins/extensions/jquery_ui/interactions.min.js'); ?>"></script>

    <script type="text/javascript" src="<?php echo asset('assets/js/plugins/trees/fancytree_all.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('assets/js/plugins/trees/fancytree_childcounter.js'); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function () {

            $(".tree-checkbox-hierarchical").fancytree({
                checkbox: true,
                selectMode: 3,
                select: function (event, data) {

                }
            });

            // Loop through all trees, get the selected nodes from each tree then
            // get the permission ids by removing extra text (perm-) and then
            // join them as string with , and put it in text field
            $('#permissions_assignment_form').submit(function (e) {
                // e.preventDefault()
                var allSelectedNodes = []
                $.each($(".tree-checkbox-hierarchical"), function(i,v){
                    var thisTreeSelectedNodes = $(v).fancytree('getTree').getSelectedNodes();
                    // console.table(thisTreeSelectedNodes)
                    var thisTreeSelKeys = $.map(thisTreeSelectedNodes, function (node) {
                        // return "[" + node.key + "]: '" + node.title + "'";
                        if(node.key.includes("perm-")){
                            return node.key.replace("perm-", "");
                        }
                    });
                    // console.log(thisTreeSelKeys)
                    allSelectedNodes = allSelectedNodes.concat(thisTreeSelKeys)
                })

                // console.log(allSelectedNodes);
                $("#checked_permissions").val(allSelectedNodes.join(","));
                // return false;

            });


        })
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title">User Details: <strong><u><?php echo e($item->name); ?></u></strong></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <h5><strong><?php echo e($item->username); ?> / <?php echo e($item->email); ?></strong></h5>
                            <h6>Organization: <strong><?php echo e($item->company->title ?? ""); ?></strong> (<?php echo e($item->section->title ?? ""); ?>)</h6>
                            <div>
                                <strong>Assigned Roles</strong><br>
                                <?php $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-info"><?php echo e($r->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <p><?php echo e($item->description); ?></p>



                            <div class="alert alert-info mt-3">
                                <i class="icon-warning mr-1"></i> <strong>ATTENTION!</strong>
                                <p>Please select permissions in each app that you want to assign to this user. After you select all permissions, make sure to click "Save Permissions" button at the bottom of the page.</p>
                            </div>

                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




    <?php echo Form::open(['class' => 'form-horizontal', 'id' => 'permissions_assignment_form' ,'method' => 'post', 'route' => ['settings.users-mgt.user-permissions-save', \Illuminate\Support\Facades\Crypt::encrypt($item->id)]]); ?>


    <div class="row">





        <?php
            $assigned_perms_c = collect($item->permissions);
            $assigned_perms_ids = $assigned_perms_c->pluck('id')->toArray();
            // dd($assigned_perms_ids);
        ?>
        <input type="hidden" value="" id="checked_permissions" name="checked_permissions"/>
        <input type="hidden" value="<?php echo e(implode(',', $assigned_perms_ids)); ?>" id="assigned_permissions" name="assigned_permissions">

        <?php $__currentLoopData = $trees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><strong><i class="<?php echo e($tree->icon); ?> mr-1"></i><?php echo e($tree->title); ?> App</strong></h6>
                    <div class="header-elements">

                    </div>
                </div>

                <div class="card-body" style="max-height: 400px !important; overflow-y: auto;">




                    <div class="tree-checkbox-hierarchical well">

                        <ul>

                            <?php $__currentLoopData = $tree->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li id="menu-<?php echo e($menu->id); ?>" rel="<?php echo e($menu->id); ?>" class=" folder expanded" ><?php echo e($menu->title); ?>

                                    <ul>
                                        <?php $__currentLoopData = $menu->myPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li id="perm-<?php echo e($perm->id); ?>" rel="<?php echo e($perm->id); ?>" class="<?php echo e((in_array($perm->id, $assigned_perms_ids)? 'selected': '')); ?>"><?php echo e($perm->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </div>


                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    </div>



    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">


                    <div class="col-12">
                        <a href="<?php echo e(route('settings.users-mgt.list')); ?>" class="btn btn-warning btn-sm">
                            <i class="icon-arrow-left16 mr-1"></i> Back to Users
                        </a>

                        <button type="submit" class="btn btn-success btn-sm">
                            <i class="icon-database-check mr-1"></i> Save Permissions
                        </button>
                    </div>


                </div>

            </div>
        </div>
    </div>


    <?php echo Form::close(); ?>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/users_mgt/show.blade.php ENDPATH**/ ?>