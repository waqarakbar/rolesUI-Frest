<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    
    <style>
        .card {
            border: unset;
            box-shadow: unset;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Evidences / Attachments -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => ['ir.form.step4-save', $formID],
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>


                            <input type="hidden" value="<?php echo e($formID); ?>" name="incident_id">

                            <?php
                                $place = null;
                                if($item->places->count() > 0){
                                    $place = $item->places[0];
                                }
                            ?>


                            <h6>
                                <span class="step-title">
                                    General Info
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>



                            <h6>
                                <span class="step-title">
                                    Complainants & Evidences
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                            </fieldset>





                            <h6>
                                <span class="step-title">Person of Interest</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>





                            <h6>
                                <span class="step-title">Place of Interest</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step4', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                                <div class="row">


                                    <div class="col-3">
                                        <div class="form-group">
                                            <?php echo Form::label('place_type_id', 'Select Place Type ', ['class' => 'control-label req']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('place_type_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('place_type_id', [null=>'Select a Place Type']+$place_types->toArray(), $place->place_type_id ?? null, ['class' => 'form-control form-control-select2', 'id' => 'place_type_id', 'required' => 'required']); ?>

                                        </div>
                                    </div>


                                    <div class="col-3">
                                        <div class="form-group">
                                            <?php echo Form::label('province_id', 'Select Province ', ['class' => 'control-label req']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('province_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('province_id', [null=>'Select a Province']+$provinces->toArray(), $place->province_id ?? null, ['class' => 'form-control form-control-select2', 'id' => 'province_id', 'required' => 'required']); ?>

                                        </div>
                                    </div>




                                    <div class="col-3">
                                        <div class="form-group">
                                            <?php echo Form::label('district_id', 'Select District ', ['class' => 'control-label req']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('district_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('district_id', [null=>'Select a District']+$districts->toArray(), $place->district_id ?? null, ['class' => 'form-control', 'id' => 'district_id', 'required' => 'required']); ?>

                                        </div>
                                    </div>



                                    <div class="col-3">
                                        <div class="form-group">
                                            <?php echo Form::label('tehsil_id', 'Select Tehsil ', ['class' => 'control-label']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('tehsil_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('tehsil_id', [null=>'Select a Tehsil']+$tehsils->toArray(), $place->tehsil_id ?? null, ['class' => 'form-control', 'id' => 'tehsil_id']); ?>

                                        </div>
                                    </div>

                                </div>



                                <div class="row">

                                    <div class="col-6">

                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <?php echo Form::label('vc_nc', 'UC / VC ', ['class' => 'control-lebel req']); ?>

                                                    <span
                                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('vc_nc'); ?><?php endif; ?></span>
                                                    <?php echo Form::text('vc_nc', $place->vc_nc ?? null, ['class' => 'form-control', 'id' => 'vc_nc', 'required' => 'required']); ?>

                                                </div>
                                            </div>

                                            <div class="col-6">
                                                <div class="form-group">
                                                    <?php echo Form::label('police_station_id', 'Select Police Station ', ['class' => 'control-label']); ?>


                                                    <span
                                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('police_station_id'); ?> <?php endif; ?></span>
                                                    <?php echo Form::select('police_station_id', [null=>'Select a Police Station']+$police_stations->toArray(), $place->police_station_id ?? null, ['class' => 'form-control form-control-select2', 'id' => 'police_station_id']); ?>

                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <di class="col-6">
                                                <div class="form-group">
                                                    <?php echo Form::label('latitude', 'Lat ', ['class' => 'control-label req']); ?>

                                                    <span
                                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('latitude'); ?><?php endif; ?></span>
                                                    <?php echo Form::text('latitude', $place->latitude ?? null, ['class' => 'form-control', 'id' => 'latitude', 'required' => 'required']); ?>

                                                </div>
                                            </di>

                                            <div class="col-6">
                                                <div class="form-group">
                                                    <?php echo Form::label('longitude', 'Long ', ['class' => 'control-label req']); ?>

                                                    <span
                                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('longitude'); ?><?php endif; ?></span>
                                                    <?php echo Form::text('longitude', $place->longitude ?? null, ['class' => 'form-control', 'id' => 'longitude', 'required' => 'required']); ?>

                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-6">
                                        <div class="form-group">
                                            <?php echo Form::label('address', 'Address ', ['class' => 'control-label req']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('address'); ?><?php endif; ?></span>
                                            <?php echo Form::textarea('address', $place->address ?? null, ['class' => 'form-control', 'id' => 'address', 'required' => 'required', 'rows' => 5]); ?>

                                        </div>
                                    </div>

                                </div>


                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <?php echo Form::label('description', 'Description ', ['class' => 'form-label']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                            <?php echo Form::textarea('description', $place->description ?? null, ['class' => 'form-control', 'id' => 'description', 'rows' => 4]); ?>

                                        </div>
                                    </div>
                                </div>

                            </fieldset>





                            <h6>
                                <span class="step-title">Mobility & Routes</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step5', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>





                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    <a href="<?php echo e(route('ir.form.step3', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Previous
                                    </a>

                                    <button class="btn btn-info btn-sm" name="save">
                                        <i class="fa fas fa-save mr-1"></i> Save
                                    </button>

                                    <button class="btn btn-success btn-sm" name="save_next">
                                        Save & Next <i class="icon-arrow-right16 ml-1"></i>
                                    </button>

                                    
                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <script>
        $(function (){
            $('.next-btn').trigger('click'); // first step
            $('.next-btn').trigger('click').trigger('click');
        });

        $(document).ready(function () {
            var CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
            $('#province_id').change(function () {
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('ir.form.province-districts')); ?>',
                    data: {province_id: $('#province_id').val(), _token: CSRF_TOKEN}
                }).done(function (data) {
                    var options ='<option value>Select a District</option>';
                    $.each(JSON.parse(data), function(i, v){
                        options += '<option value='+v.id+'>'+v.title+'</option>';
                    });
                    $('#district_id').html(options);
                })
            });

            $("#district_id").change(function(){
                var district_id = $(this).val();
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.tehsils-by-district-id')); ?>',
                    data: {
                        district_id: district_id,
                        _token: CSRF_TOKEN
                    }
                }).done(function(res){
                    var options = '<option>Select a Tehsil</option>';
                    $.each(res, function(i, j){
                        options += "<option value='"+i+"'>"+j+"</option>"
                    });
                    $("#tehsil_id").html(options);
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/form4.blade.php ENDPATH**/ ?>