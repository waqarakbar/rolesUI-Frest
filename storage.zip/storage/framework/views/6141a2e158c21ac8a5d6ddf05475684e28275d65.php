<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startSection('content'); ?>

    <div class="row">


        <div class="col-md-8">

            <div class="card">

                <div class="card-body">

                    <div class="row">

                        <div class="col-md-12">


                            <div class="row">

                                <div class="col-2" style="b-order: 1px solid red">
                                    <img
                                        src="data:image/png;base64,<?php echo e((new \Milon\Barcode\DNS2D())->getBarcodePNG($item->tracking_code, "QRCODE")); ?>"
                                        alt="<?php echo e($item->tracking_code); ?>" style="width: 100%;"/>
                                    <p class="text-center" style="font-size: 9px"><?php echo e($item->tracking_code); ?></p>
                                </div>


                                <div class="col-10">

                                    <h4>
                                        <strong><u>ID: <?php echo e($item->tracking_code); ?></u></strong>
                                        <span class="ml-2 badge badge-<?php echo e($item->priority->badge_class); ?>"><?php echo e($item->priority->title ?? ""); ?> Priority</span>
                                    </h4>
                                    <h6>
                                        <strong>Spectrum: </strong><?php echo e($item->spectrum->title ?? ""); ?>

                                        <em><small>(<?php echo e($item->incidentSource->title ?? ""); ?>)</small></em>
                                    </h6>

                                    <h6>
                                        <strong>Motives: </strong>
                                        <?php $__currentLoopData = $item->incidentMotives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-success bg-dark"><?php echo e($mot->title); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </h6>


                                    <table>
                                        <tr>
                                            <td style="width: 10px; vertical-align: top">
                                                <i class="icon-direction mr-2"></i>
                                            </td>
                                            <td>

                                                <?php echo e($item->places[0]->address ?? ""); ?> <br>
                                                <?php echo e($item->places[0]->province->title ?? ""); ?> /
                                                <?php echo e($item->places[0]->district->title ?? ""); ?>

                                                (<?php echo e($item->places[0]->vc_nc ?? ""); ?>)
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="width: 10px">
                                                <i class="icon-location3 mr-2"></i>
                                            </td>
                                            <td>
                                                <?php echo $item->places[0]->latitude ?? "<code>n/a</code>"; ?>

                                                / <?php echo $item->places[0]->longitude ?? "<code>n/a</code>"; ?>

                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <i class="fa fa-user-secret"></i>
                                            </td>

                                            <td>
                                                <?php echo e($item->policeStation->title ?? "Police station not specified"); ?>

                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <i class="far fa-calendar-alt"></i>
                                            </td>

                                            <td>
                                                <?php echo e(date("d/M/Y", strtotime($item->incident_date))); ?>

                                                <?php echo e(date("h:i A", strtotime($item->incident_time))); ?>

                                            </td>
                                        </tr>

                                    </table>


                                </div>

                            </div>


                        </div>

                    </div>

                </div>

                <div
                    class="col-md-12 bg-<?php echo e($item->currentStatus[0]->statusHistory->incidentStatus->bg_class); ?> text-white text-center p-2">
                    <h6 style="padding-top: 10px ">
                        <strong>
                            <?php echo e($item->currentStatus[0]->statusHistory->incidentStatus->title); ?>

                        </strong>
                        <?php if($item->currentStatus[0]->statusHistory->reopened == "yes"): ?>
                            (re-opened)
                        <?php endif; ?>
                        by
                        <strong><?php echo e($item->currentStatus[0]->statusHistory->user->name ?? ""); ?></strong>
                        (<?php echo e($item->currentStatus[0]->statusHistory->user->company->title ?? ""); ?>)
                        on/since
                        <strong><?php echo e(date("d/M/Y h:i A", strtotime($item->currentStatus[0]->statusHistory->created_at))); ?></strong>
                    </h6>
                </div>

            </div>

        </div>


        <div class="col-md-4">

            

            <?php
                $disabled = "disabled";
                $link = "#";
                // echo $user->id;
                if($item->assignmentCurrent[0]->assignment->to_user_id == $user->id){
                    $disabled = "";
                    $link = null;
                }
            ?>
            <a href="<?php echo e($link ?? route('ir.form.step1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
               class="btn btn-success btn-block btn-sm text-left bg-info-600 profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-pencil mr-2"></i> General Info
            </a>

            <a href="<?php echo e($link ?? route('ir.form.step2', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
               class="btn btn-success btn-block btn-sm text-left bg-teal-600 profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-books mr-2"></i> Evidences
            </a>

            <a href="<?php echo e($link ?? route('ir.form.step3', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
               class="btn btn-success btn-block btn-sm text-left bg-orange profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-users mr-2"></i> Persons of Interest
            </a>

            <a href="<?php echo e($link ?? route('ir.form.step4', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
               class="btn btn-success btn-block btn-sm text-left bg-blue-400 profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-map4 mr-2"></i> Place of Interest
            </a>

            <a href="<?php echo e($link ?? route('ir.form.step5', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
               class="btn btn-success btn-block btn-sm text-left bg-grey-400 profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-road mr-2"></i> Mobility & Route
            </a>

            <a href="#forwardIncident"
               class="btn btn-success btn-block btn-sm text-left bg-purple-400 profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-paperplane mr-2"></i> Forward / Transfer Incident
            </a>

            <a href="<?php echo e($link ?? route('ir.form.closure-step-1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
               class="btn btn-danger btn-block btn-sm text-left profile-mf-btn <?php echo e($disabled); ?>">
                <i class="icon-cross2 mr-2"></i> Recoveries & Closure
            </a>

        </div>

    </div>




    <div class="row">

        <div class="col-md-8">

            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><strong>Incident Details & Evidences</strong></h6>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <p><?php echo nl2br($item->general_description); ?></p>
                        </div>
                    </div>


                    <div class="row mt-2">
                        <div class="col-12">
                            <h6><u>Evidences</u></h6>

                            <div class="row">
                                <?php $sn = 1 ?>
                                <?php $__currentLoopData = $item->evidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-md-6 pb-2">
                                        <a href="<?php echo e(asset("uploads/evidences/".$evd->file)); ?>" target="_blank">
                                            <div class="p-2" style="box-shadow: 1px 1px 8px #adaaaa">
                                                <strong><?php echo e($sn); ?>. </strong>
                                                <i class="<?php echo e($evd->evidenceType->link_icon); ?>"></i>
                                                <?php echo e($evd->title); ?>

                                            </div>
                                        </a>
                                    </div>
                                    <?php $sn++ ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>


                    <?php if($item->complainants->count() > 0): ?>

                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="alert alpha-brown border-0">
                                    <h6><u>Complainants</u></h6>

                                    <div class="table-responsive">
                                        <table class="table table-hover table-sm">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Father Name</th>
                                                <th>CNIC</th>
                                                <th>Passport</th>
                                                <th>Registration</th>
                                                <th>Contact</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php if( count($item->complainants) > 0 ): ?>
                                                <?php $__currentLoopData = $item->complainants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($comp->name); ?></td>
                                                        <td><?php echo e($comp->father_name); ?></td>
                                                        <td><?php echo e($comp->cnic); ?></td>
                                                        <td><?php echo e($comp->passport); ?></td>
                                                        <td><?php echo e($comp->other_registration_no); ?></td>
                                                        <td><?php echo e($comp->contact_number); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>

                    <?php endif; ?>

                </div>


            </div>

        </div>


        <div class="col-md-4">

            <div class="card">

                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><strong>Incident Status Log</strong></h6>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body b-order-top-blue">

                    <div class="list-feed list-feed-solid">

                        <?php $__currentLoopData = $item->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-feed-item border-<?php echo e($sh->incidentStatus->bg_class); ?>">

                                <span class="badge badge-<?php echo e($sh->incidentStatus->bg_class); ?>">
                                    <?php if($sh->reopened == "yes"): ?> Re-opened <?php else: ?> <?php echo e($sh->incidentStatus->title); ?> <?php endif; ?>
                                </span>
                                <a href="#"><?php echo e($sh->user->name); ?></a> - <span class="-text-muted"
                                                                              style="font-size: 11px"> (<?php echo e(date('d/M/Y h:i A', strtotime($sh->created_at))); ?>)</span><br>
                                <?php echo e($sh->remarks); ?>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

            </div>

        </div>

    </div>






    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><strong>Persons of Interest</strong></h5>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-md-12">

                            <div class="table-responsive" style="min-height: 100px">

                                <?php if($item->incidentPersons->count() <= 0): ?>

                                    <div class="alert alert-warning">
                                        <strong>ATTENTION!</strong> It looks like that there are no persons of interest
                                        attached with this incidence right now. You may <a
                                            href="<?php echo e($link ?? route('ir.form.step3', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
                                            class="<?php echo e($disabled); ?>"><strong>Click
                                                here</strong></a> to start adding persons of interest
                                    </div>

                                <?php else: ?>


                                    <table class="table table-striped">

                                        <thead>

                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Father Name</th>
                                            <th>CNIC</th>
                                            <th>Reg.No.</th>
                                            <th>Passport</th>
                                            <th>Gender</th>
                                            <th>Contact</th>
                                            <th>Status</th>
                                            <th>Other Dept. Requests</th>
                                            <?php if(!$link): ?>
                                                <th style="width: 160px"></th>
                                            <?php endif; ?>
                                        </tr>

                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $item->incidentPersons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($pers->person->name); ?></td>
                                                <td><?php echo e($pers->person->father_name); ?></td>
                                                <td><?php echo e($pers->person->cnic); ?></td>
                                                <td><?php echo e($pers->person->other_registration); ?></td>
                                                <td><?php echo e($pers->person->passport); ?></td>
                                                <td><?php echo e($pers->person->gender->title ?? "n/a"); ?></td>
                                                <td><?php echo e($pers->person->contact_number); ?></td>
                                                <td>
                                                    <?php if($pers->person->poiStautsHistoryCurrent->count() > 0): ?>
                                                        <?php echo "<span class='badge badge-".$pers->person->poiStautsHistoryCurrent[0]->poiStatusHistory->poiStatus->bg_class."'>".$pers->person->poiStautsHistoryCurrent[0]->poiStatusHistory->poiStatus->title."</span>" ?? ""; ?>

                                                        <?php if($pers->person->poiStautsHistoryCurrent->count() > 0): ?>
                                                            <small><?php echo e(date("d/M/Y h:i A", strtotime($pers->person->poiStautsHistoryCurrent[0]->poiStatusHistory->status_date))); ?></small>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <code>n/a</code>
                                                    <?php endif; ?>
                                                </td>


                                                <td>

                                                    <?php

                                                        $total_req_users = 0;
                                                        $completed_req_users = 0;
                                                        foreach($pers->person->requests as $req){
                                                            $thisReqUsers = $req->requestUsers;
                                                            $total_req_users += $thisReqUsers->count();

                                                            if($thisReqUsers->count() > 0){
                                                                $completed_req_users += $thisReqUsers->where('status', 'completed')->count();
                                                            }
                                                        }

                                                        // echo $total_req_users."/".$completed_req_users;
                                                        $percent = 0;
                                                        if($total_req_users > 0){
                                                            $percent = round(($completed_req_users/$total_req_users)*100);
                                                        }

                                                    ?>

                                                    <?php if($total_req_users > 0): ?>
                                                        <span style="font-size: 11px; font-weight: bold"><?php echo e($completed_req_users); ?> / <?php echo e($total_req_users); ?> (<?php echo e($percent); ?>%)</span>
                                                        <br>

                                                        <div class="progress mb-3" style="height: 0.375rem;">
                                                            <div class="progress-bar bg-success"
                                                                 style="width: <?php echo e($percent); ?>%">
                                                                <span class="sr-only"><?php echo e($percent); ?>% Complete</span>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <code>n/a</code>
                                                    <?php endif; ?>

                                                </td>

                                                <?php if(!$link): ?>
                                                    <td>

                                                        <a href="<?php echo e($link ?? route('ir.od-requests.initiate-request', [
    'id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id),
    'entity_type_id' => \Illuminate\Support\Facades\Crypt::encrypt('1'),
    'entity_id' => \Illuminate\Support\Facades\Crypt::encrypt($pers->person->id)])); ?>"
                                                           class="btn btn-warning btn-sm btn-block <?php echo e($disabled); ?>">
                                                            Info Request <i class="icon-arrow-right16 ml-1"></i>
                                                        </a>


                                                        <a href="#" class="btn btn-info btn-sm btn-block"
                                                           data-toggle="modal" data-target="#poiStatusUpdate"
                                                           data-person_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($pers->person->id)); ?>">
                                                            Sts. Update <i class="icon-reading ml-1"></i>
                                                        </a>


                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>

                                <?php endif; ?>


                            </div>

                        </div>

                    </div>

                </div>


            </div>
        </div>
    </div>







    <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><strong>Mobilities</strong></h5>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-md-12">

                            <?php if( $item->mobilities->count() == 0 ): ?>

                                <div class="alert alert-warning">
                                    <span class="font-weight-semibold">Warning!</span> No mobilities have been added to
                                    this incident yet. Please <a href="<?php echo e($link ?? route('ir.form.step5', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class=" <?php echo e($disabled); ?>"> <strong>click here</strong></a> to add mobilities
                                </div>

                            <?php else: ?>



                                <div class="row">
                                    <div class="col-12">


                                        <div class="table-responsive">
                                            <table class="table table-hover table-sm">

                                                <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Type</th>
                                                    <th style="width: 40%">Mobility Details</th>
                                                    <th>Route Details</th>
                                                    
                                                    <th>Other Dept. Requests</th>
                                                    <?php if(!$link): ?>
                                                        <th style="width: 140px"></th>
                                                    <?php endif; ?>
                                                </tr>
                                                </thead>

                                                <tbody>
                                                <?php $__currentLoopData = $item->mobilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><strong><?php echo e($mob->mobilityType->title ?? ""); ?></strong></td>
                                                        <td>

                                                            <?php if($mob->mobility_type_id == 1): ?>

                                                                <span>
                                                                        <strong><?php echo e($mob->vehicleBrand->title ?? ""); ?> (<?php echo e($mob->vehicleType->title ?? ""); ?> <?php echo e($mob->vehicle_model ?? ""); ?>) | Color: <?php echo e($mob->color ?? ""); ?></strong> <br>
                                                                        <strong>Registration Status: </strong> <?php echo e($mob->vehicle_registration_status ?? ""); ?> <?php echo e($mob->vehicle_registration_no ?? ""); ?> / <strong>Chassis No.:</strong> <?php echo e($mob->vehicle_chassis_no ?? ""); ?> (Chassis Tempered: <?php echo e($mob->vehicle_chassis_tempered ?? ""); ?>)
                                                                    </span>

                                                            <?php elseif($mob->mobility_type_id == 2): ?>

                                                                <span>
                                                                        <strong>Flight Type: </strong> <?php echo e($mob->flight_type ?? ""); ?> | <strong>Flight No.: </strong> <?php echo e($mob->flight_no ?? ""); ?> <br>
                                                                        <strong>Airport: </strong> <?php echo e($mob->airport_name ?? ""); ?> (<?php echo e($mob->flightOriginCountry->title ?? ""); ?> to <?php echo e($mob->flightDestinationCountry->title ?? ""); ?>)
                                                                    </span>

                                                            <?php elseif($mob->mobility_type_id == 3): ?>

                                                                <span>
                                                                        <strong>Shipping Company: </strong> <?php echo e($mob->shipping_company ?? ""); ?> | <strong>Container No.:</strong> <?php echo e($mob->container_no ?? ""); ?>

                                                                    </span>

                                                            <?php elseif($mob->mobility_type_id == 4): ?>

                                                                <span>
                                                                        <strong>Courier Company: </strong> <?php echo e($mob->courier_name ?? ""); ?> <br>
                                                                        <strong>From: </strong><?php echo e($mob->courier_origin_details ?? ""); ?> <br>
                                                                        <strong>To: </strong><?php echo e($mob->courier_destination_details ?? ""); ?>

                                                                    </span>

                                                            <?php elseif($mob->mobility_type_id == 5): ?>

                                                                <span>
                                                                        <strong>Gadget Type: </strong> <?php echo e($mob->gadgettype->title ?? ""); ?> - <?php echo e($mob->gadget_manufacturer ?? ""); ?> (SR No. <?php echo e($mob->gadget_serial_no ?? ""); ?>)
                                                                    </span>

                                                            <?php endif; ?>

                                                        </td>
                                                        <td><?php echo e($mob->route_details); ?></td>
                                                        <td>

                                                            <?php

                                                                $total_req_users = 0;
                                                                $completed_req_users = 0;
                                                                foreach($mob->requests as $req){
                                                                    $thisReqUsers = $req->requestUsers;
                                                                    $total_req_users += $thisReqUsers->count();

                                                                    if($thisReqUsers->count() > 0){
                                                                        $completed_req_users += $thisReqUsers->where('status', 'completed')->count();
                                                                    }
                                                                }

                                                                // echo $total_req_users."/".$completed_req_users;
                                                                $percent = 0;
                                                                if($total_req_users > 0){
                                                                    $percent = round(($completed_req_users/$total_req_users)*100);
                                                                }

                                                            ?>

                                                            <?php if($total_req_users > 0): ?>
                                                                <span style="font-size: 11px; font-weight: bold"><?php echo e($completed_req_users); ?> / <?php echo e($total_req_users); ?> (<?php echo e($percent); ?>%)</span>
                                                                <br>

                                                                <div class="progress mb-3" style="height: 0.375rem;">
                                                                    <div class="progress-bar bg-success"
                                                                         style="width: <?php echo e($percent); ?>%">
                                                                        <span
                                                                            class="sr-only"><?php echo e($percent); ?>% Complete</span>
                                                                    </div>
                                                                </div>
                                                            <?php else: ?>
                                                                <code>n/a</code>
                                                            <?php endif; ?>

                                                        </td>

                                                        <?php if(!$link): ?>
                                                            <td>

                                                                <?php
                                                                    if($mob->mobility_type_id == 1){
                                                                        $ent_t_id = 2;
                                                                    }elseif($mob->mobility_type_id == 5){
                                                                        $ent_t_id = 3;
                                                                    }else{
                                                                        $ent_t_id = 2;
                                                                    }
                                                                ?>

                                                                <a href="<?php echo e($link ?? route('ir.od-requests.initiate-request', [
    'id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id),
    'entity_type_id' => \Illuminate\Support\Facades\Crypt::encrypt($ent_t_id),
    'entity_id' => \Illuminate\Support\Facades\Crypt::encrypt($mob->id)])); ?>"
                                                                   class="btn btn-warning btn-sm <?php echo e($disabled); ?>">
                                                                    Request <i class="icon-arrow-right16 ml-1"></i>
                                                                </a>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>

                                            </table>
                                        </div>

                                    </div>
                                </div>

                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>






    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><strong>Recoveries</strong></h5>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-md-12">

                            <div class="table-responsive" style="min-height: 100px">

                                <?php if($item->recoveries->count() <= 0): ?>

                                    <div class="alert alert-warning">
                                        <strong>ATTENTION!</strong> No recoveries has been added yet to the incident, <a
                                            href="<?php echo e($link ?? route('ir.form.closure-step-1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="<?php echo e($disabled); ?>"><strong>Click
                                                here</strong></a> to start adding recoveries
                                    </div>

                                <?php else: ?>


                                    <table class="table table-striped">

                                        <thead>

                                        <tr>
                                            <th>#</th>
                                            <th>Type</th>
                                            <th>Item</th>
                                            <th>Weight</th>
                                            <th>Quantity</th>
                                            <th>Approx. worth</th>

                                        </tr>

                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $item->recoveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($rec->recoveryType->title); ?></td>
                                                <td><?php echo e($rec->title); ?></td>
                                                <td><?php echo e($rec->weight); ?></td>
                                                <td><?php echo e($rec->quantity); ?></td>
                                                <td><?php echo e($rec->worth); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>

                                <?php endif; ?>


                            </div>

                        </div>

                    </div>

                </div>


            </div>
        </div>
    </div>



    <div class="row">
        <div class="col-md-12" id="forwardIncident">
            <!-- Chat widget -->
            <div class="card">

                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><strong>Forwarding / Transfer Incident</strong></h5>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body">


                    <?php if($item->assignmentCurrent[0]->assignment->to_user_id == $user->id and $item->currentStatus[0]->statusHistory->incident_status_id != 3): ?>
                    <div class="alert alpha-brown border-0">

                        <form action="<?php echo e(route('ir.forward-incident')); ?>" method="post" enctype="multipart/form-data">

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="incident_id"
                                   value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">


                            <div class="row">

                                <div class="col-md-5">
                                    <div class="form-group">
                                        <?php echo Form::label('department_type_id', 'Select Department Type ', ['class' => 'form-label control-label req']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_type_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('department_type_id', [null=>'Select a Department Type']+$department_types->toArray(), NULL, ['class' => 'form-control form-control-select2', 'id' => 'department_type_id', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-md-7">
                                    <div class="form-group">
                                        <?php echo Form::label('department_id', 'Select Department ', ['class' => 'form-label control-label req']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('department_id', [null=>'Select a Department'], NULL, ['class' => 'form-control form-control-select2', 'id' => 'department_id', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <?php echo Form::label('user_id', 'Select Officer ', ['class' => 'form-label control-label req']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('user_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('user_id', [null=>'Select a Officer'], NULL, ['class' => 'form-control form-control-select2', 'id' => 'user_id', 'required' => 'required']); ?>

                                    </div>
                                </div>


                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <?php echo Form::label('remarks', 'Remarks ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                        <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'required' => 'required']); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="alert alpha-success">
                                        <div class="form-group">
                                            <?php echo Form::label('attachment', 'Attachment (if any) ', ['class' => 'form-label control-label']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('attachment'); ?><?php endif; ?></span>
                                            <?php echo Form::file('attachment', null, ['class' => 'form-control', 'id' => 'attachment']); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit"
                                            class="btn bg-success-400 btn-labeled btn-labeled-right ml-auto"><b><i
                                                class="icon-paperplane"></i></b> Forward / Transfer Incident
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>

                    <?php else: ?>

                        <?php if( $item->currentStatus[0]->statusHistory->incident_status_id == 3): ?>
                            <div class="alert alert-success border-0">
                                <h6>
                                    <strong>
                                        <i class="icon-warning"></i> ATTENTION!
                                    </strong>
                                </h6>

                                This incident has been closed by <strong><?php echo e($item->assignmentCurrent[0]->assignment->toUser->name); ?></strong> (<?php echo e($item->assignmentCurrent[0]->assignment->toUser->company->title); ?>)
                            </div>
                        <?php else: ?>
                            <div class="alert alert-primary border-0">
                                <h6>
                                    <strong>
                                        <i class="icon-warning"></i> ATTENTION!
                                    </strong>
                                </h6>

                                This incident is currently assigned to <strong><?php echo e($item->assignmentCurrent[0]->assignment->toUser->name); ?></strong> (<?php echo e($item->assignmentCurrent[0]->assignment->toUser->company->title); ?>)
                            </div>
                        <?php endif; ?>



                    <?php endif; ?>


                        <div class="row">
                            <div class="col-md-12">
                                <div style="border-top: 4px solid #e1e1e1; margin-top: 20px; margin-bottom: 30px"></div>
                            </div>
                        </div>



                    <div class="-alert -alpha-slate">

                        <div class="row">
                            <div class="col-md-12">
                                <h5><strong>Forward / Transfer Timeline</strong></h5>
                            </div>
                        </div>


                        <ul class="media-list media-chat media-chat-scrollable mb-3">

                            <?php $__currentLoopData = $item->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="media">

                                    <div class="mr-3">


                                        <span class="alert <?php if($ass->assignment_type_id == 1): ?> alpha-warning <?php else: ?> alpha-danger <?php endif; ?>"
                                              style="display: inline-block; width: 60px; height: 60px; -border: 1px solid red; text-align: center; border-radius: 50px; line-height: 59px; padding: 0px; padding-right: 4px; color: <?php if($ass->assignment_type_id == 1): ?> #f8b117 <?php else: ?> red <?php endif; ?>">
                                            <i class="icon-paperplane icon-2x"></i>
                                        </span>
                                    </div>

                                    <div class="media-body" style="margin-top: 10px;">
                                        <div class="media-chat-item">

                                            <?php if($ass->assignment_type_id == 1): ?>

                                                Initiated by
                                                <span class="badge badge-warning" style="font-size: 14px"><?php echo e($ass->toUser->name); ?> <small>(<?php echo e($ass->toUser->company->title); ?>)</small></span>

                                            <?php else: ?>

                                                <span class="badge badge-info" style="font-size: 14px"><?php echo e($ass->fromUser->name); ?> <small>(<?php echo e($ass->fromUser->company->title); ?>)</small></span>
                                                to
                                                <span class="badge badge-info" style="font-size: 14px"><?php echo e($ass->toUser->name); ?> <small>(<?php echo e($ass->toUser->company->title); ?>)</small></span>

                                            <?php endif; ?>


                                            Dated

                                            <span class="badge badge-dark mt-2"
                                                  style="font-size: 12px"><?php echo e(date("d/M/Y h:i A", strtotime($ass->created_at))); ?></span><br>

                                            <p class="mt-4">
                                                <strong>Remarks:</strong><br>
                                                <?php echo e($ass->remarks); ?>

                                            </p>

                                            <?php if(!is_null($ass->attachment)): ?>
                                            <p>
                                                <a href="<?php echo e(asset('uploads/assignment_attachments/'.$ass->attachment)); ?>" target="_blank">
                                                    <i class="fa fa-paperclip"></i> View Attachment
                                                </a>
                                            </p>
                                            <?php endif; ?>

                                        </div>
                                        
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </ul>
                    </div>


                </div>
            </div>
            <!-- /chat widget -->
        </div>
    </div>



    <?php if(isset($od_request_u) and $od_request_u->count() > 0): ?>

        <!-- collapse the form if there are already requests -->
        <script>
            $(document).ready(function () {
                setTimeout(function () {
                    $(".requestFormCollapse").trigger('click')
                }, 500);
            })
        </script>


        <div class="row">
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-body">
                        <!-- Questions title -->
                        <div class="text-center mb-3 py-2 mt-5">
                            <h3 class="font-weight-semibold mb-1">Initiated Requests</h3>
                            <span class="text-muted d-block">Following requests have been initiated and forwarded to stakeholders</span>

                            <?php
                                $f_total_requests = $od_request_u->count();
                                $f_completed_requests = $od_request_u->where('status', 'completed')->count();
                                $f_percentage = round(($f_completed_requests/$f_total_requests)*100);
                            ?>

                            <h5 class="font-weight-semibold">
                                <?php echo e($f_completed_requests); ?> / <?php echo e($f_total_requests); ?> (<?php echo e($f_percentage); ?>% Completed)
                            </h5>

                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                    <div class="progress mb-3" style="height: 1rem;">
                                        <div class="progress-bar bg-success" style="width: <?php echo e($f_percentage); ?>%">
                                            <span class="sr-only"><?php echo e($f_percentage); ?>% Complete</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4"></div>
                            </div>

                        </div>
                        <!-- /questions title -->

                        <div class="row">
                            <div class="col-md-12 text-center">
                                <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                <i class="icon-arrow-down32"
                                   style="display: block; line-height: .7; margin-bottom: 7px"></i>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>




        <!-- Inner container -->
        <div class="d-flex align-items-start flex-column flex-md-row">

            <!-- Left content -->
            <div class="w-100 overflow-auto order-2 order-md-1">

                <!-- Questions list -->
                <div class="card-group-control card-group-control-right">


                    <?php $__currentLoopData = $od_request_u; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            if($requ->status == 'completed'){
                                $sts_class = "success";
                                $sts_title = "Completed";
                            }else{
                                if(!is_null($requ->due_date) and time() > strtotime($requ->due_date)){
                                    $sts_class = "danger";
                                    $sts_title = "Overdue";
                                }else{
                                    $sts_class = "warning";
                                    $sts_title = "Pending";
                                }
                            }
                        ?>


                        <div class="card mb-2">
                            <div class="card-header">
                                <h6 class="card-title">
                                    <a class="text-default collapsed " data-toggle="collapse"
                                       href="#question<?php echo e($requ->id); ?>">
                                        <span class="font-weight-semibold"><?php echo e($loop->iteration); ?>. </span>
                                        <i class="fa fa-check-circle text-<?php echo e($sts_class); ?>"></i>
                                        <strong><?php echo e($requ->request->form->title); ?></strong> of
                                        <em><u><?php echo e($requ->request->entityType->title); ?></u></em> assigned to
                                        <strong><?php echo e($requ->user->name ?? ""); ?></strong>
                                        <small>
                                            (<?php echo e($requ->user->company->title ?? ""); ?>)
                                            <span class="text-danger">[Due: <?php echo e(date('d/M/Y', strtotime($requ->request->due_date))); ?>]</span>
                                        </small>
                                    </a>
                                </h6>
                            </div>

                            <div id="question<?php echo e($requ->id); ?>" class="collapse">
                                <div class="card-body">


                                    <div class="row mb-0">
                                        <div class="col-md-12">
                                            <div class="alert alpha-info border-0">

                                                <h5><strong><u>Request Details</u></strong></h5>
                                                <p>
                                                    This request was initiated by
                                                    <strong><?php echo e($requ->request->user->name ?? ""); ?></strong>
                                                    <small>(<?php echo e($requ->request->user->company->title ?? ""); ?>)</small>
                                                    for the "<?php echo e($requ->request->entityType->title ?? ""); ?>",
                                                    dated <?php echo e(date("d/M/Y h:i A", strtotime($requ->request->created_at))); ?>


                                                </p>

                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <p class="text-danger"><strong>Due
                                                                Date: </strong> <?php echo e(date("d/M/Y", strtotime($requ->request->due_date))); ?>

                                                        </p>
                                                        <p>
                                                            <span
                                                                class="badge badge-<?php echo e($sts_class); ?>"><?php echo e($sts_title); ?></span>
                                                            <?php if($requ->status == 'completed'): ?>
                                                                <span
                                                                    class="text-success">Completed on <?php echo e(date("d/M/Y h:s A", strtotime($requ->completion_date))); ?></span>
                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                </div>

                                                <p>
                                                    <strong>Remarks: </strong><br><?php echo nl2br($requ->request->remarks); ?>

                                                </p>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                            <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                            <i class="icon-arrow-down32"
                                               style="display: block; line-height: .7; margin-bottom: 7px"></i>
                                        </div>
                                    </div>


                                    <?php if($requ->status == 'completed'): ?>
                                        <div class="row mt-0">
                                            <div class="col-md-12">
                                                <div class="alert alpha-success border-0">

                                                    <h5><strong><u>Response Data</u></strong></h5>

                                                    <p>
                                                        Response submitted by
                                                        <strong><?php echo e($requ->user->name ?? ""); ?></strong>
                                                        <small>(<?php echo e($requ->user->company->title ?? ""); ?>)</small>, dated
                                                        <strong><?php echo e(date("d/M/Y h:i A", strtotime($requ->completion_date))); ?></strong>
                                                    </p>



                                                    <?php if($requ->compliance_possible == "no"): ?>

                                                        <div class="alert alert-danger">
                                                            <strong><i class="icon-warning"></i> ATTENTION! <br>
                                                                the officer stated that compliance to this request is not possible, following are the details:</strong>
                                                            <br><br>
                                                            "<em><?php echo e($requ->remarks); ?></em>"
                                                        </div>


                                                    <?php else: ?>

                                                        <p>
                                                            <strong>Remarks: </strong><br><?php echo e($requ->remarks); ?>

                                                        </p>

                                                        <div>

                                                            
                                                            <table class="table table-striped table-bordered" >
                                                                <thead>
                                                                <tr>
                                                                    <th style="width: 30%">Data Request</th>
                                                                    <th>Submitted Information</th>
                                                                </tr>
                                                                </thead>

                                                                <tbody>
                                                                <?php $__currentLoopData = $requ->requestUserData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <th><?php echo e($theD->od_field_title); ?></th>
                                                                        <td>
                                                                            <?php if($theD->od_field_type_id == 5): ?>
                                                                                <a href="<?php echo e(asset('uploads/od_responses/'.$theD->od_value)); ?>" target="_blank">
                                                                                    <i class="fa fa-paperclip"></i> File Attachment
                                                                                </a>
                                                                            <?php elseif($theD->od_field_type_id == 3): ?>
                                                                                <?php if(!is_null($theD->od_value)): ?>
                                                                                    <?php echo e(date("d/M/Y", strtotime($theD->od_value))); ?>

                                                                                <?php endif; ?>
                                                                            <?php else: ?>
                                                                                <?php echo e($theD->od_value); ?>

                                                                            <?php endif; ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>

                                                    <?php endif; ?>





                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="row mt-0">
                                            <div class="col-md-12">
                                                <div class="alert alert-warning b-order-0">
                                                    ATTENTION! The assignee has not yet submitted their response to this
                                                    request
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>


                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>

    <?php endif; ?>



    <?php echo $__env->make("incidentreporting::incident-reporting.steps._partials.poi_status_update_modal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <script>

        $(document).ready(function () {
            $("#department_type_id").change(function(){
                var department_type_id = $(this).val();
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.companies-by-type-id')); ?>',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        department_type_id: department_type_id
                    },
                    success: function(res){
                        var options = "<option value>Select a Department</option>";
                        $.each(res, function(i, v){
                            options += "<option value='"+i+"'>"+v+"</option>";
                        });
                        $("#department_id").html(options);
                    }
                })
            });


            $("#department_id").change(function(){
                var department_id = $(this).val();
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.users-list-by-company-id')); ?>',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        company_id: department_id,
                        current_user: '<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($user->id)); ?>'
                    },
                    success: function(res){
                        var options = "<option value>Select an Officer</option>";
                        $.each(res, function(i, v){
                            options += "<option value='"+i+"'>"+v+"</option>";
                        });
                        $("#user_id").html(options);
                    }
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/incident_profile.blade.php ENDPATH**/ ?>