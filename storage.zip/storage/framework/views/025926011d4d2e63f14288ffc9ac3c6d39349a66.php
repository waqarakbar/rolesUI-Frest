<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
<style>
    .card{
        border: unset;
        box-shadow: unset;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">


                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => 'ir.form.step1-save',
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>




                            <h6>
                                <span class="step-title">
                                    General Info
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset  class="pt-3">

                                <div class="row">
                                    <div class="col-md-6">
                                        <?php if($item->exists): ?>
                                            <input type="hidden" name="id" value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>" />
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label class="req">Spectrum:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('spectrum_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('spectrum_id', [null => 'Select a Spectrum']+$spectrum->toArray() ,null, ['class' => 'form-control form-control-select2',"data-placeholder"=>"Select Spectrum",'id'=>'spectrum_id','Placeholder'=>'Spectrum', 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                        <div class="row">

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="req">Source:</label>
                                                    <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('incident_source_id'); ?> <?php endif; ?></span>
                                                    <?php echo Form::select('incident_source_id',$sources,$item->incident_source_id, ['class' => 'form-control form-control-select2',"data-placeholder"=>"Select Source",'id'=>'source_id','Placeholder'=>'Source', 'required' => 'required']); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <?php echo Form::label('modus_operandi_id', 'Modus Operandi ', ['class' => 'control-label']); ?>


                                                    <span
                                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('modus_operandi_id'); ?> <?php endif; ?></span>
                                                    <?php echo Form::select('modus_operandi_id', [null=>'Modus Operandi']+$modus_operandi->toArray(), NULL, ['class' => 'form-control', 'id' => 'modus_operandi_id']); ?>

                                                </div>
                                            </div>

                                        </div>


                                    </div>

                                    
                                </div>


                                <div class="row">

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="req">Motive:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('incident_motive_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('incident_motive_id[]',$motives, $item->incidentMotives->pluck('id'), ['class' => 'form-control form-control-select2',"data-placeholder"=>"Select Motive",'id'=>'motive_id','Placeholder'=>'Incident Motive', "multiple"=>"multiple", 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="req">Priority:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('priority_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('priority_id',$priorities,null, ['class' => 'form-control form-control-select2',"data-placeholder"=>"Select Priority",'id'=>'priority_id','Placeholder'=>'Priority', 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="req">Police Station:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('police_station_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('police_station_id',[null => 'Select a police station']+$police_stations->toArray() ,null, ['class' => 'form-control form-control-select2',"data-placeholder"=>"Select Priority",'id'=>'police_station_id','Placeholder'=>'Police Station']); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="req">Date of Report:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('incident_date'); ?> <?php endif; ?></span>
                                            <?php echo Form::date('incident_date',NULL, ['class' => 'form-control',"data-placeholder"=>"DD-MM-YYY",'id'=>'incident_date', 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Time of Report:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('incident_time'); ?> <?php endif; ?></span>
                                            <?php echo Form::time('incident_time',NULL, ['class' => 'form-control',"data-placeholder"=>"DD-MM-YYY",'id'=>'incident_time']); ?>

                                        </div>
                                    </div>


                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Worth Weight:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('worth_weight'); ?> <?php endif; ?></span>
                                            <?php echo Form::text('worth_weight',$item->worth_weight, ['class' => 'form-control',"data-placeholder"=>"Worth Weight",'id'=>'worth_weight']); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>General Description:</label>
                                            <span class="help"><?php if(session()->has('errors')): ?><?php echo session()->get('errors')->first('general_description'); ?> <?php endif; ?></span>
                                            <?php echo Form::textarea('general_description',null, ['class' => 'form-control',"data-placeholder"=>"General Description",'rows'=>6,'id'=>'general_description']); ?>

                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <h6>
                                <span class="step-title">
                                    Complainants & Evidences
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                            </fieldset>


                            <h6>
                                <span class="step-title">
                                    Person of Interest
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>


                            <h6>
                                <span class="step-title">
                                    Place of Interest
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step4', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                            </fieldset>




                            <h6>
                                <span class="step-title">Mobility & Routes</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step5', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>




                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">


                                    <button type="submit" class="btn btn-info btn-sm" name="save">
                                        <i class="fa fas fa-save mr-1"></i> Save
                                    </button>

                                    <button type="submit" name="save_next" class="btn btn-success btn-sm">
                                        Save & Next <i class="icon-arrow-right16 ml-1"></i>
                                    </button>
                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <script>
        $(function(){

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/form1.blade.php ENDPATH**/ ?>