<!-- Disabled keyboard interaction -->
<div id="addComplainant" class="modal fade" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-l-g">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Complainant</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST" action="<?php echo e(route('ir.incident.save-complainant')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="incident_id" value="<?php echo e($formID); ?>">



                    <div class="row">

                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo Form::label('complainant_type', 'Complainant Type ', ['class' => 'control-label form-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('complainant_type'); ?> <?php endif; ?></span>
                                <?php echo Form::select('complainant_type', [null=>'Select a Complainant Type', 'self' => 'Self', 'other' => 'Other'], NULL, ['class' => 'form-control', 'id' => 'complainant_type', 'required' => 'required']); ?>

                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo Form::label('profession_id', 'Complainant / Victim Profession ', ['class' => 'control-label form-label']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('profession_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('profession_id', [null=>'Select a Profession (if any)']+$professions->toArray(), NULL, ['class' => 'form-control', 'id' => 'profession_id']); ?>

                            </div>
                        </div>

                    </div>



                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('name', 'Name ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('name'); ?><?php endif; ?></span>
                                <?php echo Form::text('name', old('name'), ['class' => 'form-control', 'id' => 'name', 'required' => 'required']); ?>

                            </div>
                        </div>

                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('father_name', 'Father Name ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('father_name'); ?><?php endif; ?></span>
                                <?php echo Form::text('father_name', old('father_name'), ['class' => 'form-control', 'id' => 'father_name', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">

                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('gender_id', 'Select Gender ', ['class' => 'control-label form-label']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('gender_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('gender_id', [null=>'Select a Gender']+$genders->toArray(), old('gender_id'), ['class' => 'form-control', 'id' => 'gender_id']); ?>

                            </div>
                        </div>

                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('contact_number', 'Contact Number ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('contact_number'); ?><?php endif; ?></span>
                                <?php echo Form::text('contact_number', old('contact_number'), ['class' => 'form-control', 'id' => 'contact_number', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('cnic', 'CNIC Number ', ['class' => 'form-label']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('cnic'); ?><?php endif; ?></span>
                                <?php echo Form::text('cnic', old('cnic'), ['class' => 'form-control', 'id' => 'cnic']); ?>

                            </div>
                        </div>

                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('passport', 'Passport Number ', ['class' => 'form-label']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('passport'); ?><?php endif; ?></span>
                                <?php echo Form::text('passport', old('passport'), ['class' => 'form-control', 'id' => 'passport']); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('other_registration_no', 'Any Other Registration Number ', ['class' => 'form-label']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('other_registration_no'); ?><?php endif; ?></span>
                                <?php echo Form::text('other_registration_no', old('other_registration'), ['class' => 'form-control', 'id' => 'other_registration_no']); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('address', 'Address ', ['class' => 'form-label']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('address'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('address', old('address'), ['class' => 'form-control', 'id' => 'address', 'rows' => 3]); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="icon-arrow-left16 mr-1"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Save Complainant
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /disabled keyboard interaction -->
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/_partials/new_complainant_modal.blade.php ENDPATH**/ ?>