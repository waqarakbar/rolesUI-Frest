<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startSection('content'); ?>


    <?php if($entity_type_id == 1): ?>
        <?php echo $__env->make("incidentreporting::od_requests._partials.poi_entity", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make("incidentreporting::od_requests._partials.mobility_entity", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>




    <?php if($request_user_status == "pending"): ?>

        <div class="row">
            <div class="col-12">

                <!-- Traffic sources -->
                <div class="card">
                    <div class="card-header header-elements-inline">
                        <h5 class="card-title"><strong><?php echo e($title); ?></strong></h5>
                        <div class="header-elements">
                            <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                                
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <div class="row">


                            <div class="col-12">


                                <form method="post" action="<?php echo e(route('ir.od-requests.save-response')); ?>"
                                      enctype="multipart/form-data">

                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                    <input type="hidden" name="incident_id"
                                           value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">

                                    <input type="hidden" name="entity_type_id"
                                           value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($entity_type_id)); ?>">

                                    <input type="hidden" name="entity_id"
                                           value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($entity_id)); ?>">

                                    <input type="hidden" name="request_id"
                                           value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($od_request->id)); ?>">




                                    <div class="row mb-0">
                                        <div class="col-md-12">
                                            <div class="alert alpha-info border-0">

                                                <h5><strong><u>Request Details</u></strong></h5>
                                                <p>
                                                    This request was initiated by
                                                    <strong><?php echo e($od_request->user->name ?? ""); ?></strong>
                                                    <small>(<?php echo e($od_request->user->company->title ?? ""); ?>)</small>
                                                    for the "<?php echo e($od_request->entityType->title ?? ""); ?>",
                                                    dated <?php echo e(date("d/M/Y h:i A", strtotime($od_request->created_at))); ?>


                                                </p>

                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <p class="text-danger"><strong>Due
                                                                Date: </strong> <?php echo e(date("d/M/Y", strtotime($od_request->due_date))); ?>

                                                        </p>

                                                    </div>
                                                </div>

                                                <p>
                                                    <strong>Remarks: </strong><br><?php echo nl2br($od_request->remarks); ?>

                                                </p>

                                            </div>
                                        </div>
                                    </div>



                                    <div class="row">
                                        <div class="col-md-12">
                                            <hr>
                                        </div>
                                    </div>



                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="alert alpha-success border-0">

                                                <div class="form-group">
                                                    <?php echo Form::label('compliance_possible', 'Is complying to this request possible? ', ['class' => 'form-label req control-label']); ?>


                                                    <span
                                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('compliance_possible'); ?> <?php endif; ?></span>
                                                    <?php echo Form::select('compliance_possible', ['yes'=>'Yes', 'no' => 'No'], NULL, ['class' => 'form-control', 'id' => 'compliance_possible', 'required' => 'required']); ?>

                                                </div>

                                            </div>
                                        </div>
                                    </div>





                                    <div id="dynamic_form_fields_cont">
                                        <?php $__currentLoopData = $form->fieldGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                            <div class="row">
                                                <div class="col-md-12"
                                                     style="-border-bottom: 1px solid #efeeee; margin-top: 20px">
                                                    <h6>
                                                        <strong><?php echo e($loop->iteration); ?>: <?php echo e($fg->title); ?></strong>

                                                        <?php if($fg->is_recurring == "yes"): ?>
                                                            <a href="" class="btn btn-info btn-success fg_recurring_btn"
                                                               data-target_div="fgid_<?php echo e($fg->id); ?>_cont"
                                                               style="padding: 2px 8px">
                                                                <i class="fa fa-plus"></i> Add New
                                                            </a>
                                                        <?php endif; ?>
                                                    </h6>


                                                    <div class="row">


                                                        <div class="col-md-12">

                                                            <div class="well alpha-brown" id="fgid_<?php echo e($fg->id); ?>_cont"
                                                                 style="-border: 1px solid red; padding: 10px">

                                                                <div class="row">

                                                                    <?php $__currentLoopData = $fg->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <input type="hidden" name="field_ids[]"
                                                                               value="<?php echo e($f->id); ?>">
                                                                        <?php
                                                                            $req = "";
                                                                            $input_req_attr = "";
                                                                            $input_req_attr_ph = "no";
                                                                            if($f->is_mandatory == "yes"){
                                                                                $req = "req";
                                                                                $input_req_attr = "required";
                                                                                $input_req_attr_ph = "yes";
                                                                            }
                                                                        ?>
                                                                        <div class="col-md-6">

                                                                            <div class="form-group">
                                                                                <?php $file_up_label = "" ?>
                                                                                <?php if($f->od_field_type_id == 5): ?>
                                                                                    <?php $file_up_label = " <span style='color: #f82828; font-weight: normal; font-size: 11px'>(only PDF and images are allowed)</span>" ?>
                                                                                <?php endif; ?>

                                                                                <label for="field_v_<?php echo e($f->id); ?>" class="form-label <?php echo e($req); ?>"><?php echo $f->title.$file_up_label; ?></label>
                                                                                <span
                                                                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first("field_v_".$f->id); ?><?php endif; ?></span>

                                                                                <?php if($f->od_field_type_id == 1): ?>

                                                                                    <input type="text"
                                                                                           name="field_v[<?php echo e($fg->id); ?>][<?php echo e($f->id); ?>][]"
                                                                                           class="form-control" <?php echo e($input_req_attr); ?> data-is_mandatory="<?php echo e($input_req_attr_ph); ?>">

                                                                                <?php elseif($f->od_field_type_id == 2): ?>

                                                                                    <input type="number"
                                                                                           name="field_v[<?php echo e($fg->id); ?>][<?php echo e($f->id); ?>][]"
                                                                                           class="form-control" <?php echo e($input_req_attr); ?> data-is_mandatory="<?php echo e($input_req_attr_ph); ?>">

                                                                                <?php elseif($f->od_field_type_id == 3): ?>

                                                                                    <input type="date"
                                                                                           name="field_v[<?php echo e($fg->id); ?>][<?php echo e($f->id); ?>][]"
                                                                                           class="form-control" <?php echo e($input_req_attr); ?> data-is_mandatory="<?php echo e($input_req_attr_ph); ?>">

                                                                                <?php elseif($f->od_field_type_id == 4): ?>

                                                                                    <textarea
                                                                                        name="field_v[<?php echo e($fg->id); ?>][<?php echo e($f->id); ?>][]"
                                                                                        class="form-control"
                                                                                        rows="3" <?php echo e($input_req_attr); ?>  data-is_mandatory="<?php echo e($input_req_attr_ph); ?>"></textarea>
                                                                                <?php elseif($f->od_field_type_id == 5): ?>

                                                                                    <input type="file" name="field_v[<?php echo e($fg->id); ?>][<?php echo e($f->id); ?>][]" class="form-control" <?php echo e($input_req_attr); ?> data-is_mandatory="<?php echo e($input_req_attr_ph); ?>" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps">

                                                                                <?php else: ?>

                                                                                    <select
                                                                                        name="field_v[<?php echo e($fg->id); ?>][<?php echo e($f->id); ?>][]"
                                                                                        class="form-control" <?php echo e($input_req_attr); ?> data-is_mandatory="<?php echo e($input_req_attr_ph); ?>">
                                                                                        <?php $__currentLoopData = $f->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <option
                                                                                                value="<?php echo e($fo->title); ?>"><?php echo e($fo->title); ?></option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                <?php endif; ?>

                                                                            </div>

                                                                        </div>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>


                                                </div>
                                            </div>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>



                                    <div class="row" style="margin-top: 20px">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <?php echo Form::label('remarks', 'Remarks / Details ', ['class' => 'form-label req']); ?>

                                                <span
                                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                                <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'required' => 'required', 'rows' => 6]); ?>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-12">

                                            <a href="<?php echo e(route($back_route[0])); ?>" class="btn btn-warning btn-sm mr-1"><i
                                                    class="icon-arrow-left16 mr-1"></i>
                                                <?php echo e($back_route[1]); ?></a>

                                            <button type="submit" class="btn btn-success btn-sm submit_btn_mf">
                                                <i class="icon-database-check mr-1"></i> Save Request
                                            </button>

                                        </div>
                                    </div>

                                </form>


                            </div>

                        </div>

                    </div>


                </div>
                <!-- /traffic sources -->

            </div>
        </div>

    <?php else: ?>


        <div class="row">
            <div class="col-12">

                <!-- Traffic sources -->
                <div class="card">
                    <div class="card-header header-elements-inline">
                        
                        <div class="header-elements">
                            <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                                
                            </div>
                        </div>
                    </div>

                    <div class="card-body">



                        <div class="row mb-0">
                            <div class="col-md-12">
                                <div class="alert alpha-info border-0">

                                    <h5><strong><u>Request Details</u></strong></h5>
                                    <p>
                                        This request was initiated by <strong><?php echo e($od_request->user->name ?? ""); ?></strong> <small>(<?php echo e($od_request->user->company->title ?? ""); ?>)</small> for the "<?php echo e($od_request->entityType->title ?? ""); ?>", dated <?php echo e(date("d/M/Y h:i A", strtotime($od_request->created_at))); ?>


                                    </p>

                                    <p class="text-danger">
                                        <strong>Due Date: </strong> <?php echo e(date('d/M/Y', strtotime($od_request->due_date))); ?>

                                    </p>

                                    <p>
                                        <strong>Remarks: </strong><br><?php echo e($od_request->remarks); ?>

                                    </p>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12 text-center">
                                <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                <i class="icon-arrow-down32" style="display: block; line-height: .7; margin-bottom: 7px"></i>
                            </div>
                        </div>


                        <div class="row mt-0">
                            <div class="col-md-12">
                                <div class="alert alpha-success border-0">

                                    <h5><strong><u>Response Data</u></strong></h5>

                                    <p>
                                        Response submitted by <strong><?php echo e($od_request->requestUsers[0]->user->name ?? ""); ?></strong> <small>(<?php echo e($od_request->requestUsers[0]->user->company->title ?? ""); ?>)</small>, dated <strong><?php echo e(date("d/M/Y h:i A", strtotime($od_request->requestUsers[0]->completion_date))); ?></strong>
                                    </p>

                                    <?php if($od_request->requestUsers[0]->compliance_possible == "no"): ?>

                                        <div class="alert alert-danger">
                                            <strong><i class="icon-warning"></i> ATTENTION! <br>
                                                the officer stated that compliance to this request is not possible, following are the details:</strong>
                                            <br><br>
                                            "<em><?php echo e($od_request->requestUsers[0]->remarks); ?></em>"
                                        </div>


                                    <?php else: ?>

                                        <p>
                                            <strong>Remarks: </strong><br><?php echo e($od_request->requestUsers[0]->remarks); ?>

                                        </p>

                                        <div>

                                            
                                            <table class="table table-striped table-bordered" >
                                                <thead>
                                                <tr>
                                                    <th style="width: 30%">Data Request</th>
                                                    <th>Submitted Information</th>
                                                </tr>
                                                </thead>

                                                <tbody>
                                                <?php $__currentLoopData = $od_request->requestUsers[0]->requestUserData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th><?php echo e($theD->od_field_title); ?></th>
                                                        <td>
                                                            <?php if($theD->od_field_type_id == 5): ?>
                                                                <a href="<?php echo e(asset('uploads/od_responses/'.$theD->od_value)); ?>" target="_blank">
                                                                    <i class="fa fa-paperclip"></i> File Attachment
                                                                </a>
                                                            <?php elseif($theD->od_field_type_id == 3): ?>
                                                                <?php if(!is_null($theD->od_value)): ?>
                                                                    <?php echo e(date("d/M/Y", strtotime($theD->od_value))); ?>

                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php echo e($theD->od_value); ?>

                                                            <?php endif; ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    <?php endif; ?>



                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-md-12">
                                <a href="<?php echo e(route($back_route[0])); ?>" class="btn btn-warning btn-sm mr-1"><i
                                        class="icon-arrow-left16 mr-1"></i>
                                    <?php echo e($back_route[1]); ?></a>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts-bottom'); ?>
    <script>

        $(document).ready(function () {

            <?php if(Session::has('errors')): ?>
            $("#department_type_id").trigger('change')
            <?php endif; ?>

            $("#department_type_id").change(function () {
                var department_type_id = $(this).val();
                // alert(department_type_id);
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('ir.od-requests.form-department-somethingx')); ?>',
                    data: {
                        department_type_id: department_type_id,
                        entity_type_id: '<?php echo e($entity_type_id); ?>',
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function (res) {
                        // console.log(res.departments);
                        var dpts = "";
                        $.each(res.departments, function (i, v) {
                            dpts += "<option value='" + i + "'>" + v + "</option>";
                        });
                        $("#department_id").html(dpts).trigger('change')
                        // $("#department_id").select2().trigger('change')

                        // console.log(Object.keys(res.forms).length)
                        if (Object.keys(res.forms).length > 0) {
                            var form_checks = "<div class='alert alpha-brown border-0'>";
                            form_checks += "<h6><strong><u>Select information requests,</u></strong> <small>(you may select one or more requests)</small></h6>";
                            $.each(res.forms, function (i, v) {
                                form_checks += "<div>";
                                form_checks += "<label class='form-label mb-2'>" +
                                    "<input type='checkbox' class='mr-2' name='form_ids[]' value='" + i + "' />" +
                                    " " + v +
                                    "</label>";
                                form_checks += "</div>";
                            });
                            $("#add_forms_checkboxes_here").html(form_checks);
                            // enable submit button
                            $(".submit_btn_mf").removeAttr("disabled")
                        } else {
                            var form_checks = "<div class='alert alert-danger border-0'>";
                            form_checks += "<h6><strong><u>Select information requests,</u></strong> <small>(you may select one or more requests)</small></h6>";
                            form_checks += "SORRY! there are no request forms assigned to the selected department type";
                            $("#add_forms_checkboxes_here").html(form_checks);

                            // disable submit button
                            $(".submit_btn_mf").attr("disabled", "disabled")
                        }

                    }
                })
            })
        });


        $(document).ready(function () {
            $(document).on('click', ".fg_recurring_btn", function (e) {
                e.preventDefault()
                var target_div = $(this).data('target_div')
                var target_html = $("#" + target_div).html()

                var refined_target_html = "<div class='well alpha-brown' style='margin-top: 20px; b-order: 1px solid red; padding: 10px'>" +
                    "<div class='text-right'><a href='#' class='-btn -btn-danger -btn-sm remove_fg text-danger'><i class='icon-trash'></i></a></div>" +
                    target_html +
                    "</div>"


                $("#" + target_div).after(refined_target_html)
            })

            $(document).on('click', ".remove_fg", function (e) {
                e.preventDefault()
                $(this).closest(".well").remove()
            })
        })

        $(document).ready(function () {
            $("#compliance_possible").change(function(){
                var compliance_possible = $(this).val();
                // alert(compliance_possible)
                if(compliance_possible == 'no'){
                    // remove the required attribute
                    $("#dynamic_form_fields_cont input, #dynamic_form_fields_cont select, #dynamic_form_fields_cont textarea").removeAttr('required');
                    $("#dynamic_form_fields_cont").css({'display': 'none'});
                }else{
                    $("#dynamic_form_fields_cont").css({'display': 'block'});
                    var fields = $("#dynamic_form_fields_cont input, #dynamic_form_fields_cont select, #dynamic_form_fields_cont textarea").removeAttr('required');
                    $.each(fields, function(i, v){
                       if($(v).attr('data-is_mandatory') == 'yes'){
                           $(v).attr('required', 'required')
                       }
                    })
                }
            })
        })

    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_requests/submit_response.blade.php ENDPATH**/ ?>