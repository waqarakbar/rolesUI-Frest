<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/ext_plugins/printThis/printThis.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title">Filter report by status</h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">




                        <form action="<?php echo e(route('ir.reports.incidents-by-spectrum')); ?>">


                            <div class="row">

                                <div class="col-md-8" >
                                    <div class="form-group">
                                        <?php echo Form::label('spectrum_id', 'Select a Spectrum ', ['class' => 'control-label req']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('spectrum_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('spectrum_id', [null=>'Select a a Spectrum']+$spectrum->toArray(), NULL, ['class' => 'form-control', 'id' => 'spectrum_id', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group pt-4">
                                        <button class="btn btn-success btn-sm btn-block" type="submit">
                                            <i class="fa fa-file-alt mr-1"></i> Filter Report
                                        </button>
                                    </div>
                                </div>

                            </div>


                        </form>



                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

    <?php if(isset($incident_list)): ?>
    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row printable">

                        <div class="col-md-12 text-center show_in_print">
                            <?php echo $__env->make('incidentreporting::reports._partials.report_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <h6><strong><u>Incidents List</u></strong></h6>
                                <table class="table table-sm table-bordered table-condensed" >

                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tracking ID</th>
                                        <th>Spectrum</th>
                                        <th>Date & Time</th>
                                        <th>Initiated By</th>
                                        <th>Current Assigned By</th>
                                        <th>Current Assigned To</th>
                                        <th>Source</th>
                                        <th>Self/Transf.</th>
                                        <th>Priority</th>
                                        <th>Motive</th>
                                        <th>Status</th>
                                        <th style="width: 100px">Other Departments Requests</th>
                                        <th class="hide_in_print"></th>

                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $incident_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>


                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><strong><?php echo e($item->tracking_code); ?></strong></td>
                                            <td><?php echo e($item->spectrum->title ?? ""); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->incident_date)->format('d/m/Y')); ?> <?php echo e(\Carbon\Carbon::parse($item->incident_date." ".$item->incident_time)->format('h:i A')); ?></td>

                                            <td><?php echo e($item->user->name); ?> (<small><?php echo e($item->user->company->title); ?></small>)</td>
                                            <td>
                                                <?php if($item->assignmentcurrent[0]->assignment->assignment_type_id == 1): ?>
                                                    --
                                                <?php else: ?>
                                                    <?php echo e($item->assignmentcurrent[0]->assignment->fromUser->name); ?> (<small><?php echo e($item->assignmentcurrent[0]->assignment->fromUser->company->title); ?></small>)
                                                <?php endif; ?>
                                            </td>

                                            <td><?php echo e($item->assignmentcurrent[0]->assignment->toUser->name); ?> (<small><?php echo e($item->assignmentcurrent[0]->assignment->toUser->company->title); ?></small>)</td>

                                            <td><?php echo e($item->incidentSource->title ?? ""); ?></td>
                                            <td><?php echo e($item->assignmentCurrent[0]->assignment->assignmentType->title ?? ""); ?></td>

                                            <td><span class="badge badge-<?php echo e($item->priority->badge_class); ?>"><?php echo e($item->priority->title ?? ""); ?></span></td>
                                            <td>

                                                <?php $ssn = 1 ?>
                                                <?php $__currentLoopData = $item->incidentMotives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="-badge -badge-primary -badge-pill"><small><?php echo e($ssn++); ?>. <?php echo e($m->title); ?></small></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </td>

                                            <td>
                                                
                                                <span class="badge badge-<?php echo e($item->currentStatus[0]->statusHistory->incidentStatus->bg_class); ?>">
                                                    <?php echo e($item->currentStatus[0]->statusHistory->incidentStatus->title); ?>

                                                </span>
                                            </td>
                                            <td>

                                                <?php

                                                    $total_req_users = 0;
                                                    $completed_req_users = 0;
                                                    foreach($item->requests as $req){
                                                        $thisReqUsers = $req->requestUsers;
                                                        $total_req_users += $thisReqUsers->count();

                                                        if($thisReqUsers->count() > 0){
                                                            $completed_req_users += $thisReqUsers->where('status', 'completed')->count();
                                                        }
                                                    }

                                                    // echo $total_req_users."/".$completed_req_users;
                                                    $percent = 0;
                                                    if($total_req_users > 0){
                                                        $percent = round(($completed_req_users/$total_req_users)*100);
                                                    }

                                                ?>

                                                <?php if($total_req_users > 0): ?>
                                                    <span style="font-size: 11px; font-weight: bold"><?php echo e($completed_req_users); ?> / <?php echo e($total_req_users); ?> (<?php echo e($percent); ?>%)</span><br>

                                                    <div class="progress mb-3" style="height: 0.375rem;">
                                                        <div class="progress-bar bg-success" style="width: <?php echo e($percent); ?>%">
                                                            <span class="sr-only"><?php echo e($percent); ?>% Complete</span>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <code>n/a</code>
                                                <?php endif; ?>
                                            </td>


                                            <td class="hide_in_print">
                                                <a href="<?php echo e(route('ir.incident.profile', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="btn btn-sm btn-success">
                                                    <i class="icon-arrow-right16"></i>
                                                </a>
                                            </td>



                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>




                    <div class="row mt-2">
                        <div class="col-md-12">
                            <a href="javascript:void(0)" class="btn btn-success btn-sm" onclick="$('.printable').printThis({importCSS: true, loadCSS: '<?php echo asset('assets/css/print.css'); ?>'});">
                                <i class="icon-printer mr-1"></i> Print Report
                            </a>
                        </div>
                    </div>


                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/reports/incidents_by_spectrum.blade.php ENDPATH**/ ?>