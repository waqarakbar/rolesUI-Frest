<!-- Disabled keyboard interaction -->
<div id="poiStatusUpdate" class="modal fade" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-l-g">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update PoI Status</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST" action="<?php echo e(route('ir.poi-status-update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="incident_id" value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">
                    <input type="hidden" name="person_id" id="poisu_person_id" value="">




                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo Form::label('poi_status_id', 'Select Status ', ['class' => 'form-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('poi_status_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('poi_status_id', [null=>'Select a Status']+$poi_statuses->toArray(), NULL, ['class' => 'form-control f-orm-control-select2', 'id' => 'poi_status_id', 'required' => 'required']); ?>

                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo Form::label('status_date', 'Dated ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('status_date'); ?><?php endif; ?></span>
                                <?php echo Form::date('status_date', null, ['class' => 'form-control', 'id' => 'status_date', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-12">

                            <div class="alert alert-info border-0">
                                <div class="form-group">
                                    <?php echo Form::label('attachment', 'Attachment (if any) ', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('attachment'); ?><?php endif; ?></span>
                                    <?php echo Form::file('attachment', null, ['class' => 'form-control', 'id' => 'attachment']); ?>

                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('remarks', 'Remarks ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'required' => 'required', 'rows' => 4]); ?>

                            </div>
                        </div>
                    </div>






                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="icon-arrow-left16 mr-1"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Update Status
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /disabled keyboard interaction -->
<script>
    $(document).ready(function () {
        $('#poiStatusUpdate').on('shown.bs.modal', function (e) {
            // $(".form-control-select2").select2()
            var person_id = $(e.relatedTarget).data('person_id');
            $("#poisu_person_id").val(person_id)
        });

        <?php if(session()->has('errors')): ?>
            $("#poiStatusUpdate").modal("show")
        <?php endif; ?>
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/_partials/poi_status_update_modal.blade.php ENDPATH**/ ?>