<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $(".select2").select2()

        })


    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'method' => $item->exists ? 'put' : 'post',
                                'route' => $item->exists ? ['ir.spectrums.update', \Illuminate\Support\Facades\Crypt::encrypt($item->id)] : ['ir.spectrums.store']
                                ]); ?>



                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('title', 'Spectrum Title ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                        <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('description', 'Description ', ['class' => 'form-label']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                        <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description', 'rows' => 4]); ?>

                                    </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-12">

                                    <a href="<?php echo e(route('ir.spectrums.list')); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Back
                                    </a>

                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="icon-database-check mr-1"></i> Save
                                    </button>

                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/spectrums/form.blade.php ENDPATH**/ ?>