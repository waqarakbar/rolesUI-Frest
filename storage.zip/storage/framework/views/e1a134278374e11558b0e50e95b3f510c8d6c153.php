<!-- Modal -->
<div class="modal fade" id="newField" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Add New <span id="field_type_title_heading"></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?php echo e(route('fm.save-field')); ?>" method="post" enctype="multipart/form-data">

                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="od_form_id" value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">
                <input type="hidden" name="field_group_id" id="field_group_id" value="">
                <input type="hidden" name="field_type_id" id="field_type_id" value="">

                <div class="modal-body">


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('title', 'Field Title ', ['class' => 'form-label req']); ?>

                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('description', 'Details ', ['class' => 'form-label']); ?>

                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description', 'rows' => 3]); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row" id="dropdownListOptionsCont" style="display: none">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <h6>
                                    <strong><u>Dropdown List Options</u></strong>
                                    <a href="#" class="btn btn-xs btn-success" id="newOptionBtn">
                                        <i class="fa fa-plus"></i> New Option
                                    </a>
                                </h6>

                                <div class="row optionCont">
                                    <div class="col-md-10">
                                        <input class="form-control" type="text" name="options[]" disabled placeholder="Dropdown list option">
                                    </div>
                                    <div class="col-md-2">
                                        <a href="#" class="btn btn-xs btn-danger removeOption">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>

                                <div id="appendNewOptionHere"></div>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <label for="is_mandatory">
                                <input type="checkbox" name="is_mandatory" value="yes" id="is_mandatory"> Check if this field is mandatory
                            </label>
                        </div>
                    </div>


                </div>
                <div class="modal-footer">
                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="fa fa-times"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Add Field
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {

        $('#newField').on('show.bs.modal', function(e) {

            // clear the options list
            $("#appendNewOptionHere").html("")

            //get data-id attribute of the clicked element
            var field_type_id = $(e.relatedTarget).data('field_type_id');
            var field_type = $(e.relatedTarget).data('field_type');
            var field_group_id = $(e.relatedTarget).data('field_group_id');

            // show dropdownListOptionsCont if the field_type_id is 6
            if(field_type_id == 6){
                $("#dropdownListOptionsCont").show()
                // add required to all options fields
                $("input[name='options[]']").attr('required', 'required')
                $("input[name='options[]']").removeAttr('disabled')
            }else{
                $("#dropdownListOptionsCont").hide()
                $("input[name='options[]']").removeAttr('required')
                $("input[name='options[]']").attr('disabled', 'disabled')
            }

            console.log(field_type, field_type_id, field_group_id);
            //populate the textbox
            // $(e.currentTarget).find('input[name="bookId"]').val(bookId);
            $(e.currentTarget).find('#field_type_title_heading').html(field_type);
            $(e.currentTarget).find('#field_group_id').val(field_group_id);
            $(e.currentTarget).find('#field_type_id').val(field_type_id);


        });

        // adding new options
        $("#newField").on("click", "#newOptionBtn", function(){
            var optionHtml = '<div class="row optionCont" style="margin-top: 5px">' +
                '<div class="col-md-10">' +
                '<input class="form-control" type="text" name="options[]" required="required" placeholder="Dropdown list option">' +
                '</div>' +
                '<div class="col-md-2">' +
                '<a href="#" class="btn btn-xs btn-danger removeOption"><i class="fa fa-times"></i></a>' +
                '</div>' +
                '</div>'

            $("#appendNewOptionHere").append(optionHtml)
        })

        // remove an option
        $("#newField").on("click", '.removeOption', function(){
            $(this).closest('.optionCont').remove()
        })
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_forms/_partials/new_field_modal.blade.php ENDPATH**/ ?>