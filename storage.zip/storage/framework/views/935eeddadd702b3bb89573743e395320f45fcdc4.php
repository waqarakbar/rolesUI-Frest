<?php $app_id = config('settings.app_id') ?>

<?php $__env->startPush('scripts'); ?>

    <script src="<?php echo e(asset('assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>

    <script type="text/javascript">

        $(document).ready(function () {

            $(".select2").select2()

            $("#company_id").change(function(){
                var company_id = $(this).val()

                // get the sections/units of this company
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.sections-by-company-id')); ?>',
                    data: {
                        company_id: company_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                        <?php if($item->exists): ?>
                        ,section_id: '<?php echo e($item->id); ?>'
                        <?php endif; ?>
                    },
                    success: function(res){
                        // console.log(res)
                        var sections = "<option value>Select <?php echo e(config('settings.section_title')); ?></option>"
                        $.each(res, function(i,v){
                            sections += "<option value='"+i+"'>"+v+"</option>"
                        })
                        $("#section_id").html(sections)
                    }
                })

                // get the users of this company for parent user
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.users-list-by-company-id')); ?>',
                    data: {
                        company_id: company_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                        <?php if($item->exists): ?>
                        ,user_id: '<?php echo e($item->id); ?>'
                        <?php endif; ?>
                    },
                    success: function(res){
                        // console.log(res)
                        var sections = "<option value>This is parent user</option>"
                        $.each(res, function(i,v){
                            sections += "<option value='"+i+"'>"+v+"</option>"
                        })
                        $("#parent_id").html(sections)
                    }
                })

            })




            
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'method' => $item->exists ? 'put' : 'post',
                                'route' => $item->exists ? ['settings.users-mgt.update', \Illuminate\Support\Facades\Crypt::encrypt($item->id)] : ['settings.users-mgt.store']
                                ]); ?>





                            <div class="row">

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('name', 'Title / Name ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('name'); ?><?php endif; ?></span>
                                        <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('email', 'Email Address ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('email'); ?><?php endif; ?></span>
                                        <?php echo Form::email('email', null, ['class' => 'form-control', 'id' => 'email', 'required' => 'required']); ?>

                                    </div>
                                </div>

                            </div>


                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('username', 'Username ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('username'); ?><?php endif; ?></span>
                                        <?php echo Form::text('username', null, ['class' => 'form-control', 'id' => 'username', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-6">

                                    <?php if($item->exists): ?>
                                        <div class="form-group">
                                            <?php echo Form::label('password', 'Password ', ['class' => 'form-label req']); ?>

                                            <span class="help">Leave empty if you don't want to change password. <?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('password'); ?><?php endif; ?></span>
                                            <?php echo Form::text('password', "", ['class' => 'form-control', 'id' => 'password']); ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="form-group">
                                            <?php echo Form::label('password', 'Password ', ['class' => 'form-label req']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('password'); ?><?php endif; ?></span>
                                            <?php echo Form::text('password', null, ['class' => 'form-control', 'id' => 'password', 'required' => 'required']); ?>

                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>




                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('company_id', 'Select '.config('settings.company_title'), ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('company_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('company_id', [null=>'Select '.config('settings.company_title')]+$companies_dd, NULL, ['class' => 'form-control', 'id' => 'company_id', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('section_id', 'Select '.config('settings.section_title'), ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('section_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('section_id', [null=>'Select '.config('settings.section_title')]+$sections->toArray(), NULL, ['class' => 'form-control', 'id' => 'section_id']); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('parent_id', 'Select Parent User ', ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('parent_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('parent_id', [null=>'This is a Parent User']+$parent_users->toArray(), NULL, ['class' => 'form-control', 'id' => 'parent_id']); ?>

                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('role_id[]', 'Select Roles ', ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('role_id[]'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('role_id[]', $roles->toArray(), ($item->exists & $item->roles->count() > 0) ? $item->roles : null, ['class' => 'form-control select2', 'id' => 'role_id[]', 'multiple' => 'multiple']); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('description', 'Details ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                        <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

                                    </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-12">

                                    <a href="<?php echo e(route('settings.my-apps.list')); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Back
                                    </a>

                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="icon-database-check mr-1"></i> Save
                                    </button>

                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/users_mgt/form.blade.php ENDPATH**/ ?>