<!-- Modal -->
<div class="modal fade" id="newFg" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Add New Checklist</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?php echo e(route('ir.closure-configs.save-checklist')); ?>" method="post" enctype="multipart/form-data">

                <?php echo e(csrf_field()); ?>



                <input type="hidden" name="department_type_id" value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">

                <div class="modal-body">


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('title', 'Title of the Checklist ', ['class' => 'form-label req']); ?>

                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('description', 'Description / Details ', ['class' => 'form-label']); ?>

                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

                            </div>
                        </div>
                    </div>



                </div>
                <div class="modal-footer">
                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="fa fa-times"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Add Checklist
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/closure_configs/_partials/new_checklist_modal.blade.php ENDPATH**/ ?>