<!-- Disabled keyboard interaction -->
<div id="addImpact" class="modal fade" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-l-g">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Impact</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST" action="<?php echo e(route('ir.form.closure-step-3-save')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="incident_id" value="<?php echo e($formID); ?>">


                    <div class="row">

                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('impact_type_id', 'Select Impact Type ', ['class' => 'form-label control-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('impact_type_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('impact_type_id', [null=>'Select a Impact Type']+$impact_types->toArray(), NULL, ['class' => 'form-control', 'id' => 'impact_type_id', 'required' => 'required']); ?>

                            </div>
                        </div>


                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('impact_value', 'Value ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('impact_value'); ?><?php endif; ?></span>
                                <?php echo Form::text('impact_value', null, ['class' => 'form-control', 'id' => 'impact_value', 'required' => 'required']); ?>

                            </div>
                        </div>

                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('details', 'Details ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('details'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('details', null, ['class' => 'form-control', 'id' => 'details', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="fa fa-times"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Save Impact
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /disabled keyboard interaction -->
<script>
    $(document).ready(function () {
        // by defualt hid all sections
        <?php if(session()->has('errors')): ?>
            $("#addImpact").modal("show");
        <?php endif; ?>
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/_partials/new_impact_modal.blade.php ENDPATH**/ ?>