<?php $app_id = config('settings.app_id') ?>


<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'method' => $item->exists ? 'put' : 'post',
                                'route' => $item->exists ? ['settings.my-apps.update', \Illuminate\Support\Facades\Crypt::encrypt($item->id)] : ['settings.my-apps.store']
                                ]); ?>



                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('title', 'App Title ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                        <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                                    </div>
                                </div>
                            </div>



                            <div class="row">

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('route', 'App Route ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('route'); ?><?php endif; ?></span>
                                        <?php echo Form::text('route', null, ['class' => 'form-control', 'id' => 'route', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('icon', 'App Icon ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('icon'); ?><?php endif; ?></span>
                                        <?php echo Form::text('icon', null, ['class' => 'form-control', 'id' => 'icon', 'required' => 'required']); ?>

                                    </div>
                                </div>

                            </div>


                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('description', 'Description ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                        <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

                                    </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-12">

                                    <a href="<?php echo e(route('settings.my-apps.list')); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Back
                                    </a>

                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="icon-database-check mr-1"></i> Save
                                    </button>

                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/my_apps/form.blade.php ENDPATH**/ ?>