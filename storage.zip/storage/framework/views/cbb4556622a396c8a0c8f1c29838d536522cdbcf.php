<!-- Disabled keyboard interaction -->
<div id="addRecovery" class="modal fade" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-l-g">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Recovery</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST" action="<?php echo e(route('ir.form.closure-step-1-save')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="incident_id" value="<?php echo e($formID); ?>">



                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('recovery_type_id', 'Select a Type ', ['class' => 'form-label control-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('recovery_type_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('recovery_type_id', [null=>'Select a a Type']+$recovery_types->toArray(), NULL, ['class' => 'form-control', 'id' => 'recovery_type_id', 'required' => 'required']); ?>

                            </div>
                        </div>

                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('title', 'Item Name / Title ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('description', 'Details of the recovery ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description', 'required' => 'required', 'rows' => 4]); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">

                        <div class="col-4">
                            <div class="form-group">
                                <?php echo Form::label('weight', 'Weight ', ['class' => 'form-label']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('weight'); ?><?php endif; ?></span>
                                <?php echo Form::text('weight', null, ['class' => 'form-control', 'id' => 'weight']); ?>

                            </div>
                        </div>

                        <div class="col-4">
                            <div class="form-group">
                                <?php echo Form::label('quantity', 'Quantity ', ['class' => 'form-label ']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('quantity'); ?><?php endif; ?></span>
                                <?php echo Form::text('quantity', null, ['class' => 'form-control', 'id' => 'quantity']); ?>

                            </div>
                        </div>

                        <div class="col-4">
                            <div class="form-group">
                                <?php echo Form::label('worth', 'Approx. Worth ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('worth'); ?><?php endif; ?></span>
                                <?php echo Form::text('worth', null, ['class' => 'form-control', 'id' => 'worth', 'required' => 'required']); ?>

                            </div>
                        </div>

                    </div>



                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="icon-arrow-left16 mr-1"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Save Recovery
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /disabled keyboard interaction -->
<script>
    $(document).ready(function () {
        <?php if(session()->has('errors')): ?>
            $("#addRecovery").modal("show")
        <?php endif; ?>
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/_partials/new_recovery_modal.blade.php ENDPATH**/ ?>