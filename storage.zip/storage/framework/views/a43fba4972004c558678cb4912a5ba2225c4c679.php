<!-- Modal -->
<div class="modal fade" id="newField" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Add Parameter - <span id="field_type_title_heading"></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?php echo e(route('ir.closure-configs.save-parameter')); ?>" method="post" enctype="multipart/form-data">

                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="checklist_id" id="checklist_id" value="">
                <input type="hidden" name="closure_parameter_type_id" id="closure_parameter_type_id" value="">

                <div class="modal-body">


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('title', 'Parameter Title ', ['class' => 'form-label req']); ?>

                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('description', 'Details ', ['class' => 'form-label']); ?>

                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description', 'rows' => 3]); ?>

                            </div>
                        </div>
                    </div>



                </div>
                <div class="modal-footer">
                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="fa fa-times"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Add Parameter
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {

        $('#newField').on('show.bs.modal', function(e) {


            //get data-id attribute of the clicked element
            var field_type_id = $(e.relatedTarget).data('field_type_id');
            var field_type = $(e.relatedTarget).data('field_type');
            var field_group_id = $(e.relatedTarget).data('field_group_id');


            console.log(field_type, field_type_id, field_group_id);
            //populate the textbox
            // $(e.currentTarget).find('input[name="bookId"]').val(bookId);
            $(e.currentTarget).find('#field_type_title_heading').html(field_type);
            $(e.currentTarget).find('#checklist_id').val(field_group_id);
            $(e.currentTarget).find('#closure_parameter_type_id').val(field_type_id);


        });

    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/closure_configs/_partials/new_parameter_modal.blade.php ENDPATH**/ ?>