<?php
    if(isset($app_id)){
        $current_app = \Modules\Settings\Entities\MyApp::find($app_id);
    }else{
        $current_app = null;
    }

    if(!isset($user)) $user = \Illuminate\Support\Facades\Auth::user();
?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(env('APP_NAME')); ?> :: <?php echo e($title ?? ""); ?></title>

    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet"
          type="text/css">
    <link href="<?php echo e(asset('assets/css/icons/fontawesome/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/icons/icomoon/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/layout.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/my_custom.css')); ?>" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->

    <!-- Core JS files -->
    <script src="<?php echo e(asset('assets/js/main/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
    <!-- /core JS files -->

    <!-- Theme JS files -->
    <script src="<?php echo e(asset('assets/js/plugins/visualization/d3/d3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/visualization/d3/d3_tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/forms/styling/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/forms/selects/bootstrap_multiselect.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/ui/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/pickers/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
    <!-- /theme JS files -->

    <script type="text/javascript">
        $(document).ready(function () {
            $(".delete").click(function (e) {
                return confirm('Are you sure you want to delete?')
            })
        })

        $(document).ready(function () {
            $.each($(".req"), function(i, j){
                var label = $(this).html();
                $(this).html(label+" <span class='starik' style='color:red;font-size:11px;'>*</span>");
            })

        });

        $(document).ready(function () {
            $(".data_mf_table").dataTable()
        })
    </script>

    <?php echo $__env->yieldPushContent('stylesheets'); ?>
    <style>
        .wizard-form .steps{
        background: #F5F5F5;
    }
    .wizard-form .actions{
        display: none;
    }
    .wizard>.steps>ul>li.current .number{
        border-color: #46A24A;
        color: #46A24A;
    }
    .wizard>.steps>ul>li.current>a{
        color: #46A24A;
    }
    .wizard>.steps>ul>li.done .number{
        background-color: #46A24A;
        border-color: #46A24A;
    }
    .wizard>.steps>ul>li:after,
    .wizard>.steps>ul>li:before{
        background-color: #46A24A;
    }
    .wizard-form .content{
        /* border: 1px solid #46A24A; */
        margin: 0px;
        padding-top: 10px;
        box-shadow: 0 1px 10px rgb(0 0 0 / 5%);
    }

    .wizard-form .content .form-control,
    .wizard-form .content .select2-selection--single:not([class*=bg-]):not([class*=border-]),
    .modal .form-control,
    .modal .select2-selection--single:not([class*=bg-]):not([class*=border-]){
        background: #f5f5f5;
    }

    .wizard-form .content label{
        color: #46A24A;
        font-weight: 500;
    }

    .wizard-form .content label[class^="form"]{
        color: unset;
        font-weight: unset;
    }
    .wizard-form fieldset{
        min-height: 240px;
    }
    .custom-nav ul{
        padding: 0px;
        list-style: none;
        margin: 0px;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        border: 1px solid #eee;
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
        overflow: hidden;
        margin-top: 30px;
    }

    .custom-nav ul li a{ color: #999; }
    .custom-nav ul li{
        width: 100%;
        background: white;
        text-align: center;
        padding: 10px;
        font-size: 1rem;
        border-left: 1px solid #eee;
        border-right: 1px solid #eee;
    }
    .custom-nav ul li:first-child{border-left: unset;}
    .custom-nav ul li:last-child{border-right: unset;}
    .custom-nav ul li.active{
        background: #46A24A;
    }
    .custom-nav ul li.active::before{
        content: "";
        font-family: icomoon;
        display: inline-block;
        font-size: 1rem;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        transition: all ease-in-out .15s;
        color: white;
        margin-right: 5px;
    }
    .custom-nav ul li.active a{
        color: white;
    }
    @media(max-width: 768px){
        .wizard-form .steps > ul {
            display: none;
        }
        .wizard-form .custom-nav ul{
            margin-top: unset;
        }
    }
    </style>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</head>

<body>

<!-- Main navbar -->
<div class="navbar navbar-expand-md navbar-dark" style="background-color: #<?php echo e(env('GREEN')); ?>">
    <div class="navbar-brand wmin-200" style="padding: 0px;margin: 0px;">
        <a href="/" class="d-inline-block" style="font-size: 26px; color: #fff; padding-top: 9px;">
            
            <img src="<?php echo e(asset('assets/images/logo_white.svg')); ?>" alt="" style="width: 70px; height: auto; display: inline-block">
            <?php echo e(env('APP_ABBR')); ?>

        </a>
    </div>

    <div class="d-md-none">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-mobile">
            
            <i class="icon-user"></i>
            <i class="icon-chevron-down"></i>
        </button>
        <button class="navbar-toggler sidebar-mobile-main-toggle" type="button">
            <i class="icon-paragraph-justify3"></i>
        </button>
    </div>

    <div class="collapse navbar-collapse" id="navbar-mobile">
        <ul class="navbar-nav">
            <li class="nav-item">
                
            </li>


        </ul>

        <span class="b-adge b-g-success-400 ml-md-auto mr-md-3"></span>

        <ul class="navbar-nav">


            <li class="nav-item dropdown dropdown-user">
                <a href="#" class="navbar-nav-link d-flex align-items-center dropdown-toggle" data-toggle="dropdown">
                    <img src="<?php echo e(asset('assets/images/placeholders/admin2.jpeg')); ?>" class="rounded-circle mr-2"
                         height="34" alt="">
                    <span><?php echo e($user->name); ?></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right">
                    <a href="<?php echo e(route('settings.users-mgt.my-profile')); ?>" class="dropdown-item"><i class="icon-user-plus"></i> My profile</a>
                    
                    <a href="<?php echo e(route('settings.users-mgt.change-password')); ?>" class="dropdown-item"><i class="icon-cog5"></i> Change Password</a>

                    
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="icon-switch2"></i> <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>

                </div>
            </li>
        </ul>
    </div>
</div>
<!-- /main navbar -->


<!-- Page header -->
<div class="page-header">
    <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
        <div class="d-flex">

            <div class="breadcrumb">
                <a href="<?php echo e(route('app.landing-screen')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>

                <?php if(isset($current_app)): ?>
                    <span class="breadcrumb-item">
                    <a href="<?php echo e(url($current_app->route)); ?>">
                    <?php echo e($current_app->title ?? ''); ?>

                    </a>
                </span>
                <?php endif; ?>

                <?php if(isset($back_route)): ?>
                    <?php if(isset($back_route[2])): ?>
                        <span class="breadcrumb-item">
                        <a href="<?php echo e($back_route[0]); ?>">
                        <?php echo e($back_route[1]); ?>

                        </a>
                    </span>
                    <?php else: ?>
                        <span class="breadcrumb-item">
                        <a href="<?php echo e(route($back_route[0])); ?>">
                        <?php echo e($back_route[1]); ?>

                        </a>
                    </span>
                    <?php endif; ?>

                <?php endif; ?>

                <span class="breadcrumb-item active"><?php echo e($title ?? ""); ?></span>

            </div>

            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>

        <div class="header-elements d-none">
            
        </div>
    </div>

    <div class="page-header-content header-elements-md-inline">
        <div class="page-title d-flex" style="padding: 1rem 0;">
            <h4>
                <a href="<?php echo e(route('app.landing-screen')); ?>">
                    <i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Home</span>
                </a> -

                <?php if(isset($current_app)): ?>
                    <a href="<?php echo e(url($current_app->route)); ?>">
                        <?php echo e($current_app->title ?? ''); ?>

                    </a> -
                <?php endif; ?>

                <?php echo e($title ?? ''); ?>

            </h4>
            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>


        <?php echo $__env->make('layouts._partials.page_actions', ['back_route' => $back_route ?? null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
</div>
<!-- /page header -->


<!-- Page content -->
<div class="page-content pt-0">

    <!-- Main sidebar -->
    <div class="sidebar sidebar-light sidebar-main sidebar-expand-md align-self-start">

        <!-- Sidebar mobile toggler -->
        <div class="sidebar-mobile-toggler text-center">
            <a href="#" class="sidebar-mobile-main-toggle">
                <i class="icon-arrow-left8"></i>
            </a>
            <span class="font-weight-semibold">Main sidebar</span>
            <a href="#" class="sidebar-mobile-expand">
                <i class="icon-screen-full"></i>
                <i class="icon-screen-normal"></i>
            </a>
        </div>
        <!-- /sidebar mobile toggler -->


        <!-- Sidebar content -->
        <div class="sidebar-content">
            <div class="card card-sidebar-mobile">

                <!-- Header -->
                <div class="card-header header-elements-inline">
                    <h6 class="card-title">Navigation</h6>
                    <div class="header-elements">
                        <div class="list-icons">

                            

                            <a href="#"
                               class="list-icons-item navbar-nav-link sidebar-control sidebar-main-toggle d-none d-md-block "
                               style="padding: 0">
                                <i class="icon-transmission"></i>
                            </a>

                        </div>
                    </div>
                </div>

                <!-- User menu -->
                <div class="sidebar-user">
                    <div class="card-body">
                        <div class="media">
                            <div class="mr-3">
                                <a href="#"><img src="<?php echo e(asset('assets/images/placeholders/admin2.jpeg')); ?>" width="38"
                                                 height="38" class="rounded-circle" alt=""
                                                 style="border: 1px solid #ccc"></a>
                            </div>

                            <div class="media-body">
                                <div class="media-title font-weight-semibold"><?php echo e($user->name); ?></div>
                                <div class="font-size-xs opacity-50">
                                    <i class="icon-pin font-size-sm"></i> &nbsp;Khyber Pakhtunkhwa
                                </div>
                            </div>

                            <div class="ml-3 align-self-center">
                                <a href="#" class="text-white"><i class="icon-cog3"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /user menu -->


                <!-- Main navigation -->
                <div class="card-body p-0">
                    <ul class="nav nav-sidebar" data-nav-type="accordion">

                    <?php

                        $user_role_ids = [0];
                        foreach($user->roles as $ur){
                            $user_role_ids[] = $ur->id;
                        }

                        // menu of this app assigned to this user and roles
                        $menu_r = \Modules\Settings\Entities\Menu::with([
                            'myPermissions' => function($q) use ($user_role_ids, $user){
                                $q->with([
                                    'routes' => function($q) use ($user_role_ids, $user){
                                        $q->where('is_default', '=', 'yes');
                                    }
                                ])
                                ->where('show_in_menu', '=', 'yes')

                                ->whereRaw("id in (
                                        SELECT permission_id FROM permission_role WHERE role_id in (".implode(",", $user_role_ids).")
                                    )"
                                )->orWhereRaw("id in (
                                        SELECT permission_id FROM permission_user WHERE user_id in (".$user->id.")
                                    )");

                            }
                        ])->whereHas('myPermissions', function($q) use ($user_role_ids, $user){
                            $q->whereRaw("id in (
                                        SELECT permission_id FROM permission_role WHERE role_id in (".implode(",", $user_role_ids).")
                                    )"
                            )->orWhereRaw("id in (
                                        SELECT permission_id FROM permission_user WHERE user_id in (".$user->id.")
                                    )");
                        })->where('app_id', '=', $current_app->id)->get();
                        // dd($menu_r->toSql());
                    ?>

                    <!-- Main -->
                        <li class="nav-item-header mt-0">
                            <div class="text-uppercase font-size-xs line-height-xs">
                                <hr>
                            </div>
                            <i class="icon-menu" title="Main"></i></li>

                        <li class="nav-item">
                            <a href="<?php echo e(url($current_app->route)); ?>" class="nav-link active">
                                <i class="icon-home4"></i>
                                <span>
										Dashboard
										
									</span>
                            </a>
                        </li>

                        <?php $__currentLoopData = $menu_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item nav-item-submenu">
                                <a href="#" class="nav-link"><i class="<?php echo e($menu->icon); ?>"></i>
                                    <span><?php echo e($menu->title); ?></span></a>
                                <ul class="nav nav-group-sub" data-submenu-title="Layouts">
                                    <?php $__currentLoopData = $menu->myPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $mp->routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item"><a href="<?php echo e(route($mpr->route)); ?>" class="nav-link"><?php echo e($mpr->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    

                    <!-- /layout -->

                    </ul>
                </div>
                <!-- /main navigation -->

            </div>
        </div>
        <!-- /sidebar content -->

    </div>
    <!-- /main sidebar -->


    <!-- Main content -->
    <div class="content-wrapper">

        <!-- Content area -->
        <div class="content">

            <!-- Main charts -->
        
        <!-- /main charts -->

            <div class="row">
                <div class="col-12">
                    <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                        <div class="alert alert-danger alert-styled-left alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                            <span
                                class="font-weight-semibold">Error! </span> <?php echo e(\Illuminate\Support\Facades\Session::get('error')); ?>

                            .
                        </div>
                    <?php endif; ?>

                    <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                        <div class="alert alert-success alert-styled-left alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                            <span
                                class="font-weight-semibold">Success! </span> <?php echo e(\Illuminate\Support\Facades\Session::get('success')); ?>

                            .
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo $__env->yieldContent('content'); ?>


        </div>
        <!-- /content area -->

    </div>
    <!-- /main content -->

</div>
<!-- /page content -->


<!-- Footer -->
<div class="navbar navbar-expand-lg navbar-light">
    <div class="text-center d-lg-none w-100">
        <button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse"
                data-target="#navbar-footer">
            <i class="icon-unfold mr-2"></i>
            Footer
        </button>
    </div>

    <div class="navbar-collapse collapse" id="navbar-footer">
			<span class="navbar-text">
				&copy; <?php echo e(date("Y")); ?>. <a href="#"><?php echo e(env('APP_ABBR')); ?></a> by <a href="#"
                                                                                 target="_blank">PMRU</a>
			</span>

    </div>
</div>
<!-- /footer -->


 <!-- Theme JS Form files -->
 <script src="<?php echo e(asset('assets/js/plugins/forms/wizards/steps.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/plugins/forms/inputs/inputmask.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/plugins/forms/validation/validate.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/plugins/extensions/cookie.js')); ?>"></script>

 <?php echo $__env->yieldPushContent('scripts-bottom'); ?>

 <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/demo_pages/form_wizard.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/demo_pages/dashboard.js')); ?>"></script>
 <!-- /theme JS files -->

 <script>
    $(function(){
        $('.form-control-select2').select2();


        // Custom links development
        if( $('form.wizard-form').html() != undefined ) {

            var formID = $('form.wizard-form').data('id');
            var links = [];

            $('.steps ul:first').removeAttr('role');
            $('.steps ul:first li').each(function(i,v){

                // Remove Default Behaviour
                $(v).find('a').removeAttr('id');
                $(v).find('a').removeAttr('aria-controls');
                $(v).removeAttr('role');
                $(v).removeAttr('aria-disabled');
                $(v).removeAttr('aria-selected');

                $(v).addClass('custom-link');

                if( formID == undefined || formID == 0) {
                    hrf = "javascript: void(0);"
                    $(v).find('a').off("click").attr('href', hrf);
                    $(v).find('a').attr('title', "Not Allowed! Complete General info then continue.");
                } else {
                    var hrf = $.trim($(v).find('.step-link').html());
                    $(v).find('a').attr('href', hrf);
                }

                links.push({
                    title: $.trim($(v).find('span.step-title').text()),
                    icon: $.trim($(v).find('span.step-icon').html()),
                    href: hrf,
                    active: $(v).hasClass('current')
                })
            })

            if( links.length > 0) {
                htm = `<div class="custom-nav"><ul>`;
                $.each(links, function(i,li){
                    hrf = `<a href="${li.href}">${li.title}</a>`;
                    htm += `<li class="${li.active ? 'active' : ''}">${hrf}</li>`
                })
                htm += `</ul></div>`;
                $('form.wizard-form:first .steps:first').append(htm);
            }

        }

        /** Wizard custom link click event */
        $('.custom-link a').click(function(e){
            var hrf = $(this).attr('href');
            e.preventDefault();
            e.stopPropagation();
            if( hrf != undefined) {
                window.location.href = hrf;
            }
        })
    })
</script>

</body>
</html>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/resources/views/layouts/app_screen_l3.blade.php ENDPATH**/ ?>