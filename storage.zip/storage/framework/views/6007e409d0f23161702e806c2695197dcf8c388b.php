<div class="row">
    <div class="col-12">

        <!-- Traffic sources -->
        <div class="card">
            <div class="card-header header-elements-inline">
                <h5 class="card-title"><?php if(isset($od_request)): ?> <strong><u><?php echo e($od_request->form->title); ?></u></strong>
                    for <?php endif; ?> <em>Mobility</em></h5>
                <div class="header-elements">
                    <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                    </div>
                </div>
            </div>

            <div class="card-body">


                <h5><strong>Type: </strong><?php echo e($entity->mobilityType->title ?? ""); ?></h5>
                <p>

                    <?php if($entity->mobility_type_id == 1): ?>

                        <span>
                            <strong><?php echo e($entity->vehicleBrand->title); ?> (<?php echo e($entity->vehicleType->title); ?> <?php echo e($entity->vehicle_model); ?>) | Color: <?php echo e($entity->color); ?></strong> <br>
                            <strong>Registration Status: </strong> <?php echo e($entity->vehicle_registration_status); ?> <?php echo e($entity->vehicle_registration_no); ?> / <strong>Chassis No.:</strong> <?php echo e($entity->vehicle_chassis_no); ?> (Chassis Tempered: <?php echo e($entity->vehicle_chassis_tempered); ?>)
                        </span>

                    <?php elseif($entity->mobility_type_id == 2): ?>

                        <span>
                            <strong>Flight Type: </strong> <?php echo e($entity->flight_type); ?> | <strong>Flight No.: </strong> <?php echo e($entity->flight_no); ?> <br>
                            <strong>Airport: </strong> <?php echo e($entity->airport_name); ?> (<?php echo e($entity->flightOriginCountry->title); ?> to <?php echo e($entity->flighpestinationCountry->title); ?>)
                        </span>

                    <?php elseif($entity->mobility_type_id == 3): ?>

                        <span>
                            <strong>Shipping Company: </strong> <?php echo e($entity->shipping_company); ?> | <strong>Container No.:</strong> <?php echo e($entity->container_no); ?>

                        </span>

                    <?php elseif($entity->mobility_type_id == 4): ?>

                        <span>
                            <strong>Courier Company: </strong> <?php echo e($entity->courier_name); ?> <br>
                            <strong>From: </strong><?php echo e($entity->courier_origin_details); ?> <br>
                            <strong>To: </strong><?php echo e($entity->courier_destination_details); ?>

                        </span>

                    <?php elseif($entity->mobility_type_id == 5): ?>

                        <span>
                            <strong>Gadget Type: </strong> <?php echo e($entity->gadgettype->title ?? ""); ?> - <?php echo e($entity->gadget_manufacturer); ?> (SR No. <?php echo e($entity->gadget_serial_no); ?>) <br>
                            <strong>IMEI No.:</strong> <?php if(is_null($entity->imei_no)): ?> <code>n/a</code> <?php else: ?> <?php echo e($entity->imei_no); ?> <?php endif; ?>
                        </span>

                    <?php endif; ?>

                </p>
                <p><?php echo e($entity->route_details); ?></p>
                <p>
                    <strong>Details: </strong><br>
                    <?php echo e($entity->other_details); ?>

                </p>

            </div>

        </div>
    </div>
</div>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_requests/_partials/mobility_entity.blade.php ENDPATH**/ ?>