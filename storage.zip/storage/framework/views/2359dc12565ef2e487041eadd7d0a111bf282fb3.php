<!-- Disabled keyboard interaction -->
<div id="addMobility" class="modal fade" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-l-g">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Mobility</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST" action="<?php echo e(route('ir.form.step5-save')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="incident_id" value="<?php echo e($formID); ?>">

                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('mobility_type_id', 'Select Mobility Type ', ['class' => 'form-label control-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('mobility_type_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('mobility_type_id', [null=>'Select a Mobility Type']+$mobility_types->toArray(), NULL, ['class' => 'form-control', 'id' => 'mobility_type_id', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>





                    <!-- vehicle details -->
                    <div id="mobility_1" class="mobility_form_section">

                        <div class="row">

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_brand_id', 'Vehicle Brand ', ['class' => 'form-label']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('vehicle_brand_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('vehicle_brand_id', [null=>'Select a Brand']+$vehicle_brands->toArray(), NULL, ['class' => 'form-control', 'id' => 'vehicle_brand_id']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_type_id', 'Vehicle Type ', ['class' => 'form-label req']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('vehicle_type_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('vehicle_type_id', [null=>'Select a Type']+$vehicle_types->toArray(), NULL, ['class' => 'form-control', 'id' => 'vehicle_type_id', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_model', 'Model Year', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('vehicle_model'); ?><?php endif; ?></span>
                                    <?php echo Form::number('vehicle_model', null, ['class' => 'form-control', 'id' => 'vehicle_model', 'min' => '1900', 'max' => date("Y")]); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_color', 'Color ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('vehicle_color'); ?><?php endif; ?></span>
                                    <?php echo Form::text('vehicle_color', null, ['class' => 'form-control', 'id' => 'vehicle_color', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_registration_status', 'Registration Status', ['class' => 'form-label']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('vehicle_registration_status'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('vehicle_registration_status', [
                                        null=>'Select a Registration Status',
                                        'registered' => 'Registered',
                                        'non registered' => 'Not Registered',
                                        'NCP' => 'NCP',
                                        'theft' => 'Theft / Stolen'
                                    ], NULL, ['class' => 'form-control', 'id' => 'vehicle_registration_status']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_registration_no', 'Registration No. ', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('vehicle_registration_no'); ?><?php endif; ?></span>
                                    <?php echo Form::text('vehicle_registration_no', null, ['class' => 'form-control', 'id' => 'vehicle_registration_no']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_chassis_no', 'Chassis No. ', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('vehicle_chassis_no'); ?><?php endif; ?></span>
                                    <?php echo Form::text('vehicle_chassis_no', null, ['class' => 'form-control', 'id' => 'vehicle_chassis_no']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('vehicle_chassis_tempered', 'Select Chassis Number Status ', ['class' => 'form-label']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('vehicle_chassis_tempered'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('vehicle_chassis_tempered', [null=>'Select Chassis Status', 'yes' => 'Chassis is Tempered', 'no' => 'Chassis is not Tempered'], NULL, ['class' => 'form-control', 'id' => 'vehicle_chassis_tempered']); ?>

                                </div>
                            </div>
                        </div>

                    </div>



                    <!-- flight details -->
                    <div id="mobility_2" class="mobility_form_section">

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('flight_type', 'Select FLight Type ', ['class' => 'form-label req']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('flight_type'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('flight_type', [null=>'Select a FLight Type', 'domestic' => 'Domestic', 'international' => 'International'], NULL, ['class' => 'form-control', 'id' => 'flight_type', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('airport_name', 'Airport Name ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('airport_name'); ?><?php endif; ?></span>
                                    <?php echo Form::text('airport_name', null, ['class' => 'form-control', 'id' => 'airport_name', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('flight_no', 'Flight Number ', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('flight_no'); ?><?php endif; ?></span>
                                    <?php echo Form::text('flight_no', null, ['class' => 'form-control', 'id' => 'flight_no']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('origin_country_id', 'Origin Country ', ['class' => 'form-label']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('origin_country_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('origin_country_id', [null=>'Select origin country ']+$countries->toArray(), NULL, ['class' => 'form-control', 'id' => 'origin_country_id']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('destination_country_id', 'Destination Country ', ['class' => 'form-label']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('destination_country_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('destination_country_id', [null=>'Select a Destinatin Country']+$countries->toArray(), NULL, ['class' => 'form-control', 'id' => 'destination_country_id']); ?>

                                </div>
                            </div>

                        </div>

                    </div>


                    <!-- cargo details -->
                    <div id="mobility_3" class="mobility_form_section">

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('shipping_company', 'Shipping Company ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('shipping_company'); ?><?php endif; ?></span>
                                    <?php echo Form::text('shipping_company', null, ['class' => 'form-control', 'id' => 'shipping_company', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('shipping_agent', 'Shipping Agent ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('shipping_agent'); ?><?php endif; ?></span>
                                    <?php echo Form::text('shipping_agent', null, ['class' => 'form-control', 'id' => 'shipping_agent', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('clearing_agent', 'Clearing Agent ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('clearing_agent'); ?><?php endif; ?></span>
                                    <?php echo Form::text('clearing_agent', null, ['class' => 'form-control', 'id' => 'clearing_agent', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('container_no', 'Container Number ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('container_no'); ?><?php endif; ?></span>
                                    <?php echo Form::text('container_no', null, ['class' => 'form-control', 'id' => 'container_no', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>

                    </div>



                    <!-- courier details -->
                    <div id="mobility_4" class="mobility_form_section">

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('courier_name', 'Courier Name ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('courier_name'); ?><?php endif; ?></span>
                                    <?php echo Form::text('courier_name', null, ['class' => 'form-control', 'id' => 'courier_name', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('courier_origin_details', 'Courier Origin Details ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('courier_origin_details'); ?><?php endif; ?></span>
                                    <?php echo Form::textarea('courier_origin_details', null, ['class' => 'form-control', 'id' => 'courier_origin_details', 'rows' => 4, 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('courier_destination_details', 'Courier Destination Details ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('courier_destination_details'); ?><?php endif; ?></span>
                                    <?php echo Form::textarea('courier_destination_details', null, ['class' => 'form-control', 'id' => 'courier_destination_details', 'rows' => 4, 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>


                    </div>



                    <!-- gadget details -->
                    <div id="mobility_5" class="mobility_form_section">

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('gadget_type_id', 'Select Gadget Type ', ['class' => 'form-label req']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('gadget_type_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('gadget_type_id', [null=>'Select a Gadget Type']+$gadget_types->toArray(), NULL, ['class' => 'form-control', 'id' => 'gadget_type_id', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('gadget_manufacturer', 'Manufacturer Name ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('gadget_manufacturer'); ?><?php endif; ?></span>
                                    <?php echo Form::text('gadget_manufacturer', null, ['class' => 'form-control', 'id' => 'gadget_manufacturer', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('gadget_serial_no', 'Serial Number ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('gadget_serial_no'); ?><?php endif; ?></span>
                                    <?php echo Form::text('gadget_serial_no', null, ['class' => 'form-control', 'id' => 'gadget_serial_no', 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('gadget_imei_no', 'IMEI Number ', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('gadget_imei_no'); ?><?php endif; ?></span>
                                    <?php echo Form::text('gadget_imei_no', null, ['class' => 'form-control', 'id' => 'gadget_imei_no']); ?>

                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('gadget_mac_address', 'MAC Address ', ['class' => 'form-label']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('gadget_mac_address'); ?><?php endif; ?></span>
                                    <?php echo Form::text('gadget_mac_address', null, ['class' => 'form-control', 'id' => 'gadget_mac_address']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('gadget_other_info', 'Gadget Additional Info ', ['class' => 'form-label req']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('gadget_other_info'); ?><?php endif; ?></span>
                                    <?php echo Form::textarea('gadget_other_info', null, ['class' => 'form-control', 'id' => 'gadget_other_info', 'rows' => 4, 'rel' => 'cond_req']); ?>

                                </div>
                            </div>
                        </div>

                    </div>



                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('route_details', 'Route Details ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('route_details'); ?><?php endif; ?></span>
                                <?php echo Form::text('route_details', null, ['class' => 'form-control', 'id' => 'route_details', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('other_details', 'Description ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('other_details'); ?> <?php endif; ?></span>
                                <?php echo Form::textarea('other_details', null, ['class' => 'form-control', 'id' => 'other_details', 'rows' => 5, 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="icon-arrow-left16 mr-1"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-success">
                                <i class="fa fas fa-save mr-1"></i> Save Mobility
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /disabled keyboard interaction -->
<script>
    $(document).ready(function () {
        // by defualt hid all sections
        $(".mobility_form_section").hide();

        $("#mobility_type_id").change(function(){
            var id = $(this).val();
            $(".mobility_form_section").hide();

            // remove all required attribute
            $(".mobility_form_section input").removeAttr("required")
            $(".mobility_form_section textarea").removeAttr("required")
            $(".mobility_form_section select").removeAttr("required")

            $("#mobility_"+id).show();
            $("#mobility_"+id+" input[rel='cond_req']").attr("required", "required")
            $("#mobility_"+id+" textarea[rel='cond_req']").attr("required", "required")
            $("#mobility_"+id+" select[rel='cond_req']").attr("required", "required")
        })

        <?php if(session()->has('errors')): ?>
            $("#addMobility").modal("show")
            $("#mobility_type_id").val("<?php echo e(old('mobility_type_id')); ?>").trigger('change')
        <?php endif; ?>
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/_partials/new_mobility_modal.blade.php ENDPATH**/ ?>