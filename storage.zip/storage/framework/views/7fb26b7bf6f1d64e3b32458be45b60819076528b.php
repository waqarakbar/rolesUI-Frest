<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    <link href="<?php echo e(asset('assets/ext_plugins/uniform_3/css/default.css')); ?>" rel="stylesheet" type="text/css"/>
    <style>
        .card {
            border: unset;
            box-shadow: unset;
        }
        .uniform-checker{
            display: inline;
        }

        input:disabled, textarea:disabled {
            background-color: #ebebeb !important;
            cursor: not-allowed;
        }
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Evidences / Attachments -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => ['ir.form.closure-step-2-save', $formID],
                                'data-id' => $formID,
                                'data-fouc',
                                'enctype' => 'multipart/form-data'
                            ]); ?>


                            <input type="hidden" name="incident_id" value="<?php echo e($formID); ?>">

                            <h6>
                                <span class="step-title">
                                    Recoveries
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>






                            <h6>
                                <span class="step-title">Incident Closure</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">


                                <?php if($item->closures()->count() <= 0): ?>
                                <div class="row">

                                    <div class="col-6">
                                        <div class="form-group">
                                            <?php echo Form::label('company_type_id', 'Select Department Type ', ['class' => 'control-label req']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('company_type_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('company_type_id', [null=>'Select a Department Type']+$department_types->toArray(), NULL, ['class' => 'form-control form-control-select2', 'id' => 'company_type_id', 'required' => 'required']); ?>

                                        </div>
                                    </div>


                                    <div class="col-6">
                                        <div class="form-group">
                                            <?php echo Form::label('closure_date', 'Closure Date ', ['class' => 'control-label req']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('closure_date'); ?><?php endif; ?></span>
                                            <?php echo Form::date('closure_date', null, ['class' => 'form-control', 'id' => 'closure_date', 'required' => 'required']); ?>

                                        </div>
                                    </div>

                                </div>


                                <div id="theFormHere"></div>


                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <?php echo Form::label('remarks', 'Details ', ['class' => 'control-label req']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                            <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                </div>

                                <?php else: ?>

                                    <div class="row">
                                        <div class="col-12">

                                            <div class="alert alert-success">
                                                <h6><strong>Incident Closed</strong></h6>

                                                <p>This incident has been closed by <strong><?php echo e($item->closures[0]->user->name); ?></strong> (<?php echo e($item->closures[0]->user->company->title); ?>) on <strong><?php echo e(date("d/M/Y", strtotime($item->closures[0]->closure_date))); ?></strong>
                                                </p>

                                                <p style="font-size: 11px">
                                                    <strong>Closure Remarks</strong><br>
                                                    <?php echo e($item->closures[0]->remarks); ?>

                                                </p>
                                            </div>

                                        </div>
                                    </div>

                                    <h5><strong><u>Closure Data</u></strong>
                                        <a href="<?php echo e(route('ir.form.remove-closure-data', ['id' => $formID])); ?>" class="-btn -btn-danger btn-sm text-danger" onclick="return confirm('Are you sure you want to re-open the incident? All the closure data will be removed. ');">
                                            <strong><i class="fa fa-undo"></i> Re-open the incident</strong>
                                        </a>
                                    </h5>
                                    <?php $sn = 1 ?>
                                    <?php $__currentLoopData = $item->closures[0]->closureStepData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stepd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="row mb-3">
                                            <div class="col-12">
                                                <h6><strong><i class="icon-checkbox-checked2 text-success"></i> <?php echo e($stepd->closure_step_title); ?></strong></h6>

                                                <?php $snn = 1 ?>
                                                <?php $__currentLoopData = $stepd->closureStepParameterData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paramd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div style="padding-left: 15px;">
                                                        <strong><?php echo e($snn); ?>.  <?php echo e($paramd->closure_step_parameter_title); ?>: </strong>
                                                        <?php if(in_array($paramd->closure_parameter_type_id, [1,2,6])): ?>
                                                            <?php echo e($paramd->parameter_value); ?>

                                                        <?php elseif(in_array($paramd->closure_parameter_type_id, [3])): ?>
                                                            <?php echo e(date("d/M/Y", strtotime($paramd->parameter_value))); ?>

                                                        <?php elseif(in_array($paramd->closure_parameter_type_id, [4])): ?>
                                                            <?php echo e(date("h:i A", strtotime($paramd->parameter_value))); ?>

                                                        <?php elseif(in_array($paramd->closure_parameter_type_id, [5])): ?>
                                                            <a href="<?php echo e(asset('uploads/incident_closure_files/'.$paramd->parameter_value)); ?>" target="_blank">
                                                                <i class="fa fa-paperclip"></i> Attachment
                                                            </a>
                                                        <?php endif; ?>

                                                    </div>

                                                    <?php $snn++ ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>

                                        <?php $sn++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>


                            </fieldset>




                            <h6>
                                <span class="step-title">Impact & Implications</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>













                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    <?php if($item->closures()->count() <= 0): ?>

                                        <a href="<?php echo e(route('ir.form.closure-step-1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-warning btn-sm">
                                            <i class="icon-arrow-left16 mr-1"></i> Previous
                                        </a>


                                        <button type="submit" class="btn btn-info btn-sm" name="save">
                                            <i class="fa fas fa-save mr-1"></i> Save
                                        </button>


                                        <button type="submit" class="btn btn-success btn-sm" name="save_cont">
                                            Save & Next <i class="icon-arrow-right16 ml-1"></i>
                                        </button>

                                    <?php else: ?>

                                        <a href="<?php echo e(route('ir.form.closure-step-1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-warning btn-sm">
                                            <i class="icon-arrow-left16 mr-1"></i> Previous
                                        </a>


                                        <a href="<?php echo e(route('ir.form.closure-step-2', ['id' => $formID])); ?>" class="btn btn-info btn-sm" name="save">
                                            <i class="fa fas fa-save mr-1"></i> Save
                                        </a>


                                        <a href="<?php echo e(route('ir.form.closure-step-3', ['id' => $formID])); ?>" class="btn btn-success btn-sm" name="save_cont">
                                            Save & Next <i class="icon-arrow-right16 ml-1"></i>
                                        </a>

                                    <?php endif; ?>

                                </div>
                            </div>


                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- uniform-3 files -->
    <script src="<?php echo e(asset('assets/ext_plugins/uniform_3/js/jquery.uniform.standalone.js')); ?>"></script>



    <script>


        $(document).ready(function () {
            $('.next-btn').trigger('click');
            $("input").uniform();


            $("#company_type_id").change(function(){

                $("#theFormHere").html("<div class='col-12 text-center'><i class='fas fa-spinner fa-spin'></i></div>")

                var type_id = $(this).val()
                // console.log(type_id)
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('ir.get-steps-params-by-type')); ?>',
                    data: {
                        type_id: type_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(res){
                        if(res.length > 0){
                            // console.log('generate the form')

                            var form = "<div class='row'>";
                            form += "<div class='col-12'><div class='alert alert-info'>";

                            var sn = 1;
                            $.each(res, function(stepi, stepd){
                                // console.log(stepd)
                                form += "<div class='mb-3 mt-3' style='border-bottom: 1px solid #9fdde5;'>";

                                form += "<label class='control-label form-check-label' for='step_id_"+stepd.id+"' style='font-size: 16px; color: black; '>"+sn+". &nbsp;&nbsp;" +
                                    "<input class='step_checkbox_f' type='checkbox' name='steps[]' value='"+stepd.id+"' id='step_id_"+stepd.id+"'> <span style='padding-left: 5px'><u>"+stepd.title+"</u></span>"+
                                    "</label>";
                                sn++;


                                // now the steps
                                form += "<div class='row mt-2'>";
                                $.each(stepd.closure_parameters, function(parami, paramd){

                                    // console.log(paramd)

                                    form += "<div class='col-6'>";

                                    form += "<div class='form-group'>"

                                    form += "<label for=''>"+paramd.title;
                                    var accepts = " ";
                                    if(paramd.parameter_type.title == "file"){
                                        form += " <span style='color: #f82828; font-weight: normal; font-size: 11px'>(only PDF and images are allowed)</span>";
                                        accepts = ' accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" '
                                    }
                                    form += "</label>"

                                    if(paramd.parameter_type.title == "textarea"){
                                        form += "<textarea class='form-control step_id_"+stepd.id+"_param' name='params["+stepd.id+"]["+paramd.id+"]' disabled></textarea>"
                                    }else{
                                        form += "<input type='"+paramd.parameter_type.title+"' class='form-control step_id_"+stepd.id+"_param'' name='params["+stepd.id+"]["+paramd.id+"]' disabled "+accepts+" />"
                                    }


                                    form += "</div><!-- end form-group -->";
                                    form += "</div><!-- end col-6 -->";


                                });
                                form += "</div>";

                                form += "</div><!-- end mb-1 -->"

                                $("#theFormHere").html(form);
                                $("input:checkbox").uniform();
                            })

                            form += "</div></div><!-- end col-12 -->"
                            form += "</div><!-- end row -->";

                        }else{
                            // console.log('no steps no form')
                            $("#theFormHere").html("");
                        }
                    }
                })
            })


            $("#theFormHere").on("click", ".step_checkbox_f", function(e){
                var step_id = $(this).attr("id");
               if($(this).is(':checked')){
                   // console.log('checked')
                   // enable all inputs
                   $("."+step_id+"_param").removeAttr("disabled")
                }else{
                   // console.log('unchecked')
                   $("."+step_id+"_param").attr("disabled", "disabled")
                   $("."+step_id+"_param").val("")
                   $("."+step_id+"_param").html("")
               }
            });

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/closure_step_2.blade.php ENDPATH**/ ?>