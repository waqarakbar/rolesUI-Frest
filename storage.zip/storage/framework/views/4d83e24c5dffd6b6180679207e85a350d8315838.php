<?php $app_id = config('incidentreporting.app_id') ?>


<?php $__env->startPush('stylesheets'); ?>
    <style type="text/css">
        .institute_actions {
            list-style-type: none;
            padding-left: 0px;
        }

        .institute_actions li {
            margin-top: 12px;
        }

        .status-div {
            width: 101%;
            margin-left: -3px;
        }

        .status-div h5 {
            margin-bottom: 0px;
            padding: 12px;
        }

        .fg_action_link{
            border-bottom: 1px solid #ccc;
            margin-bottom: 8px;
            padding-bottom: 8px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>






            <div class="row" >
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <h6 class="card-title">Form Details</h6>
                        </div>

                        <div class="card-body" style="p-adding: 5px">

                            <h5><u><?php echo e($item->title); ?></u></h5>

                            <h6>Request to <strong><?php echo e($item->departmentType->title ?? ""); ?></strong> for <strong><?php echo e($item->entityType->title ?? ""); ?></strong></h6>

                            <p><?php echo e($item->description); ?></p>

                        </div>
                    </div>

                </div>
            </div>



        <?php if(!is_null($item->fieldGroups) and $item->fieldGroups->count() > 0): ?>


            <div class="row">




                <div class="col-md-10">

                    <div class="row">

                        <?php $__currentLoopData = $item->fieldGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-12">

                                <div class="card">
                                    

                                    <div class="card-body">


                                        <div class="row">

                                            <div class="col-md-9">

                                                <h5><strong><?php echo e($fg->title); ?></strong> <small><em><?php if($fg->is_recurring == 'yes'): ?> (Recurring) <?php endif; ?></em></small></h5>
                                                <h6><small><?php echo e($fg->description); ?></small></h6>
                                                <hr>


                                                <div class="row">

                                                    <?php if($fg->fields->count() > 0): ?>

                                                        <div class="col-md-12">

                                                            <table class="table table-hover">
                                                                <thead>
                                                                <tr>
                                                                    <th style="width: 20px">#</th>
                                                                    <th>Field</th>
                                                                    <th style="width: 140px">Type</th>
                                                                    <th style="width: 40px">Action</th>
                                                                </tr>
                                                                </thead>

                                                                <?php $__currentLoopData = $fg->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <tbody>
                                                                    <tr>
                                                                        <td style="vertical-align: top"><?php echo e($loop->iteration); ?></td>
                                                                        <td style="vertical-align: top">
                                                                            <p>
                                                                                <strong><?php echo e($f->title); ?></strong>
                                                                                <?php if($f->is_mandatory == "no"): ?>
                                                                                    <span class="badge badge-warning">Optional</span>
                                                                                <?php else: ?>
                                                                                    <span class="badge badge-info">Mandatory</span>
                                                                                <?php endif; ?>
                                                                                <br>
                                                                                <small><?php echo e($f->description); ?></small>
                                                                            </p>


                                                                            <?php if($f->od_field_type_id == 6): ?>
                                                                                <p>
                                                                                    <strong><u>Options</u></strong>
                                                                                    <ol>
                                                                                        <?php $__currentLoopData = $f->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <li><?php echo e($op->title); ?></li>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </ol>
                                                                                </p>
                                                                            <?php endif; ?>

                                                                        </td>
                                                                        <td style="vertical-align: top"><?php echo e($f->fieldType->title); ?></td>
                                                                        <td style="vertical-align: top">
                                                                            <?php echo Form::open(['method' => 'delete', 'route' => ['fm.delete-field',\Illuminate\Support\Facades\Crypt::encrypt($f->id)], 'class' => 'delete', 'style' => 'display:inline']); ?>

                                                                            <?php echo Form::button('<i class="icon-bin"></i> ', array('class'=>'btn btn-danger btn-sm t-ext-danger', 'type'=>'submit', 'style' => 'p-adding: 0px 4px;')); ?>

                                                                            <?php echo Form::close(); ?>

                                                                        </td>
                                                                    </tr>
                                                                    </tbody>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </table>
                                                        </div>


                                                    <?php else: ?>

                                                        <div class="col-md-12">
                                                            <div class="alert alert-warning">
                                                                <h6>
                                                                    <i class="fa fa-warning"></i>
                                                                    <strong>ATTENTION!</strong>
                                                                </h6>

                                                                <p>There are no fields in this field group yet.</p>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                </div>

                                            </div>

                                            <div class="col-md-3">
                                                <div class="well">
                                                    <p>
                                                        <strong>
                                                            <i class="fa fa-cogs"></i> Manage Field Group
                                                        </strong>
                                                    </p>
                                                    <hr style="margin: 0px 0px 10px 0px">



                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="1"
                                                           data-field_type="Text Field">
                                                            <i class="icon-font-size"></i> Add Text Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="2"
                                                           data-field_type="Number Field">
                                                            <i class="icon-list-numbered"></i> Add Number Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="3"
                                                           data-field_type="Date Field">
                                                            <i class="icon-calendar52"></i> Add Date Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="4"
                                                           data-field_type="Paragraph Field">
                                                            <i class="icon-paragraph-left2"></i> Add Paragraph Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="5"
                                                           data-field_type="File Upload Field">
                                                            <i class="icon-upload"></i> Add File Upload Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="6"
                                                           data-field_type="Dropdown List Field">
                                                            <i class="icon-list-unordered"></i> Add Dropdown List Field
                                                        </a>
                                                    </div>

                                                    <div class="fg_action_link" style="border: none">

                                                        <?php echo Form::open(['method' => 'delete', 'route' => ['fm.delete-field-group',\Illuminate\Support\Facades\Crypt::encrypt($fg->id)], 'class' => 'delete', 'style' => 'display:inline']); ?>

                                                        <?php echo Form::button('<i class="icon-bin"></i> Delete Field Group', array('class'=>'btn btn-link text-danger', 'type'=>'submit', 'style' => 'padding: 0px;')); ?>

                                                        <?php echo Form::close(); ?>



                                                    </div>




                                                </div>
                                            </div>

                                        </div>



                                    </div>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>




                <div class="col-md-2" style="position: relative">

                    <div style="-position: fixed">
                        <a href="#" class="btn btn-primary btn-xs btn-block" data-toggle="modal" data-target="#newFg">
                            <i class="fa fa-plus"></i> Add Field Group
                        </a>
                    </div>

                </div>




            </div>


        <?php else: ?>


            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-warning">
                        <h5><i class="fa fa-warning"></i> ATTENTION!</h5>
                        <p>Currently there are no input field groups in this form, Please add a field group to proceed with the configuration.
                            <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#newFg">
                                <i class="fa fa-plus"></i> Add Field Group
                            </a>
                        </p>
                    </div>
                </div>
            </div>

        <?php endif; ?>


    <?php echo $__env->make('incidentreporting::od_forms._partials.new_field_group_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('incidentreporting::od_forms._partials.new_field_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_forms/show.blade.php ENDPATH**/ ?>