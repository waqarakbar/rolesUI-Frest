<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    <style>

        .card {
            border: unset;
            box-shadow: unset;
        }

        .add_form {
            background: rgb(255, 255, 255);
            padding-top: 2%;
            border-radius: 5px;
            /*box-shadow: rgb(206, 206, 206) 0px 0px 19px;*/
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline d-none hide">
                    
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body p-0">

                    <div class="row">

                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => 'ir.form.step3-save',
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>



                            <input type="hidden" name="id" value="<?php echo e($formID); ?>"/>


                            <h6>
                                <span class="step-title">General Info</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>

                            <h6>
                                <span class="step-title">
                                    Complainants & Evidences
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset>
                                &nbsp;
                            </fieldset>


                            <h6>
                                <span class="step-title">Person of Interest</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step3', [$formID])); ?>

                                </span>
                            </h6>


                            <?php if($poi_person): ?>
                                <input type="hidden" name="person_id"
                                       value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($poi_person->id)); ?>"/>
                            <?php endif; ?>


                            <fieldset class="pt-3">


                                <div class="row">
                                    <div class="col-md-12">

                                        <div class="alert alpha-brown border-0">


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h5><strong><u>Search PoI Database</u></strong></h5>
                                                </div>
                                            </div>

                                            <div class="row">

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Name:</label>
                                                        <?php echo Form::text('search_name',null, ['class' => 'form-control',"placeholder"=>"Name or Local Name",'id'=>'search_name']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>CNIC:</label>
                                                        <?php echo Form::text('search_cnic',null, ['class' => 'form-control',"placeholder"=>"CNIC Number",'id'=>'search_cnic']); ?>

                                                    </div>
                                                </div>

                                            </div>


                                            <div class="row">

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Registration Number:</label>
                                                        <?php echo Form::text('search_reg_number',null, ['class' => 'form-control',"placeholder"=>"Registration Number",'id'=>'search_reg_number']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Passport Number:</label>
                                                        <?php echo Form::text('search_passport_number',null, ['class' => 'form-control',"placeholder"=>"Passport Number",'id'=>'search_passport_number']); ?>

                                                    </div>
                                                </div>

                                            </div>


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="text-danger search_form_errors" style="font-weight: bold"></div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-md-12 text-right">
                                                    <div class="form-group">

                                                        <a class="btn btn-success search_button btn-sm text-white">
                                                            <i class="icon-search4"></i> Search PoI Database
                                                        </a>

                                                        <span style="display: inline-block; padding: 10px 5px; font-weight: bold; font-size: 18px">OR</span>

                                                        <a class="btn btn-sm btn-danger show_add_form_btn text-white">
                                                            <i class="icon-database-add mr-1"></i> Add New PoI
                                                        </a>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>


                                <div class="row search_result">

                                    <div class="col-md-12">

                                        <div class="table-responsive">

                                            <div class="alert alert-warning border-0  mb-5">

                                                <h5><strong><u>Search Results</u></strong></h5>

                                                <table class="table table-hover table-sm">
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Father Name</th>
                                                        <th>Gender</th>
                                                        <th>CNIC</th>
                                                        <th>Registration Number</th>
                                                        <th>Passport</th>
                                                        <th></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="search_result_tbody">

                                                    </tbody>
                                                </table>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                                <div class="add_form">


                                    <div class="row">
                                        <div class="col-md-12 mb-2">
                                            <h5 style="color: #4BAF4F; font-weight: bold">
                                                <span
                                                    style="display: inline-block; background-color: #fff; padding: 0px 10px 0px 0px">Personal Information</span>
                                                <hr style="color: #4BAF4F; margin-top: -11px; border: 1px solid #4baf4f;">
                                            </h5>
                                        </div>
                                    </div>


                                    <div class="row">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Name:</label>
                                                <span class="help">*</span>
                                                <?php echo Form::text('name',$poi_person?$poi_person->name:"", ['class' => 'form-control',"placeholder"=>"Name or Local Name",'id'=>'name','required'=>'required']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Father Name:</label>
                                                <span class="help">*</span>
                                                <?php echo Form::text('father_name',$poi_person?$poi_person->father_name:"", ['class' => 'form-control',"placeholder"=>"Father Name",'id'=>'father_name', 'required' => 'required']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Gender:</label>
                                                <span class="help">*</span>
                                                <?php echo Form::select('gender_id',$genders,$poi_person?$poi_person->gender_id:"", ['class' => 'form-control-select2',"placeholder"=>"Gender",'id'=>'gender_id','required'=>'required']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Identification Mark:</label>
                                                <span class="help">*</span>
                                                <?php echo Form::text('identification_mark',$poi_person?$poi_person->identification_mark:"", ['class' => 'form-control',"placeholder"=>"Identification Mark",'id'=>'identification_mark', 'required' => 'required']); ?>

                                            </div>
                                        </div>

                                    </div>


                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>CNIC:</label>
                                                
                                                <?php echo Form::text('cnic',$poi_person?$poi_person->cnic:"", ['class' => 'form-control',"placeholder"=>"CNIC #",'id'=>'cnic']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Passport:</label>
                                                <?php echo Form::text('passport',$poi_person?$poi_person->passport:"", ['class' => 'form-control',"placeholder"=>"Passport Number",'id'=>'passport']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Other Registration (if any):</label>
                                                
                                                <?php echo Form::text('other_registration',$poi_person?$poi_person->other_registration:"", ['class' => 'form-control',"placeholder"=>"Registration",'id'=>'other_registration']); ?>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Religion:</label>
                                                <?php echo Form::select('religion_id',$religions,$poi_person?$poi_person->religion_id:"", ['class' => 'form-control-select2',"placeholder"=>"Religion",'id'=>'religion_id']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Sect:</label>
                                                <?php echo Form::text('religion_sect',$poi_person?$poi_person->religion_sect:"", ['class' => 'form-control',"placeholder"=>"Religion sect",'id'=>'religion_sect']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Phone Number:</label>
                                                <?php echo Form::text('contact_number',$poi_person?$poi_person->contact_number:"", ['class' => 'form-control',"placeholder"=>"Contact Number",'id'=>'contact_number']); ?>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Approx Age:</label>
                                                <?php echo Form::number('approx_age',$poi_person?$poi_person->approx_age:"", ['class' => 'form-control',"placeholder"=>"Age",'id'=>'age', 'min' => 0, 'max' => 120]); ?>

                                            </div>
                                        </div>

                                    </div>


                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="row">

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Nationality:</label>
                                                        <span class="help">*</span>
                                                        <?php echo Form::select('country_id',$countries,$poi_person?$poi_person->country_id:"", ['class' => 'form-control-select2',"placeholder"=>"Country",'id'=>'country_id','required'=>'required']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Province:</label>
                                                        <span class="help">*</span>
                                                        <?php echo Form::select('province_id',$provinces,$poi_person?$poi_person->province_id:"", ['class' => 'form-control-select2 province_id',"placeholder"=>"Province",'id'=>'province_id','required'=>'required']); ?>

                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>District:</label>
                                                        <span class="help">*</span>
                                                        <?php echo Form::select('district_id',$districts,$poi_person?$poi_person->district_id:"", ['class' => 'form-control-select2 district_id',"placeholder"=>"Country",'id'=>'district_id','required'=>'required']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Tribe:</label>
                                                        <?php echo Form::text('tribe',$poi_person?$poi_person->tribe:"", ['class' => 'form-control',"placeholder"=>"Tribe",'id'=>'tribe']); ?>

                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Sub-Tribe:</label>
                                                        <?php echo Form::text('sub_tribe',$poi_person?$poi_person->sub_tribe:"", ['class' => 'form-control',"placeholder"=>"Sub-Tribe",'id'=>'sub_tribe']); ?>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                        <div class="col-md-6">

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Local Profession:</label>
                                                        <?php echo Form::text('profession',$poi_person?$poi_person->profession:"", ['class' => 'form-control',"placeholder"=>"Profession",'id'=>'profession']); ?>

                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Address:</label>
                                                        <?php echo Form::textarea('address',$poi_person?$poi_person->address:"", ['class' => 'form-control',"placeholder"=>"Address",'id'=>'address', 'rows' => 5]); ?>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                    </div>


                                    <div class="row">
                                        <div class="col-md-12 mb-2 mt-3">
                                            <h5 style="color: #4BAF4F; font-weight: bold">
                                                <span
                                                    style="display: inline-block; background-color: #fff; padding: 0px 10px 0px 0px">Biometric Information</span>
                                                <hr style="color: #4BAF4F; margin-top: -11px; border: 1px solid #4baf4f;">
                                            </h5>
                                        </div>
                                    </div>


                                    <div class="row">


                                        <div class="col-md-6">

                                            <div class="row">

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Eye Color:</label>
                                                        <?php echo Form::select('eye_color_id',$eye_colors,$poi_person?$poi_person->eye_color_id:"", ['class' => 'form-control-select2',"placeholder"=>"Eye color",'id'=>'eye_color_id']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Skin Color:</label>
                                                        <?php echo Form::select('skin_color_id',$skin_colors,$poi_person?$poi_person->skin_color_id:"", ['class' => 'form-control-select2',"placeholder"=>"Skin color",'id'=>'skin_color_id']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label>Height:</label>
                                                        <?php echo Form::text('height',$poi_person?$poi_person->height:"", ['class' => 'form-control',"placeholder"=>"Height",'id'=>'height']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-12">

                                                    <div class="alert alert-success border-0">

                                                        <div class="row">

                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label>Photo:</label>
                                                                    <?php echo Form::file('photo_front', null , ['class' => 'form-control',"placeholder"=>"Photo",'id'=>'photo_front']); ?>

                                                                </div>
                                                            </div>


                                                            <div class="col-md-6 text-left"
                                                                 style="b-order: 1px solid red">
                                                                <?php if(!is_null($poi_person)): ?>
                                                                    <?php $__currentLoopData = $poi_person->poiAttachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poiatt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <span style="position: relative; display: inline-block; border: 1px solid green;" class="mugshot_holder">

                                                                            <?php if(/*$poiatt->incident_id == \Illuminate\Support\Facades\Crypt::decrypt($formID) and*/ $poiatt->user_id == $cur_user->id): ?>
                                                                                <span
                                                                                    class="text-danger poi_attachment_delete"
                                                                                    data-attachment_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($poiatt->id)); ?>">
                                                                                <i class="fa fa-times"
                                                                                   style="position: absolute;bottom: 10px; left: 5px; top: 4px; cursor: pointer;"></i>
                                                                            </span>
                                                                            <?php endif; ?>

                                                                        <img
                                                                            src="<?php echo e(asset('uploads/pois/'.$poiatt->file)); ?>"
                                                                            alt="" style="max-height: 100px">

                                                                        </span>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>


                                                    </div>


                                                </div>

                                            </div>

                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>General Description:</label>
                                                <?php echo Form::textarea('general_description',$poi_person?$poi_person->general_description:"", ['class' => 'form-control',"placeholder"=>"General Description",'id'=>'general_description', 'rows' => 10]); ?>

                                            </div>
                                        </div>

                                    </div>


                                    <div class="row">
                                        <div class="col-md-12 mb-2">
                                            <h5 style="color: #4BAF4F; font-weight: bold">
                                                <span
                                                    style="display: inline-block; background-color: #fff; padding: 0px 10px 0px 0px">Affiliations & Accusation Status</span>
                                                <hr style="color: #4BAF4F; margin-top: -11px; border: 1px solid #4baf4f;">
                                            </h5>
                                        </div>
                                    </div>


                                    <div class="row">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Accused Type:</label>
                                                <span class="help">*</span>
                                                <?php echo Form::select('accused_type_id',$accused_types,$poi_person?$poi_person->accused_type_id:"", ['class' => 'form-control-select2 accused_type_id',"placeholder"=>"Accused Type",'id'=>'accused_type_id','required'=>'required']); ?>

                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>is in schedule-4?:</label>
                                                <span class="help">*</span>
                                                <?php echo Form::select('is_schedule4',['no' => 'No', 'yes' => 'Yes'],$poi_person?$poi_person->is_schedule4:'', ['class' => 'form-control-select2 is_schedule4',"placeholder"=>"Is schedule 4",'id'=>'is_schedule4','required'=>'required']); ?>

                                            </div>
                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Is the person affiliated to banned organization?:</label>
                                                <?php echo Form::select('affiliated_to_organization',['no' => 'No', 'yes' => 'Yes'], '', ['class' => 'form-control-select2 affiliated_to_organization',"placeholder"=>"Banned organization affiliations",'id'=>'affiliated_to_organization']); ?>

                                            </div>


                                            <div class="row">
                                                <div class="col-md-6 affiliated_organization_block">
                                                    <div class="form-group">
                                                        <label>Organization Affiliation:</label>
                                                        <?php echo Form::select('banned_organizations',$banned_organizations,NULL, ['class' => 'form-control-select2 banned_organizations_ddown',"placeholder"=>"Banned Organizations",'id'=>'banned_organizations']); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-6 affiliated_organization_block">
                                                    <div class="form-group">
                                                        <label>Role/Position in the Organization:</label>
                                                        <?php echo Form::select('affiliation_designation_id',$affiliation_designations,NULL, ['class' => 'form-control-select2 affiliation_designation_id',"placeholder"=>"Designation",'id'=>'affiliation_designation_id']); ?>

                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <ul>
                                                        <?php if(isset($poi_person->poiAffiliations)): ?>
                                                            <?php $__currentLoopData = $poi_person->poiAffiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $af): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="poi_affiliation_cont">
                                                                    Affiliated to
                                                                    <strong><?php echo e($af->organization->title ?? ""); ?></strong>
                                                                    as
                                                                    <strong><?php echo e($af->designation->title ?? ""); ?></strong>

                                                                    <?php if($af->user_id == $cur_user->id): ?>
                                                                        <span>
                                                                            <a href="javascript:void(0);" class="text-danger poi_affiliation_delete"
                                                                               title="Remove affiliation" data-affiliation_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($af->id)); ?>">
                                                                                <i class="fa fa-times ml-1"></i>
                                                                            </a>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>

                                                    </ul>
                                                </div>
                                            </div>

                                        </div>


                                    </div>


                                </div>

                            </fieldset>


                            <h6>
                                <span class="step-title">
                                    Place of Interest
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step4', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                            </fieldset>


                            <h6>
                                <span class="step-title">Mobility & Routes</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step5', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>


                            <div class="row mt-4 save_buttons_block">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    
                                    <button type="submit" name="save" class="btn btn-success btn-sm">
                                        <i class="fa fas fa-save mr-1"></i>
                                        <?php if($poi_person): ?> Save & Add to Incident <?php else: ?> Add Person of Interest <?php endif; ?>
                                    </button>

                                    
                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <div class="card">
                <div class="card-header header-elements-inline  ">
                    <h5 class="card-title">Persons of Interests</h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row col-12">
                        <table class="table table-hover table-sm">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Father Name</th>
                                <th>Gender</th>
                                <th>CNIC</th>
                                <th>Passport</th>
                                <th>Registration Number</th>
                                <th width="14%"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $item->incidentPersons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="incident_person_cont">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($ip->person->name); ?></td>
                                    <td><?php echo e($ip->person->father_name); ?></td>
                                    <td>
                                        <?php echo e($ip->person->gender?$ip->person->gender->title:""); ?>

                                    </td>
                                    <td><?php echo e($ip->person->cnic); ?></td>
                                    <td><?php echo e($ip->person->passport); ?></td>
                                    <td><?php echo e($ip->person->other_registration); ?></td>
                                    <td>
                                        


                                        

                                        <a href="<?php echo e(route('ir.form.step3',[\Illuminate\Support\Facades\Crypt::encrypt($item->id),\Illuminate\Support\Facades\Crypt::encrypt($ip->person_id)])); ?>"
                                           class="text-warning mr-2" title="Edit PoI">
                                            <i class="icon-pencil7"></i>
                                        </a>

                                        
                                        <?php if($ip->user_id == $cur_user->id): ?>
                                            <a href="javascript:void(0)" class="text-danger incident_person_delete" title="Delete PoI" data-incident_person_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($ip->id)); ?>">
                                                <i class="icon-trash"></i>
                                            </a>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                    <div class="row mt-5">
                        <div class="col-sm-12 pb-2 text-right pr-4">

                            <a href="<?php echo e(route('ir.form.step2', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>"
                               class="btn btn-warning btn-sm">
                                <i class="icon-arrow-left16 mr-1"></i> Previous
                            </a>


                            <a href="<?php echo e(route('ir.form.step3', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>"
                               class="btn btn-info btn-sm">
                                <i class="fa fas fa-save mr-1"></i> Save
                            </a>


                            <a
                                href="<?php echo e(route('ir.form.step4', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>"
                                class="btn btn-success btn-sm">
                                Save & Next <i class="icon-arrow-right16 ml-1"></i>
                            </a>
                        </div>
                    </div>


                </div>
            </div>
            <!-- /traffic sources -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <script>
        $(function () {
            $('.search_result').hide();
            $('.save_buttons_block').hide();
            $('.add_form').hide();
            $('.next-btn').trigger('click');
            $('.next-btn').trigger('click');


            $('.affiliated_organization_block').hide();

            $('.search_button').click(function () {
                /*$('.search_result').show();
                $('.add_form').hide();*/
            });

            $('.show_add_form_btn').click(function () {
                $(this).closest('form').find("input[type=text], textarea").val("");
                $('.add_form').show();
                $('.search_result').hide();
                $('.save_buttons_block').show();
            });

            <?php if($poi_person!=null): ?>
            $('.add_form').show();
            $('.search_result').hide();
            $('.save_buttons_block').show();
            <?php endif; ?>

            var CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
            $('.province_id').change(function () {
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('ir.form.province-districts')); ?>',
                    data: {province_id: $('.province_id').val(), _token: CSRF_TOKEN}
                }).done(function (data) {
                    var options = '';
                    $.each(JSON.parse(data), function (i, v) {
                        options += '<option value=' + v.id + '>' + v.title + '</option>';
                    });
                    $('.district_id').html(options);
                })
            });


            $('select.affiliated_to_organization').change(function () {
                if ($(this).val() == "yes") {
                    $('.affiliated_organization_block').show();
                } else {
                    $('.affiliated_organization_block').hide();
                }
            });


            $('.search_button').click(function () {
                var name = $('#search_name').val();
                var passport = $('#search_passport_number').val();
                var cnic = $('#search_cnic').val();
                var other_registration = $('#search_reg_number').val();

                if(name.length == 0 && passport.length == 0 && cnic.length == 0 && other_registration.length == 0){
                    $("#search_name").css('border', '1px solid red')
                    $("#search_cnic").css('border', '1px solid red')
                    $("#search_reg_number").css('border', '1px solid red')
                    $("#search_passport_number").css('border', '1px solid red')
                    $(".search_form_errors").html("Attention! Please fill at least one field to search PoIs Database")
                    return false;
                }else{
                    $("#search_name").css('border', '1px solid #ddd')
                    $("#search_cnic").css('border', '1px solid #ddd')
                    $("#search_reg_number").css('border', '1px solid #ddd')
                    $("#search_passport_number").css('border', '1px solid #ddd')
                    $(".search_form_errors").html("")
                }

                $('.search_result').show();
                $('.add_form').hide();

                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('ir.form.search_poi')); ?>',
                    data: {
                        name: name,
                        passport: passport,
                        other_registration: other_registration,
                        cnic: cnic,
                        incident_id: '<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>',
                        _token: CSRF_TOKEN
                    }
                }).done(function (data) {
                    var trs = '';
                    $.each(JSON.parse(data), function (i, v) {
                        var gender = "";
                        if (v.gender_id == 1) {
                            gender = "Male";
                        } else if (v.gender_id == 2) {
                            gender = "Female";
                        } else if (v.gender_id == 2) {
                            gender = "Other";
                        }

                        trs += '<tr>' +
                            '<td>' + (i + 1) + '</td>' +
                            '<td>' + v.name + '</td>' +
                            '<td>' + v.father_name + '</td>' +
                            '<td>' + gender + '</td>' +
                            '<td>' + v.cnic + '</td>' +
                            '<td>' + v.other_registration + '</td>' +
                            '<td>' + v.passport + '</td>' +
                            '<td><a class="btn btn-info btn-sm" href=' + v.route + ' ><i class="icon-arrow-down16"></i> Import PoI</a></td>' +
                            '</tr>';
                    });
                    $('.search_result_tbody').html(trs);

                })
            });
        })

        $(document).ready(function () {
            $(".poi_attachment_delete").click(function (e) {

                var conf = confirm('Are you sure you want to delete this photo?');
                if(conf){
                    var attachment_id = $(this).data('attachment_id');
                    $.ajax({
                        type: 'post',
                        url: '<?php echo e(route('ir.poi-attachment-delete')); ?>',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            attachment_id: attachment_id
                        },
                        success: function (res) {
                            // console.table(res)

                        }
                    });
                    $(this).parent(".mugshot_holder").remove();
                }
            })


            $(".poi_affiliation_delete").click(function (e) {

                var conf = confirm('Are you sure you want to delete this affiliation?');
                /*console.log($(this).parent().parent(".poi_affiliation_cont"));
                return false;*/

                if(conf){
                    var affiliation_id = $(this).data('affiliation_id');
                    $.ajax({
                        type: 'post',
                        url: '<?php echo e(route('ir.poi-affiliation-delete')); ?>',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            affiliation_id: affiliation_id
                        },
                        success: function (res) {
                            // console.table(res)

                        }
                    });
                    $(this).parent().parent(".poi_affiliation_cont").remove();
                }
            });


            $(".incident_person_delete").click(function (e) {

                var conf = confirm('Are you sure you want to remove this PoI from the incident?');
                /*console.log($(this).parent().parent(".poi_affiliation_cont"));
                return false;*/

                if(conf){
                    var incident_person_id = $(this).data('incident_person_id');
                    $.ajax({
                        type: 'post',
                        url: '<?php echo e(route('ir.incident-person-delete')); ?>',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            incident_person_id: incident_person_id
                        },
                        success: function (res) {
                            // console.table(res)

                        }
                    });
                    $(this).parent().parent(".incident_person_cont").remove();
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/form3.blade.php ENDPATH**/ ?>