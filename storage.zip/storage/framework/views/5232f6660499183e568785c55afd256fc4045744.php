<?php
    if(!isset($user)) $user = \Illuminate\Support\Facades\Auth::user();
?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(env('APP_NAME')); ?> <?php echo e($title ?? ""); ?></title>

    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet"
          type="text/css">
    <link href="<?php echo e(asset('assets/css/icons/icomoon/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/icons/icomoon/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('assets/css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/layout.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/my_custom.css')); ?>" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->

    <!-- Core JS files -->
    <script src="<?php echo e(asset('assets/js/main/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
    <!-- /core JS files -->

    <script>
        $(document).ready(function () {
            $(document).ready(function () {
                $.each($(".req"), function(i, j){
                    var label = $(this).html();
                    $(this).html(label+" <span class='starik' style='color:red;font-size:11px;'>*</span>");
                })

            });
        })
    </script>

</head>

<body>

<!-- Main navbar -->
<div class="navbar navbar-expand-md navbar-dark" style="background-color: #<?php echo e(env('GREEN')); ?>">
    <div class="navbar-brand wmin-200" style="padding: 0px;margin: 0px;">
        <a href="/" class="d-inline-block" style="font-size: 26px; color: #fff; padding-top: 9px;">
            
            <img src="<?php echo e(asset('assets/images/logo_white.svg')); ?>" alt="" style="width: 70px; height: auto; display: inline-block">
            <?php echo e(env('APP_ABBR')); ?>

        </a>
    </div>

    <div class="d-md-none">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-mobile">
            
            <i class="icon-user"></i>
            <i class="icon-chevron-down"></i>
        </button>

        

    </div>

    <div class="collapse navbar-collapse" id="navbar-mobile">
        <ul class="navbar-nav">
            <li class="nav-item">
                
            </li>


        </ul>

        <span class="b-adge b-g-success-400 ml-md-auto mr-md-3"></span>

        <ul class="navbar-nav">


            <li class="nav-item dropdown dropdown-user">
                <a href="#" class="navbar-nav-link d-flex align-items-center dropdown-toggle" data-toggle="dropdown">
                    <img src="<?php echo e(asset('assets/images/placeholders/admin2.jpeg')); ?>" class="rounded-circle mr-2"
                         height="34" alt="">
                    <span><?php echo e($user->name); ?></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right">
                    <a href="<?php echo e(route('settings.users-mgt.my-profile')); ?>" class="dropdown-item"><i class="icon-user-plus"></i> My profile</a>
                    
                    <a href="<?php echo e(route('settings.users-mgt.change-password')); ?>" class="dropdown-item"><i class="icon-cog5"></i> Change Password</a>

                    
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="icon-switch2"></i> <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>

                </div>
            </li>
        </ul>
    </div>
</div>
<!-- /main navbar -->






<!-- Page header -->
<div class="page-header">
    <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
        <div class="d-flex">

            <div class="breadcrumb">
                <a href="<?php echo e(route('app.landing-screen')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>


                <span class="breadcrumb-item active"><?php echo e($title ?? ""); ?></span>

            </div>

            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>

        <div class="header-elements d-none">

        </div>
    </div>

    <div class="page-header-content header-elements-md-inline">
        <div class="page-title d-flex" style="padding: 1rem 0;">
            <h4>
                <a href="<?php echo e(route('app.landing-screen')); ?>">
                    <i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Home</span>
                </a> -


                <?php echo e($title ?? ''); ?>

            </h4>
            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>


        <?php echo $__env->make('layouts._partials.page_actions', ['back_route' => $back_route ?? null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
</div>
<!-- /page header -->




<!-- Page content -->
<div class="page-content -pt-0">

    <!-- Main content -->
    <div class="content-wrapper">

        <!-- Content area -->
        <div class="content p-2">



            <div class="row">
                <div class="col-12">
                    <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                        <div class="alert alert-danger alert-styled-left alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                            <span
                                class="font-weight-semibold">Error! </span> <?php echo e(\Illuminate\Support\Facades\Session::get('error')); ?>

                            .
                        </div>
                    <?php endif; ?>

                    <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                        <div class="alert alert-success alert-styled-left alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                            <span
                                class="font-weight-semibold">Success! </span> <?php echo e(\Illuminate\Support\Facades\Session::get('success')); ?>

                            .
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo $__env->yieldContent('content'); ?>


        </div>
        <!-- /content area -->

    </div>
    <!-- /main content -->

</div>
<!-- /page content -->


</body>
</html>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/resources/views/layouts/restricted_layout.blade.php ENDPATH**/ ?>