<div class="header-elements d-none mb-3 mb-md-0">
    <div class="d-flex justify-content-center">

        <?php if(isset($back_route)): ?>

            <?php if(isset($back_route[2])): ?>
                <a href="<?php echo e($back_route[0]); ?>" class="btn btn-warning btn-sm mr-1"><i class="icon-arrow-left16 mr-1"></i>
                    <?php echo e($back_route[1]); ?></a>
            <?php else: ?>
                <a href="<?php echo e(route($back_route[0])); ?>" class="btn btn-warning btn-sm mr-1"><i class="icon-arrow-left16 mr-1"></i>
                    <?php echo e($back_route[1]); ?></a>
            <?php endif; ?>

        <?php endif; ?>

        <?php if(isset($new_route)): ?>

            <?php if(isset($new_route[2])): ?>
                    <a href="<?php echo e($new_route[0]); ?>" class="btn btn-success btn-sm"><i class="icon-database-add mr-1"></i>
                        <?php echo e($new_route[1]); ?></a>
            <?php else: ?>
                    <a href="<?php echo e(route($new_route[0])); ?>" class="btn btn-success btn-sm"><i class="icon-database-add mr-1"></i>
                        <?php echo e($new_route[1]); ?></a>
            <?php endif; ?>


        <?php endif; ?>

    </div>
</div>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/resources/views/layouts/_partials/page_actions.blade.php ENDPATH**/ ?>