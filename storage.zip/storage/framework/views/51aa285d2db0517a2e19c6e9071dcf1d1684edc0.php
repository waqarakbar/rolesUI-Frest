<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    <style>
        .fab-menu-btn {
            display: flex;
            padding: 0.25rem 0.75rem !important;
            justify-content: space-between;
            font-size: 10pt;
            letter-spacing: 0.50px;
        }

        .custom-card-group {

        }

        .custom-card-group .card:first-child {
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        }

        .custom-card-group .card:last-child {
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
        }

        .custom-card-group .card {
            border: unset;
            border-radius: unset;
        }

        .border-radius-5 {
            border-radius: 5px;
        }

        .border-radius-10 {
            border-radius: 10px;
        }

        .card-icon {
            position: absolute;
            top: 30%;
            right: 10%;
            opacity: 0.3;
        }

        .custom-card-priority .card {
            margin-right: 1.5%;
            width: 22.5%;
            float: left;
        }

        .card-stats {
            position: absolute;
            right: 5px;
            top: 10px;
        }

        .custom-card-illegal .card {
            border: unset;
            box-shadow: 0px 0px 5px 5px #eee;
            min-height: 122px;
        }

        .custom-card-illegal .card .card-body {
            display: flex;
            justify-content: flex-start;
            align-items: center;
        }

        .custom-card-illegal .card .icon-container img {
            max-width: 48px;
            margin-right: 10px;
            margin-left: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">


            <!-- Basic Summary -->
            <div class="row mb-3">
                <div class="col-sm-12">
                    <div class="card bg-success">

                        <div class="card-header header-elements-sm-inline py-1" style="border-bottom: 3px solid #eee;">
                            <h6 class="card-title">
                                Incident Summary
                            </h6>
                            <div class="header-elements">
                                <a class="text-default daterange-ranges font-weight-semibold cursor-pointer dropdown-toggle">
                                    <i class="icon-calendar3 mr-2"></i>
                                    <span>June 20 - June 26</span>
                                </a>
                            </div>
                        </div>

                        <div
                            class="card-body d-md-flex align-items-md-center justify-content-md-between flex-md-wrap py-1">

                            <?php
                                $sts_denom = 1;
                                if($status_wise_counts[0]->total > 0){
                                    $sts_denom = $status_wise_counts[0]->total;
                                }
                            ?>
                            <div class="d-flex align-items-center mb-3 mb-md-0">
                                <div class="ml-3">
                                    <h5 class="font-weight-semibold mb-0"
                                        style="font-size: 2rem"><?php echo e($status_wise_counts[0]->total); ?></h5>
                                    <span class="text-white">Total Incidents</span>
                                </div>
                            </div>

                            <div class="d-flex align-items-center mb-3 mb-md-0">
                                <a href="<?php echo e(route('ir.reports.incidents-by-status', ['status_id' => \Illuminate\Support\Facades\Crypt::encrypt(1)])); ?>"
                                   class="btn bg-transparent border-white text-white rounded-round border-2 btn-icon">
                                    <i class="icon-arrow-up8"></i>
                                </a>
                                <div class="ml-3">
                                    <h5 class="font-weight-semibold mb-0"
                                        style="font-size: 1.25rem"><?php echo e($status_wise_counts[0]->draft); ?></h5>
                                    <?php
                                        $draft_pc = round(($status_wise_counts[0]->draft*100)/$sts_denom)
                                    ?>
                                    <span class="text-white">Draft (<?php echo e($draft_pc); ?>%)</span>
                                </div>
                            </div>

                            <div class="d-flex align-items-center mb-3 mb-md-0">
                                <a href="<?php echo e(route('ir.reports.incidents-by-status', ['status_id' => \Illuminate\Support\Facades\Crypt::encrypt(2)])); ?>"
                                   class="btn bg-transparent border-white text-white rounded-round border-2 btn-icon">
                                    <i class="icon-arrow-up-right3"></i>
                                </a>
                                <div class="ml-3">
                                    <h5 class="font-weight-semibold mb-0"
                                        style="font-size: 1.25rem"><?php echo e($status_wise_counts[0]->inprogress); ?></h5>
                                    <?php
                                        $inprogress_pc = round(($status_wise_counts[0]->inprogress*100)/$sts_denom)
                                    ?>
                                    <span class="text-white">InProgress (<?php echo e($inprogress_pc); ?>%)</span>
                                </div>
                            </div>

                            <div class="d-flex align-items-center mb-3 mb-md-0">
                                <a href="<?php echo e(route('ir.reports.incidents-by-status', ['status_id' => \Illuminate\Support\Facades\Crypt::encrypt(3)])); ?>"
                                   class="btn bg-transparent border-white text-white rounded-round border-2 btn-icon">
                                    <i class="icon-arrow-down8"></i>
                                </a>
                                <div class="ml-3">
                                    <h5 class="font-weight-semibold mb-0"
                                        style="font-size: 1.25rem"><?php echo e($status_wise_counts[0]->closed); ?></h5>
                                    <?php
                                        $closed_pc = round(($status_wise_counts[0]->closed*100)/$sts_denom)
                                    ?>
                                    <span class="text-white">Closed (<?php echo e($closed_pc); ?>%)</span>
                                </div>
                            </div>


                        </div>

                        <div id="server-load"></div>

                    </div>
                </div>
            </div>


            <!-- Priority wise index -->
            <div class="row mb-3">

                <div class="col-sm-12 col-md-9">
                    <h3>Priority-wise index</h3>

                    <div class="col-12 p-0 custom-card-priority">

                        <?php $__currentLoopData = $priority_wise_counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('ir.reports.incidents-by-priority', ['priority_id' => \Illuminate\Support\Facades\Crypt::encrypt($pcount->id)])); ?>">
                                <div class="card col-12 col-md-3 border-radius-10 bg-<?php echo e($pcount->badge_class); ?>">
                                    <div class="card-body p-2">
                                        <div class="d-flex">
                                            <h1 class="font-weight-semibold mb-0"><?php echo e($pcount->num_i); ?></h1>
                                        </div>
                                        <div>
                                            <span class="font-weight-semibold"><?php echo e($pcount->priority); ?></span>
                                        </div>
                                        <div class="card-icon">

                                            <?php if($pcount->id == 4): ?>
                                                <i class="fa fa-fw fa-2x fa-exclamation-triangle"></i>
                                            <?php elseif($pcount->id == 3): ?>
                                                <i class="icon-bell3" style="font-size: 36px;"></i>
                                            <?php elseif($pcount->id == 2): ?>
                                                <i class="icon-hour-glass2" style="font-size: 36px;"></i>
                                            <?php else: ?>
                                                <i class="icon-meter-slow" style="font-size: 36px;"></i>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                </div>


                <div class="col-sm-12 col-md-3">
                    <h3>Response index</h3>
                    <div class="card border-radius-10 bg-info">
                        <div class="card-body p-2">
                            <div class="d-flex">
                                <h1 class="font-weight-semibold mb-0">
                                    <?php
                                        $responsive_denom = 1;
                                        if($responsive_index[0]->total > 0){
                                            $responsive_denom = $responsive_index[0]->total;
                                        }
                                        $percent = round(($responsive_index[0]->completed*100)/$responsive_denom);
                                        echo $percent."%";
                                    ?>
                                </h1>
                            </div>
                            <div>
                                <span
                                    class=""><?php echo e($responsive_index[0]->completed); ?>/<?php echo e($responsive_index[0]->total); ?></span>
                            </div>
                            <div class="card-icon">
                                <i class="icon-shield-check" style="font-size: 36px;"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!-- Illegal Spectrum Summary -->
            <h3>Illegal Spectrum Summary</h3>
            <div class="row mb-3">

                <div class="col-md-12">

                    <div class="col-md-12 p-0 custom-card-illegal"
                         style="display: flex;flex-direction: row;flex-wrap: wrap;">

                        <?php $__currentLoopData = $spectrum_wise_counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $swc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-2 col-md-4 pl-0">
                                <a href="<?php echo e(route('ir.reports.incidents-by-spectrum', ['spectrum_id' => \Illuminate\Support\Facades\Crypt::encrypt($swc->id)])); ?>">
                                    <div class="card border-radius-10 px-1">
                                        <div class="card-body px-0 py-2">
                                            <div class="d-flex align-items-center">

                                                <div class="icon-container">
                                                    <img class="" src="<?php echo e(asset('assets/images/icons/'.$swc->icon)); ?>"
                                                         alt="">
                                                </div>

                                                <div class="">
                                                    <h1 class="font-weight-semibold mb-0"><?php echo e($swc->total_incidents); ?></h1>
                                                    <span class=""><?php echo e($swc->spectrum); ?></span>
                                                </div>
                                            </div>

                                            <?php
                                                $x1 = $swc->last_60_30_days;
                                                if($x1 <= 0){
                                                    $x1 = 1;
                                                }

                                                $monthly_change = round((($swc->last_30_days - $swc->last_60_30_days)/$x1)*100, 1);

                                                if($monthly_change > 0){
                                                    // incidents increased, danger alert
                                                    $arrow_icon = "<i class='icon-arrow-up8 text-danger'></i>";
                                                    $badge_class = "danger";
                                                }else{
                                                    // incidents decreased, good times hun
                                                    $arrow_icon = "<i class='icon-arrow-down8 text-success'></i>";
                                                    $badge_class = "success";
                                                }
                                            ?>

                                            <span class="card-stats">
                                            <?php echo $arrow_icon; ?>

                                            <span class="text-<?php echo e($badge_class); ?>"><?php echo e($monthly_change); ?>%</span>
                                        </span>
                                        </div>
                                    </div>
                                </a>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        

                    </div>

                </div>

            </div>
            <!-- Illegal Spectrums -->


            <!-- Pendency Breakup -->
            <h3>Pendency Breakup</h3>
            <div class="row mb-3">

                <div class="col-12 custom-card-group d-flex">

                    <div class="card c-ol-12 col-md-3 text-center bg-success">
                        <a href="<?php echo e(route('ir.reports.incidents-by-pendency-tl', ['pendency_tl_i' => 'less_3m'])); ?>"
                           class="text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-center">
                                    <h1 class="font-weight-semibold mb-0"><?php echo e($pendency_counts[0]->less_3_months); ?></h1>
                                </div>
                                <div>
                                    Less than <span class="font-weight-semibold">3</span> Months
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="card c-ol-12 col-md-3 text-center bg-orange-300">
                        <a href="<?php echo e(route('ir.reports.incidents-by-pendency-tl', ['pendency_tl_i' => 'more_3m'])); ?>"
                           class="text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-center">
                                    <h1 class="font-weight-semibold mb-0"><?php echo e($pendency_counts[0]->between_3_6); ?></h1>
                                </div>
                                <div>
                                    More than <span class="font-weight-semibold">3</span> Months
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="card c-ol-12 col-md-3 text-center bg-warning">
                        <a href="<?php echo e(route('ir.reports.incidents-by-pendency-tl', ['pendency_tl_i' => 'more_6m'])); ?>"
                           class="text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-center">
                                    <h1 class="font-weight-semibold mb-0"><?php echo e($pendency_counts[0]->between_6_1y); ?></h1>
                                </div>
                                <div>
                                    More than <span class="font-weight-semibold">6</span> Months
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="card c-ol-12 col-md-3 text-center bg-danger">
                        <a href="<?php echo e(route('ir.reports.incidents-by-pendency-tl', ['pendency_tl_i' => 'more_1y'])); ?>"
                           class="text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-center">
                                    <h1 class="font-weight-semibold mb-0"><?php echo e($pendency_counts[0]->more_1y); ?></h1>
                                </div>
                                <div>
                                    More than <span class="font-weight-semibold">1</span> Year
                                </div>
                            </div>
                        </a>
                    </div>

                </div>


            </div>
            <!-- END of Pendency Breakup -->


        </div>

        <!-- floating button -->
        <div class="col-12">
            <ul class="fab-menu fab-menu-fixed fab-menu-bottom-right">
                <li>
                    <a href="<?php echo e(route('ir.form.step1')); ?>"
                       class="fab-menu-btn btn bg-success btn-float rounded-round btn-icon">
                        <span class="mr-1">
                            <i class="fab-icon-open icon-plus3"></i>
                            <i class="fab-icon-close icon-cross2"></i>
                        </span>
                        <span>
                            Report Incident
                        </span>
                    </a>
                </li>
            </ul>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/ui/fab.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/ui/sticky.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/ui/prism.min.js')); ?>"></script>

    <script src=".<?php echo e(asset('assets/js/demo_pages/extra_fab.js')); ?>"></script>
    <script>


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/dashboard/master_dashboard.blade.php ENDPATH**/ ?>