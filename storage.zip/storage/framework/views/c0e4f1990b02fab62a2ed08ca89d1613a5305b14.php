<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <table class="table table-striped" >

                                    <thead>
                                    <tr>
                                        <th><i class="icon-menu-open2"></i></th>
                                        <th>Tracking ID</th>
                                        <th>Spectrum</th>
                                        <th>Date & Time</th>
                                        <th>Initiated By</th>
                                        <th>Current Assigned By</th>
                                        <th>Current Assigned To</th>
                                        <th>Source</th>
                                        <th>Self/Transf.</th>
                                        
                                        <th>Priority</th>
                                        <th>Motive</th>
                                        <th>Status</th>
                                        <th style="width: 100px">Other Departments Requests</th>

                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $user_cur = \Illuminate\Support\Facades\Auth::user() ?>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td style="width: 150px">

                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown"><i class="icon-cog5 mr-2"></i> Options</button>
                                                    <div class="dropdown-menu dropdown-menu-right">


                                                        <a href="<?php echo e(route('ir.incident.profile', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-success">
                                                            <i class="icon-book"></i> Profile
                                                        </a>

                                                        <?php if($item->assignmentCurrent[0]->assignment->to_user_id == $user->id): ?>

                                                            <a href="<?php echo e(route('ir.form.step1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-success">
                                                                <i class="icon-pencil7"></i> General Information
                                                            </a>


                                                            <a href="<?php echo e(route('ir.form.step2', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-success">
                                                                <i class="icon-pencil7"></i> Evidences
                                                            </a>


                                                            <a href="<?php echo e(route('ir.form.step3', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-success">
                                                                <i class="icon-pencil7"></i> Persons of Interest
                                                            </a>


                                                            <a href="<?php echo e(route('ir.form.step4', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-success">
                                                                <i class="icon-pencil7"></i> Place of Interest
                                                            </a>


                                                            <a href="<?php echo e(route('ir.form.step5', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-success">
                                                                <i class="icon-pencil7"></i> Mobility & Route
                                                            </a>


                                                        <?php endif; ?>

                                                        <?php if(in_array($user_cur->id, config('incidentreporting.can_delete_user_ids'))): ?>
                                                            <a href="#" class="dropdown-item text-danger"
                                                               data-toggle="modal"
                                                               data-target="#deleteIncidentConfirm"
                                                               data-incident_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">
                                                                <i class="icon-trash"></i> Delete
                                                            </a>

                                                        <?php endif; ?>

                                                    </div>
                                                </div>




                                            </td>


                                            
                                            <td><strong><?php echo e($item->tracking_code); ?></strong></td>
                                            <td><?php echo e($item->spectrum->title ?? ""); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->incident_date)->format('d/m/Y')); ?> <?php echo e(\Carbon\Carbon::parse($item->incident_date." ".$item->incident_time)->format('h:i A')); ?></td>

                                            <td><?php echo e($item->user->name); ?> (<small><?php echo e($item->user->company->title); ?></small>)</td>
                                            <td>
                                                <?php if($item->assignmentcurrent[0]->assignment->assignment_type_id == 1): ?>
                                                    --
                                                <?php else: ?>
                                                    <?php echo e($item->assignmentcurrent[0]->assignment->fromUser->name); ?> (<small><?php echo e($item->assignmentcurrent[0]->assignment->fromUser->company->title); ?></small>)
                                                <?php endif; ?>
                                            </td>

                                            <td><?php echo e($item->assignmentcurrent[0]->assignment->toUser->name); ?> (<small><?php echo e($item->assignmentcurrent[0]->assignment->toUser->company->title); ?></small>)</td>

                                            <td><?php echo e($item->incidentSource->title ?? ""); ?></td>
                                            <td><?php echo e($item->assignmentCurrent[0]->assignment->assignmentType->title ?? ""); ?></td>
                                            
                                            <td><span class="badge badge-<?php echo e($item->priority->badge_class); ?>"><?php echo e($item->priority->title ?? ""); ?></span></td>
                                            <td>

                                                <?php $ssn = 1 ?>
                                                <?php $__currentLoopData = $item->incidentMotives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge -badge-primary badge-pill"><?php echo e($ssn++); ?>. <?php echo e($m->title); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </td>

                                            <td>
                                                
                                                <span class="badge badge-<?php echo e($item->currentStatus[0]->statusHistory->incidentStatus->bg_class); ?>">
                                                    <?php echo e($item->currentStatus[0]->statusHistory->incidentStatus->title); ?>

                                                </span>
                                            </td>
                                            <td>

                                                <?php

                                                    $total_req_users = 0;
                                                    $completed_req_users = 0;
                                                    foreach($item->requests as $req){
                                                        $thisReqUsers = $req->requestUsers;
                                                        $total_req_users += $thisReqUsers->count();

                                                        if($thisReqUsers->count() > 0){
                                                            $completed_req_users += $thisReqUsers->where('status', 'completed')->count();
                                                        }
                                                    }

                                                    // echo $total_req_users."/".$completed_req_users;
                                                    $percent = 0;
                                                    if($total_req_users > 0){
                                                        $percent = round(($completed_req_users/$total_req_users)*100);
                                                    }

                                                ?>

                                                <?php if($total_req_users > 0): ?>
                                                    <span style="font-size: 11px; font-weight: bold"><?php echo e($completed_req_users); ?> / <?php echo e($total_req_users); ?> (<?php echo e($percent); ?>%)</span><br>

                                                    <div class="progress mb-3" style="height: 0.375rem;">
                                                        <div class="progress-bar bg-success" style="width: <?php echo e($percent); ?>%">
                                                            <span class="sr-only"><?php echo e($percent); ?>% Complete</span>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <code>n/a</code>
                                                <?php endif; ?>
                                            </td>



                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

    <?php echo $__env->make('incidentreporting::incident-reporting.steps._partials.delete_incident_confirm_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/index.blade.php ENDPATH**/ ?>