<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <table class="table table-striped" >

                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Request</th>
                                        <th>Request For</th>
                                        <th>Due Date</th>
                                        <th>Requested By</th>
                                        <th></th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><strong><?php echo e($item->form->title ?? ""); ?></strong></td>
                                            <td><?php echo e($item->entityType->title ?? ""); ?></td>
                                            <td><?php echo e(date("d/M/Y", strtotime($item->due_date))); ?></td>
                                            <td><strong><?php echo e($item->user->name); ?></strong> <small>(<?php echo e($item->user->company->title ?? ""); ?>)</small></td>
                                            <td style="width: 150px">


                                                <a href="<?php echo e(route('ir.od-requests.submit-response', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="btn btn-warning btn-sm">
                                                    Respond <i class="icon-arrow-right16 ml-1"></i>
                                                </a>



                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_requests/my_pending_requests.blade.php ENDPATH**/ ?>