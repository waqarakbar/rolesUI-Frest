<?php $app_id = config('settings.app_id') ?>


<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <form action="<?php echo e(route('settings.users-mgt.change-password-save')); ?>" method="post">


                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">


                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('new_password', 'New Password ', ['class' => 'form-label req']); ?>

                                            <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('new_password'); ?> <?php endif; ?></span>
                                            <input type="password" name="new_password" id="new_password" class="form-control" required>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('conf_new_password', 'Confirm New Password ', ['class' => 'form-label req']); ?>

                                            <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('conf_new_password'); ?> <?php endif; ?></span>
                                            <input type="password" name="conf_new_password" id="conf_new_password" class="form-control" required>
                                        </div>
                                    </div>

                                </div>




                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="alert alpha-danger border-0">
                                            <div class="form-group">
                                                <?php echo Form::label('current_password', 'Current Password ', ['class' => 'form-label req']); ?>

                                                <span class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('current_password'); ?> <?php endif; ?></span>
                                                <input type="password" name="current_password" id="current_password" class="form-control" required>
                                                <span class="-help text-primary">Please provide your current password to save changes</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>








                                <div class="row">
                                    <div class="col-12">

                                        <button class="btn btn-danger btn-sm">
                                            <i class="icon-undo mr-1"></i> Reset
                                        </button>

                                        <button type="submit" class="btn btn-success btn-sm">
                                            <i class="icon-database-check mr-1"></i> Update Password
                                        </button>

                                    </div>
                                </div>

                            </form>


                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.restricted_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/users_mgt/change_password.blade.php ENDPATH**/ ?>