<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startSection('content'); ?>


    <?php if($entity_type_id == 1): ?>
        <?php echo $__env->make("incidentreporting::od_requests._partials.poi_entity", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(in_array($entity_type_id, [2, 3])): ?>
        <?php echo $__env->make("incidentreporting::od_requests._partials.mobility_entity", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>












    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">

                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><strong>Submit New Request Form</strong></h6>
                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item requestFormCollapse" data-action="collapse"></a>
                        </div>
                    </div>
                </div>


                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <form method="post" action="<?php echo e(route('ir.od-requests.save')); ?>">

                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                <input type="hidden" name="incident_id"
                                       value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">

                                <input type="hidden" name="entity_type_id"
                                       value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($entity_type_id)); ?>">

                                <input type="hidden" name="entity_id"
                                       value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($entity_id)); ?>">


                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('department_type_id', 'Select Department type ', ['class' => 'form-label req']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_type_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('department_type_id', [null=>'Select a Department type']+$department_types->toArray(), NULL, ['class' => 'form-control form-control-select2', 'id' => 'department_type_id', 'required' => 'required']); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('due_date', 'Due Date ', ['class' => 'form-label req']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('due_date'); ?><?php endif; ?></span>
                                            <?php echo Form::date('due_date', null, ['class' => 'form-control', 'id' => 'due_date', 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-12">
                                        <div id="add_forms_checkboxes_here"></div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php echo Form::label('department_id', 'Select Department ', ['class' => 'form-label req']); ?>


                                            <span
                                                class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_id'); ?> <?php endif; ?></span>
                                            <?php echo Form::select('department_id[]', [], NULL, ['class' => 'form-control form-control-select2', 'id' => 'department_id', 'multiple'=> 'multiple', 'required' => 'required']); ?>

                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php echo Form::label('remarks', 'Remarks / Details ', ['class' => 'form-label req']); ?>

                                            <span
                                                class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                            <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'required' => 'required', 'rows'=>10]); ?>

                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-12">

                                        <a href="<?php echo e(route('ir.incident.profile', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>"
                                           class="btn btn-warning btn-sm">
                                            <i class="icon-arrow-left16 mr-1"></i> Incident Profile
                                        </a>

                                        <button type="submit" class="btn btn-success btn-sm submit_btn_mf">
                                            <i class="icon-database-check mr-1"></i> Save Request
                                        </button>

                                    </div>
                                </div>

                            </form>


                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>





    <?php if(isset($od_request_u) and $od_request_u->count() > 0): ?>

        <!-- collapse the form if there are already requests -->
        <script>
            $(document).ready(function () {
                setTimeout(function(){
                    $(".requestFormCollapse").trigger('click')
                }, 500);
            })
        </script>


        <!-- Questions title -->
        <div class="text-center mb-3 py-2 mt-5">
            <h3 class="font-weight-semibold mb-1">Initiated Requests</h3>
            <span class="text-muted d-block">Following requests have been initiated and forwarded to stakeholders against this <?php echo e($entity_type->title); ?></span>

            <?php
                $f_total_requests = $od_request_u->count();
                $f_completed_requests = $od_request_u->where('status', 'completed')->count();
                $f_percentage = round(($f_completed_requests/$f_total_requests)*100);
            ?>

            <h5 class="font-weight-semibold">
               <?php echo e($f_completed_requests); ?> / <?php echo e($f_total_requests); ?> (<?php echo e($f_percentage); ?>% Completed)
            </h5>

            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <div class="progress mb-3" style="height: 1rem;">
                        <div class="progress-bar bg-success" style="width: <?php echo e($f_percentage); ?>%">
                            <span class="sr-only"><?php echo e($f_percentage); ?>% Complete</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4"></div>
            </div>

        </div>
        <!-- /questions title -->

        <!-- Inner container -->
        <div class="d-flex align-items-start flex-column flex-md-row">

            <!-- Left content -->
            <div class="w-100 overflow-auto order-2 order-md-1">

                <!-- Questions list -->
                <div class="card-group-control card-group-control-right">


                    <?php $__currentLoopData = $od_request_u; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            if($requ->status == 'completed'){
                                $sts_class = "success";
                                $sts_title = "Completed";
                            }else{
                                if(!is_null($requ->due_date) and time() > strtotime($requ->due_date)){
                                    $sts_class = "danger";
                                    $sts_title = "Overdue";
                                }else{
                                    $sts_class = "warning";
                                    $sts_title = "Pending";
                                }
                            }
                        ?>


                        <div class="card mb-2">
                            <div class="card-header">
                                <h6 class="card-title">
                                    <a class="text-default collapsed " data-toggle="collapse" href="#question<?php echo e($requ->id); ?>">
                                        <span class="font-weight-semibold"><?php echo e($loop->iteration); ?>. </span>
                                        <i class="fa fa-check-circle text-<?php echo e($sts_class); ?>"></i>
                                        <strong><?php echo e($requ->request->form->title); ?></strong> of <em><u><?php echo e($entity_type->title); ?></u></em> assigned to <strong><?php echo e($requ->user->name ?? ""); ?></strong>
                                        <small>
                                            (<?php echo e($requ->user->company->title ?? ""); ?>)
                                            <span class="text-danger">[Due: <?php echo e(date('d/M/Y', strtotime($requ->request->due_date))); ?>]</span>
                                        </small>
                                    </a>
                                </h6>
                            </div>

                            <div id="question<?php echo e($requ->id); ?>" class="collapse">
                                <div class="card-body">


                                    <div class="row mb-0">
                                        <div class="col-md-12">
                                            <div class="alert alpha-info border-0">

                                                <h5><strong><u>Request Details</u></strong></h5>
                                                <p>
                                                    This request was initiated by <strong><?php echo e($requ->request->user->name ?? ""); ?></strong> <small>(<?php echo e($requ->request->user->company->title ?? ""); ?>)</small> for the "<?php echo e($requ->request->entityType->title ?? ""); ?>", dated <?php echo e(date("d/M/Y h:i A", strtotime($requ->request->created_at))); ?>


                                                </p>

                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <p class="text-danger"><strong>Due Date: </strong> <?php echo e(date("d/M/Y", strtotime($requ->request->due_date))); ?></p>
                                                        <p>
                                                            <span class="badge badge-<?php echo e($sts_class); ?>"><?php echo e($sts_title); ?></span>
                                                            <?php if($requ->status == 'completed'): ?>
                                                                <span class="text-success">Completed on <?php echo e(date("d/M/Y h:s A", strtotime($requ->completion_date))); ?></span>
                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                </div>

                                                <p>
                                                    <strong>Remarks: </strong><br><?php echo e($requ->request->remarks); ?>

                                                </p>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                            <i class="icon-arrow-down32" style="display: block; line-height: .7;"></i>
                                            <i class="icon-arrow-down32" style="display: block; line-height: .7; margin-bottom: 7px"></i>
                                        </div>
                                    </div>


                                    <?php if($requ->status == 'completed'): ?>
                                    <div class="row mt-0">
                                        <div class="col-md-12">
                                            <div class="alert alpha-success border-0">

                                                <h5><strong><u>Response Data</u></strong></h5>

                                                <p>
                                                    Response submitted by <strong><?php echo e($requ->user->name ?? ""); ?></strong> <small>(<?php echo e($requ->user->company->title ?? ""); ?>)</small>, dated <strong><?php echo e(date("d/M/Y h:i A", strtotime($requ->completion_date))); ?></strong>
                                                </p>

                                                <?php if($requ->compliance_possible == "no"): ?>

                                                    <div class="alert alert-danger">
                                                        <strong><i class="icon-warning"></i> ATTENTION! <br>
                                                            the officer stated that compliance to this request is not possible, following are the details:</strong>
                                                        <br><br>
                                                        "<em><?php echo e($requ->remarks); ?></em>"
                                                    </div>


                                                <?php else: ?>

                                                    <p>
                                                        <strong>Remarks: </strong><br><?php echo e($requ->remarks); ?>

                                                    </p>

                                                    <div>

                                                        
                                                        <table class="table table-striped table-bordered" >
                                                            <thead>
                                                            <tr>
                                                                <th style="width: 30%">Data Request</th>
                                                                <th>Submitted Information</th>
                                                            </tr>
                                                            </thead>

                                                            <tbody>
                                                            <?php $__currentLoopData = $requ->requestUserData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <th><?php echo e($theD->od_field_title); ?></th>
                                                                    <td>
                                                                        <?php if($theD->od_field_type_id == 5): ?>
                                                                            <a href="<?php echo e(asset('uploads/od_responses/'.$theD->od_value)); ?>" target="_blank">
                                                                                <i class="fa fa-paperclip"></i> File Attachment
                                                                            </a>
                                                                        <?php elseif($theD->od_field_type_id == 3): ?>
                                                                            <?php if(!is_null($theD->od_value)): ?>
                                                                                <?php echo e(date("d/M/Y", strtotime($theD->od_value))); ?>

                                                                            <?php endif; ?>
                                                                        <?php else: ?>
                                                                            <?php echo e($theD->od_value); ?>

                                                                        <?php endif; ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="row mt-0">
                                            <div class="col-md-12">
                                                <div class="alert alert-warning b-order-0">
                                                    ATTENTION! The assignee has not yet submitted their response to this request
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>


                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts-bottom'); ?>
    <script>

        $(document).ready(function () {

            <?php if(Session::has('errors')): ?>
            $("#department_type_id").trigger('change')
            <?php endif; ?>

            $("#department_type_id").change(function () {
                var department_type_id = $(this).val();
                // alert(department_type_id);
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('ir.od-requests.form-department-somethingx')); ?>',
                    data: {
                        department_type_id: department_type_id,
                        entity_type_id: '<?php echo e($entity_type_id); ?>',
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function (res) {
                        // console.log(res.departments);
                        var dpts = "";
                        $.each(res.departments, function (i, v) {
                            dpts += "<option value='" + i + "'>" + v + "</option>";
                        });
                        $("#department_id").html(dpts).trigger('change')
                        // $("#department_id").select2().trigger('change')

                        // console.log(Object.keys(res.forms).length)
                        if (Object.keys(res.forms).length > 0) {
                            var form_checks = "<div class='alert alpha-brown border-0'>";
                            form_checks += "<h6><strong><u>Select information requests,</u></strong> <small>(you may select one or more requests)</small></h6>";
                            $.each(res.forms, function (i, v) {
                                form_checks += "<div>";
                                form_checks += "<label class='form-label mb-2'>" +
                                    "<input type='checkbox' class='mr-2' name='form_ids[]' value='" + i + "' />" +
                                    " " + v +
                                    "</label>";
                                form_checks += "</div>";
                            });
                            $("#add_forms_checkboxes_here").html(form_checks);
                            // enable submit button
                            $(".submit_btn_mf").removeAttr("disabled")
                        } else {
                            var form_checks = "<div class='alert alert-danger border-0'>";
                            form_checks += "<h6><strong><u>Select information requests,</u></strong> <small>(you may select one or more requests)</small></h6>";
                            form_checks += "SORRY! there are no request forms assigned to the selected department type";
                            $("#add_forms_checkboxes_here").html(form_checks);

                            // disable submit button
                            $(".submit_btn_mf").attr("disabled", "disabled")
                        }

                    }
                })
            })
        });


    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_requests/initiate_request.blade.php ENDPATH**/ ?>