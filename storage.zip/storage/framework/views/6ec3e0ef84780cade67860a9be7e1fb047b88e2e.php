<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    
    <style>
        .card {
            border: unset;
            box-shadow: unset;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Evidences / Attachments -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => ['ir.form.step2-save', $formID],
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>



                            <h6>
                                <span class="step-title">
                                    General Info
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>




                            <h6>
                                <span class="step-title">
                                    Complainants & Evidences
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">


                                <div class="row">
                                    <div class="col-12">
                                        <div class="alert alpha-brown border-0">

                                            <h6><strong><u>Evidences</u></strong></h6>
                                            <?php if( $item->evidences->count() == 0 ): ?>
                                                <div class="alert alert-warning">

                                                    <span class="font-weight-semibold">Warning!</span> Not Evidence attached. Please <a href="#" data-toggle="modal" data-target="#addAttachmentModal"><strong>Click here</strong></a> to add new evidence
                                                </div>
                                            <?php else: ?>
                                            <button type="button" class="btn btn-warning btn-sm float-right" data-toggle="modal" data-target="#addAttachmentModal"> <i class="fa fa-plus-circle mr-1"></i> Add Evidence</button>
                                            <div class="table-responsive">
                                                <table class="table table-hover table-sm">
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Title</th>
                                                        <th>File Type</th>
                                                        <th>File Link</th>
                                                        <th>Decription</th>
                                                        <th>Uploaded On</th>
                                                        <th class="text-center" style="width: 30px;"><i class="icon-menu-open2"></i></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php if( count($item->evidences) > 0 ): ?>
                                                        <?php $__currentLoopData = $item->evidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($loop->iteration); ?></td>
                                                                <td><?php echo e($evidence->title); ?></td>
                                                                <td><?php echo e(optional($evidence->evidenceType)->title ?? "-"); ?></td>
                                                                <td>
                                                                    <a href="<?php echo e(asset("uploads/evidences/".$evidence->file)); ?> " target="_blank" placeholder="View File">
                                                                        View File <i class="fa fa-fw fa-external-link-alt"></i>
                                                                    </a>
                                                                </td>
                                                                <td><?php echo e($evidence->description); ?></td>
                                                                <td><?php echo e(\Carbon\Carbon::parse($evidence->created_at)->format('d/m/Y h:i A')); ?></td>
                                                                <td>
                                                                    <a class="text-danger" href="<?php echo e(route('ir.upload-file.remove', [\Illuminate\Support\Facades\Crypt::encrypt($evidence->id)])); ?>" onclick="return confirm('Are you sure you want to delete this evidence?')">
                                                                        <i class="icon-trash"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>



                                <div class="row">
                                    <div class="col-12">
                                        <div class="alert alpha-brown border-0">

                                            <h6><strong><u>Complainants</u></strong></h6>
                                            <?php if( $item->complainants->count() == 0 ): ?>
                                                <div class="alert alert-warning">

                                                    <span class="font-weight-semibold">ATTENTION!</span> There are no complainants attached with this incident. If the incident does not have any complainants, you may leave this section. Otherwise <a href="#" data-toggle="modal" data-target="#addComplainant"><strong>Click here</strong></a> to start adding complainants
                                                </div>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-warning btn-sm float-right" data-toggle="modal" data-target="#addComplainant"> <i class="fa fa-plus-circle mr-1"></i> Add Complainant</button>
                                                <div class="table-responsive">
                                                    <table class="table table-hover table-sm">
                                                        <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Type</th>
                                                            <th>Name</th>
                                                            <th>Father Name</th>
                                                            <th>Profession</th>
                                                            <th>CNIC</th>
                                                            <th>Passport</th>
                                                            <th>Registration</th>
                                                            <th>Contact</th>
                                                            <th class="text-center" style="width: 30px;"><i class="icon-menu-open2"></i></th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php if( count($item->complainants) > 0 ): ?>
                                                            <?php $__currentLoopData = $item->complainants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($loop->iteration); ?></td>
                                                                    <td><?php echo e($comp->complainant_type ?? ""); ?></td>
                                                                    <td><?php echo e($comp->name); ?></td>
                                                                    <td><?php echo e($comp->father_name); ?></td>
                                                                    <td><?php echo e($comp->profession->title ?? ""); ?></td>
                                                                    <td><?php echo e($comp->cnic); ?></td>
                                                                    <td><?php echo e($comp->passport); ?></td>
                                                                    <td><?php echo e($comp->other_registration_no); ?></td>
                                                                    <td><?php echo e($comp->contact_number); ?></td>

                                                                    <td class="text-center" style="width: 120px">

                                                                        

                                                                        <a href="<?php echo e(route('ir.incident.delete-complainant', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($comp->id)])); ?>" class="text-danger" title="Delete Complainant" onclick="return confirm('Are you sure you want to delete complainant?')">
                                                                            <i class="icon-trash"></i>
                                                                        </a>

                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>


                            </fieldset>





                            <h6>
                                <span class="step-title">Person of Interest</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>




                            <h6>
                                <span class="step-title">
                                    Place of Interest
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step4', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                            </fieldset>





                            <h6>
                                <span class="step-title">Mobility & Routes</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.step5', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>




                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    <a href="<?php echo e(route('ir.form.step1', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Previous
                                    </a>


                                    <button class="btn btn-info btn-sm" name="save">
                                        <i class="fa fas fa-save mr-1"></i> Save
                                    </button>


                                    <a type="submit" href="<?php echo e(route('ir.form.step3', [ \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-success btn-sm">
                                        Save & Next <i class="icon-arrow-right16 ml-1"></i>
                                    </a>
                                </div>
                            </div>


                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

    <?php echo $__env->make('incidentreporting::incident-reporting.steps._partials.new_complainant_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Disabled keyboard interaction -->
    <div id="addAttachmentModal" class="modal fade" data-keyboard="false" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Evidences</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">

                    <form method="POST" action="<?php echo e(route('ir.upload-file')); ?>?redirect=back" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-sm-12 col-md-5 form-group">
                                <label class="form-label semi-bold req" for="">Evidence Type</label>
                                <span class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('evidence_type_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select("evidence_type_id", $evidence_types, old('evidence_type_id'), ['class' => 'form-control-select2', 'required' => 'required']); ?>

                            </div>

                            <div class="col-sm-12 col-md-7 form-group">
                                <label class="form-label semi-bold " for="">Evidence Title</label>
                                <span class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('title'); ?> <?php endif; ?></span>
                                <input type="text" name="title" class="form-control" placeholder="Leave Blank (auto get from file)" value="<?php echo e(old('title')); ?>">
                            </div>


                            <div class="col-sm-12 form-group">
                                <label class="form-label semi-bold req" for="">Attach File</label>
                                <span class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('file'); ?> <?php endif; ?></span>
                                <input type="file" name="file" class="form-control" placeholder="Choose file to upload" value="<?php echo e(old('file')); ?>" required />
                                <input type="hidden" name="_id" value="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($item->id)); ?>">
                            </div>

                            <div class="col-sm-12 form-group">
                                <label for="description" class="form-label">Description</label>
                                <span class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('description'); ?> <?php endif; ?></span>
                                <textarea class="form-control" name="description" id="" rows="4"><?php echo e(old('description')); ?></textarea>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-12 text-right">
                                <button type="button" class="btn btn-warning btn-sm" data-dismiss="modal">
                                    <i class="icon-arrow-left16 mr-1"></i> Close
                                </button>
                                <button type="submit" name="save" class="btn btn-success btn-sm">
                                    Upload <i class="fa fas fa-upload ml-1"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </div>
    <!-- /disabled keyboard interaction -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <!-- Theme JS files -->

    
    <!-- /theme JS files -->
    <script>


        $(document).ready(function () {

            <?php if(Session::has('errors') and Session::get('errors')->first('file')): ?>
                $("#addAttachmentModal").modal('show')
            <?php endif; ?>

            <?php if(Session::has('errors') and (Session::get('errors')->first('name') or Session::get('errors')->first('father_name') or Session::get('errors')->first('contact_number'))): ?>
                $("#addComplainant").modal('show')
            <?php endif; ?>


            $('.next-btn').trigger('click');

            // Fixing the URL not found issue
            setTimeout( function() {
                $('.dropzonee').addClass('dropzone');
            }, 100);

            /*Dropzone.autoDiscover = false; // otherwise will be initialized twice
            var myDropzoneOptions = {
                maxFiles: 10,
                method: 'POST',
                autoProcessQueue: false,
                addRemoveLinks: true,
                init : function() {
                    this.on("addedfile", function(file) { alert('New File addedd'); newFileAdded(file); });
                    // this.on("thumbnail", function(file,fileurl) { new_thumbnail_added(file); });
                    this.on("removedfile", function(file) { newFileRemoved(file); });
                    // this.on("totaluploadprogress", function(progress) { display_progress(progress); });
                    this.on("queuecomplete", function() { allFilesUploaded(); });
                    //this.on("processing", function(file) { new_file_processed(file); });
                },
                sending: function (file, xhr, formData) {
                    alert('Sending...');
                    formData.append('_token', '<?php echo e(csrf_token()); ?>'),
                        formData.append('upload_directory', 'evidences')
                },
                success: function (file, response) {
                    var response_str = JSON.stringify(response.id);
                    alert(response_str);
                    $("#uploaded_file_responses_div").append("<input type='hidden' name='uploaded_file_response[]' value='" + response_str + "'>")
                },
                error: function(err){
                    alert(err);
                }
            };
            var myDropzone = new Dropzone('#myAwesomeDropzone', myDropzoneOptions);*/

            /**
             * New File Added
             * */
            function newFileAdded(file) {
                console.log(file);
            }

            /**
             * New file Removed
             * */
            function newFileRemoved(file) {
                console.log(file);
            }

            function allFilesUploaded() {
                alert('All files uploaded');
            }

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/form2.blade.php ENDPATH**/ ?>