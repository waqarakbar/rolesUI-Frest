<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    
    <style>
        .card {
            border: unset;
            box-shadow: unset;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Evidences / Attachments -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => ['ir.form.closure-step-3-save', $formID],
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>


                            <?php echo csrf_field(); ?>

                            <h6>
                                <span class="step-title">
                                    Recoveries
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>






                            <h6>
                                <span class="step-title">Incident Closure</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">
                                &nbsp;
                            </fieldset>




                            <h6>
                                <span class="step-title">Impact & Implications</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">


                                <?php if($item->impacts->count() <= 0): ?>

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="alert alert-warning">
                                                ATTENTION! It seems that no impacts has been added to this incident yet, please
                                                <a href="#" data-toggle="modal" data-target="#addImpact"><strong>Click here</strong></a> to start adding impacts to the incident.
                                            </div>
                                        </div>
                                    </div>

                                <?php else: ?>


                                    <button type="button" class="btn btn-warning btn-sm float-right" data-toggle="modal" data-target="#addImpact"> <i class="fa fa-plus-circle mr-1"></i> Add Impact</button>
                                    <div class="table-responsive">
                                        <table class="table table-hover table-sm">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Impact Type</th>
                                                <th>Impact Value</th>
                                                <th>Details</th>
                                                <th class="text-center" style="width: 130px;"><i class="icon-menu-open2"></i></th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $item->impacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="impact_cont">
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($impact->impactType->title ?? ""); ?></td>
                                                    <td><?php echo e($impact->impact_value); ?></td>
                                                    <td style="width: 40%"><?php echo e(substr($impact->details, 0, 140)); ?></td>
                                                    <td>

                                                        


                                                        <?php if($impact->user_id == $cur_user->id): ?>
                                                            <a href="javascript:void(0)" class="text-danger impact_delete" title="Delete impact" data-impact_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($impact->id)); ?>">
                                                                <i class="icon-trash"></i>
                                                            </a>
                                                        <?php endif; ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>


                                <?php endif; ?>


                            </fieldset>












                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    <a href="<?php echo e(route('ir.form.closure-step-2', ['id' => $formID])); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Incident Closure
                                    </a>


                                    <a href="<?php echo e(route('ir.form.closure-step-3', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="btn btn-info btn-sm">
                                        <i class="fa fas fa-save mr-1"></i> Save
                                    </a>


                                    <a href="<?php echo e(route('ir.incident.profile', ['id' => $formID])); ?>" class="btn btn-success btn-sm">
                                        Save & Finish <i class="icon-checkbox-checked ml-1"></i>
                                    </a>

                                </div>
                            </div>


                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>



    <?php echo $__env->make('incidentreporting::incident-reporting.steps._partials.new_impact_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <!-- Theme JS files -->

    <script>


        $(document).ready(function () {

            $('.next-btn').trigger('click').trigger('click');



            $(".impact_delete").click(function (e) {

                var conf = confirm('Are you sure you want to delete this impact item?');

                if(conf){
                    var impact_id = $(this).data('impact_id');
                    $.ajax({
                        type: 'post',
                        url: '<?php echo e(route('ir.impact-delete')); ?>',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            impact_id: impact_id
                        },
                        success: function (res) {
                            // console.table(res)

                        }
                    });
                    $(this).parent().parent(".impact_cont").remove();
                }
            })

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/closure_step_3.blade.php ENDPATH**/ ?>