<?php $app_id = config('settings.app_id') ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <table class="table table-striped data_mf_table" >

                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Type</th>
                                        <th>Level</th>
                                        <th>Parent</th>
                                        <th>No. of Sub <?php echo e(str_plural(config('settings.company_title'))); ?></th>
                                        <th>Division</th>
                                        <th>District</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><strong><?php echo e($item->title); ?></strong></td>
                                            <td><?php echo e($item->type->title ?? ""); ?></td>
                                            <td><?php echo e($item->level->title ?? ""); ?></td>
                                            <td><?php echo e($item->parent->title ?? ""); ?></td>
                                            <td><?php echo e($item->children->count() ?? 0); ?></td>
                                            <td><?php echo e($item->division->title ?? ""); ?></td>
                                            <td><?php echo e($item->district->title ?? ""); ?></td>
                                            <td style="width: 150px">

                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown"><i class="icon-cog5 mr-2"></i> Options</button>
                                                    <div class="dropdown-menu dropdown-menu-right">



                                                        <a href="<?php echo e(route('settings.companies.edit', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-warning">
                                                            <i class="icon-pencil7"></i> Edit
                                                        </a>

                                                        <?php echo Form::open(['method' => 'delete', 'route' => ['settings.companies.delete',\Illuminate\Support\Facades\Crypt::encrypt($item->id)], 'class' => 'dropdown-item delete', 'style' => 'display:inline']); ?>

                                                        <?php echo Form::button('<i class="icon-trash text-danger" style=" margin-right: 12px;color:red;"></i> Delete', array('class'=>'btn btn-link ', 'type'=>'submit', 'style' => 'padding:0px; width:100%; text-align:left')); ?>

                                                        <?php echo Form::close(); ?>




                                                    </div>
                                                </div>




                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/companies/index.blade.php ENDPATH**/ ?>