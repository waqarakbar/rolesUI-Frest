<?php $app_id = config('settings.app_id') ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <table class="table table-striped data_mf_table" >

                                    <thead>
                                    <tr>
                                        
                                        <th>Action</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Username</th>
                                        <th>Parent User</th>
                                        <th>No. of Children Users</th>
                                        <th><?php echo e(config('settings.company_title')); ?></th>
                                        <th><?php echo e(config('settings.section_title')); ?></th>
                                        <th>Roles</th>
                                        <th>No. of Permissions</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td style="width: 150px">

                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown"><i class="icon-cog5 mr-2"></i> Options</button>
                                                    <div class="dropdown-menu dropdown-menu-right">



                                                        <a href="<?php echo e(route('settings.users-mgt.edit', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-warning">
                                                            <i class="icon-pencil7"></i> Edit
                                                        </a>


                                                        <a href="<?php echo e(route('settings.users-mgt.show', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="dropdown-item text-primary">
                                                            <i class="icon-cog6"></i> Permissions
                                                        </a>

                                                        <?php echo Form::open(['method' => 'delete', 'route' => ['settings.users-mgt.delete',\Illuminate\Support\Facades\Crypt::encrypt($item->id)], 'class' => 'dropdown-item delete', 'style' => 'display:inline-block']); ?>

                                                        <?php echo Form::button('<i class="icon-trash text-danger" style=" margin-right: 12px;color:red;"></i> Delete', array('class'=>'btn btn-link ', 'type'=>'submit', 'style' => 'padding:0px; width:100%; text-align:left')); ?>

                                                        <?php echo Form::close(); ?>




                                                    </div>
                                                </div>




                                            </td>
                                            <td><strong><?php echo e($item->name); ?></strong></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><code><?php echo e($item->username); ?></code></td>
                                            <td><?php echo e($item->parent->name ?? ""); ?></td>
                                            <td><?php echo e($item->children->count()); ?></td>
                                            <td><?php echo e($item->company->title ?? ""); ?></td>
                                            <td><?php echo e($item->section->title ?? ""); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-info"><?php echo e($r->name); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td><?php echo e($item->permissions->count()); ?></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/users_mgt/index.blade.php ENDPATH**/ ?>