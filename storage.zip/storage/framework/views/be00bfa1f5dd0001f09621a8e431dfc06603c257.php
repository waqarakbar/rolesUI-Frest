
<style type="text/css">
    .bred {
        b-order: 1px solid red;
    }

    .titlesec h3, .titlesec h4, .titlesec h3 {
        margin: 2px !important;
    }
</style>

<div class="report_header bred row">

    <div class="-header_logo col-2 bred">
        <img src="<?php echo asset('assets/images/kpklogo.png'); ?>" alt="" width="120px">
    </div>

    <div class="titlesec col-8 text-center">
        <h3><strong><?php echo e(env('APP_NAME')); ?></strong></h3>
        <h4 class="text-center"><b><?php echo e(\Modules\Settings\Entities\Company::find($user->company_id)->title); ?></b></h4>

        <h5 class="text-center"><em><b><?php echo $title; ?></b></em></h5>

        <p style="background-color: green !important; color: #ffffff !important; text-align: center; padding: 2px;">Dated: <?php echo date("d/M/Y h:i A") ?></p>

    </div>


    <div class="col-2 text-right bred">

        <?php if(isset($qrcodeText)): ?>
            <?php $qrt = $qrcodeText ?>
        <?php else: ?>
            <?php $qrt = $user->id." - ".$user->name. "(".$user->username.")" ?>
        <?php endif; ?>

        <img src="data:image/png;base64,<?php echo e((new \Milon\Barcode\DNS2D())->getBarcodePNG($qrt, "QRCODE")); ?>"
                 alt="<?php echo e($qrt); ?>" style="width: 120px;"/>

    </div>

</div>

<div class="row">
    <div class="col-xs-12">
        <hr>
    </div>
</div>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/reports/_partials/report_header.blade.php ENDPATH**/ ?>