<?php $app_id = config('settings.app_id') ?>


<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'method' => $item->exists ? 'put' : 'post',
                                'route' => $item->exists ? ['settings.my-roles.update', \Illuminate\Support\Facades\Crypt::encrypt($item->id)] : ['settings.my-roles.store']
                                ]); ?>



                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('name', 'Role Title ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('name'); ?><?php endif; ?></span>
                                        <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'required' => 'required']); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="row">

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('slug', 'Role Slug ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('slug'); ?><?php endif; ?></span>
                                        <?php echo Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('level', 'Role Level ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('level'); ?><?php endif; ?></span>
                                        <?php echo Form::number('level', null, ['class' => 'form-control', 'id' => 'level', 'required' => 'required', 'min' => 0]); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('description', 'Details ', ['class' => 'form-label']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                        <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

                                    </div>
                                </div>
                            </div>








                            <div class="row">
                                <div class="col-12">

                                    <a href="<?php echo e(route('settings.my-apps.list')); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Back
                                    </a>

                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="icon-database-check mr-1"></i> Save
                                    </button>

                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/my_roles/form.blade.php ENDPATH**/ ?>