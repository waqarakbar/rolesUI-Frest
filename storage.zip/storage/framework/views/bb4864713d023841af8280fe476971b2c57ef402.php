<?php $app_id = config('settings.app_id') ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $(".select2").select2()

            $("#province_id").change(function(){
                var province_id = $(this).val()
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.districts-by-province-id')); ?>',
                    data: {
                        province_id: province_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(res){
                        // console.log(res)
                        var districts = "<option value>Select a district</option>"
                        $.each(res, function(i,v){
                            districts += "<option value='"+i+"'>"+v+"</option>"
                        })
                        $("#district_id").html(districts)
                    }
                })
            })


            $("#division_id").change(function(){
                var division_id = $(this).val()
                // alert('there')
                $.ajax({
                    type: 'post',
                    url: '<?php echo e(route('noauth.districts-by-division-id')); ?>',
                    data: {
                        division_id: division_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(res){
                        console.log(res)
                        var districts = "<option value>Select a district</option>"
                        $.each(res, function(i,v){
                            districts += "<option value='"+i+"'>"+v+"</option>"
                        })
                        $("#district_id").html(districts)
                    }
                })
            })

        })


    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">


                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'method' => $item->exists ? 'put' : 'post',
                                'route' => $item->exists ? ['settings.companies.update', \Illuminate\Support\Facades\Crypt::encrypt($item->id)] : ['settings.companies.store']
                                ]); ?>




                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('title', config('settings.company_title').' Name ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                        <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="row">

                                <div class="col-3">
                                    <div class="form-group">
                                        <?php echo Form::label('company_type_id', 'Select Type ', ['class' => 'control-label req']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('company_type_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('company_type_id', [null=>'Select a Type']+$types->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'company_type_id', 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-3">
                                    <div class="form-group">
                                        <?php echo Form::label('company_level_id', 'Select Level ', ['class' => 'control-label req']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('company_level_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('company_level_id', [null=>'Select a Level']+$levels->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'company_level_id', 'required' => 'required']); ?>

                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('parent_id', 'Select Parent '.config('settings.company_title'), ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('parent_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('parent_id', [null=>'This is a parent '.config('settings.company_title')]+$companies_dd, NULL, ['class' => 'form-control select2', 'id' => 'parent_id']); ?>

                                    </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <?php echo Form::label('province_id', 'Select Province ', ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('province_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('province_id', [null=>'Select a Province']+$provinces->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'province_id']); ?>

                                    </div>
                                </div>


                                <div class="col-3">
                                    <div class="form-group">
                                        <?php echo Form::label('division_id', 'Select Division ', ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('division_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('division_id', [null=>'Select a Division']+$divisions->toArray(), NULL, ['class' => 'form-control', 'id' => 'division_id']); ?>

                                    </div>
                                </div>


                                <div class="col-3">
                                    <div class="form-group">
                                        <?php echo Form::label('district_id', 'Select District ', ['class' => 'control-label']); ?>


                                        <span
                                            class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('district_id'); ?> <?php endif; ?></span>
                                        <?php echo Form::select('district_id', [null=>'Select a District']+$districts->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'district_id']); ?>

                                    </div>
                                </div>


                            </div>


                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <?php echo Form::label('description', 'Details ', ['class' => 'form-label req']); ?>

                                        <span
                                            class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                        <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

                                    </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-12">

                                    <a href="<?php echo e(route('settings.companies.list')); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Back
                                    </a>

                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="icon-database-check mr-1"></i> Save
                                    </button>

                                </div>
                            </div>

                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('settings.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/Settings/Resources/views/companies/form.blade.php ENDPATH**/ ?>