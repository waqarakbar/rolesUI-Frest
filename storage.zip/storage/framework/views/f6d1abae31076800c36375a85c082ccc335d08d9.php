<!-- Disabled keyboard interaction -->
<div id="deleteIncidentConfirm" class="modal fade" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-l-g">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Incident Delete Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST" action="<?php echo e(route('ir.incident.delete-incident')); ?>">


                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="incident_id" id="incident_id_mf" value="">


                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('remarks', 'Why are you deleting this incident (Reason)?  ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'required' => 'required', 'rows' => 4]); ?>

                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-12 text-right">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                <i class="icon-arrow-left16 mr-1"></i> Close
                            </button>

                            <button type="submit" name="save" class="btn btn-danger">
                                <i class="fa fas fa-trash mr-1"></i> Delete Incident
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /disabled keyboard interaction -->
<script>
    $(document).ready(function () {
        $('#deleteIncidentConfirm').on('shown.bs.modal', function (e) {
            // $(".form-control-select2").select2()
            var incident_id = $(e.relatedTarget).data('incident_id');
            console.log(incident_id)
            $("#incident_id_mf").val(incident_id)
        });

        
    })
</script>
<?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/_partials/delete_incident_confirm_modal.blade.php ENDPATH**/ ?>