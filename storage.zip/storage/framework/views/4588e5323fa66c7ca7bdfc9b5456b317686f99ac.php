<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('stylesheets'); ?>
    
    <style>
        .card {
            border: unset;
            box-shadow: unset;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <!-- Evidences / Attachments -->
            <div class="card">

                <div class="card-body p-0">

                    <div class="row">


                        <div class="col-12">

                            <?php echo Form::model($item, [
                                'enctype' => 'multipart/form-data',
                                'class' => 'wizard-form steps-enable-all',
                                'method' => 'post',
                                'route' => ['ir.form.closure-step-1-save', $formID],
                                'data-id' => $formID,
                                'data-fouc',
                            ]); ?>


                            <?php echo csrf_field(); ?>

                            <h6>
                                <span class="step-title">
                                    Recoveries
                                </span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-1', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">

                                <?php if($item->recoveries->count() <= 0): ?>

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="alert alert-warning">
                                                ATTENTION! It seems that no recoveries has been added to this incident yet, please
                                                <a href="#" data-toggle="modal" data-target="#addRecovery"><strong>Click here</strong></a> to start adding recoveries to the incident.
                                            </div>
                                        </div>
                                    </div>

                                <?php else: ?>


                                    <button type="button" class="btn btn-warning btn-sm float-right" data-toggle="modal" data-target="#addRecovery"> <i class="fa fa-plus-circle mr-1"></i> Add Recovery</button>
                                    <div class="table-responsive">
                                        <table class="table table-hover table-sm">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Type</th>
                                                <th>Item</th>
                                                <th>Weight</th>
                                                <th>Quantity</th>
                                                <th>Worth</th>
                                                <th class="text-center" style="width: 130px;"><i class="icon-menu-open2"></i></th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            <?php $__currentLoopData = $item->recoveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recovery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="recovery_cont">
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($recovery->recoveryType->title ?? ""); ?></td>
                                                    <td><?php echo e($recovery->title); ?></td>
                                                    <td><?php echo e($recovery->weight); ?></td>
                                                    <td><?php echo e($recovery->quantity); ?></td>
                                                    <td><?php echo e($recovery->worth); ?></td>
                                                    <td class="text-center">

                                                        

                                                        <?php if($recovery->user_id == $cur_user->id): ?>
                                                            <a href="javascript:void(0)" class="text-danger recovery_delete" title="Delete recovery" data-recovery_id="<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($recovery->id)); ?>">
                                                                <i class="icon-trash"></i>
                                                            </a>
                                                        <?php endif; ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>


                                <?php endif; ?>

                            </fieldset>






                            <h6>
                                <span class="step-title">Incident Closure</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-2', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">


                            </fieldset>




                            <h6>
                                <span class="step-title">Impact & Implications</span>
                                <span class="d-none step-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                                <span class="d-none step-link">
                                    <?php echo e(route('ir.form.closure-step-3', [$formID])); ?>

                                </span>
                            </h6>
                            <fieldset class="pt-3">


                            </fieldset>












                            <div class="row mt-5">
                                <div class="col-sm-12 pb-2 text-right pr-4">

                                    <a href="<?php echo e(route('ir.incident.profile', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id) ])); ?>" class="btn btn-warning btn-sm">
                                        <i class="icon-arrow-left16 mr-1"></i> Incident Profile
                                    </a>


                                    <a href="<?php echo e(route('ir.form.closure-step-1', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="btn btn-info btn-sm">
                                        <i class="fa fas fa-save mr-1"></i> Save
                                    </a>


                                    <a href="<?php echo e(route('ir.form.closure-step-2', ['id' => \Illuminate\Support\Facades\Crypt::encrypt($item->id)])); ?>" class="btn btn-success btn-sm" name="save_cont">
                                        Save & Next <i class="icon-arrow-right16 ml-1"></i>
                                    </a>
                                </div>
                            </div>


                            <?php echo Form::close(); ?>



                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>


    <?php echo $__env->make('incidentreporting::incident-reporting.steps._partials.new_recovery_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts-bottom'); ?>
    <!-- Theme JS files -->

    <script>


        $(document).ready(function () {

            // $('.next-btn').trigger('click');
            $(".recovery_delete").click(function (e) {

                var conf = confirm('Are you sure you want to delete this recovery item?');

                if(conf){
                    var recovery_id = $(this).data('recovery_id');
                    $.ajax({
                        type: 'post',
                        url: '<?php echo e(route('ir.recovery-delete')); ?>',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            recovery_id: recovery_id
                        },
                        success: function (res) {
                            // console.table(res)

                        }
                    });
                    $(this).parent().parent(".recovery_cont").remove();
                }
            })

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.' . config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/incident-reporting/steps/closure_step_1.blade.php ENDPATH**/ ?>