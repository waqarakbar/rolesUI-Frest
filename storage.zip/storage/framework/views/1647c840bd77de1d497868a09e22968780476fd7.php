<?php $app_id = config('incidentreporting.app_id') ?>


<?php $__env->startPush('stylesheets'); ?>
    <style type="text/css">
        .institute_actions {
            list-style-type: none;
            padding-left: 0px;
        }

        .institute_actions li {
            margin-top: 12px;
        }

        .status-div {
            width: 101%;
            margin-left: -3px;
        }

        .status-div h5 {
            margin-bottom: 0px;
            padding: 12px;
        }

        .fg_action_link{
            border-bottom: 1px solid #ccc;
            margin-bottom: 8px;
            padding-bottom: 8px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>






            <div class="row" >
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            <h6 class="card-title"><?php echo e($title); ?></h6>
                        </div>

                        <div class="card-body" style="p-adding: 5px">

                            <h5><u><?php echo e($item->title); ?></u></h5>

                            <h6>Closure parameter configuration for <strong><em><?php echo e($item->title); ?></em></strong> department type</h6>

                            

                        </div>
                    </div>

                </div>
            </div>



        <?php if(!is_null($item->closureSteps) and $item->closureSteps->count() > 0): ?>


            <div class="row">




                <div class="col-md-10">

                    <div class="row">

                        <?php $__currentLoopData = $item->closureSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-12">

                                <div class="card">
                                    

                                    <div class="card-body">


                                        <div class="row">

                                            <div class="col-md-9">

                                                <h5><strong><?php echo e($fg->title); ?></strong> </h5>
                                                <h6><small><?php echo e($fg->description); ?></small></h6>
                                                <hr>


                                                <div class="row">

                                                    <?php if($fg->closureParameters->count() > 0): ?>

                                                        <div class="col-md-12">

                                                            <table class="table table-hover">
                                                                <thead>
                                                                <tr>
                                                                    <th style="width: 20px">#</th>
                                                                    <th>Parameter</th>
                                                                    <th style="width: 140px">Type</th>
                                                                    <th style="width: 40px">Action</th>
                                                                </tr>
                                                                </thead>

                                                                <?php $__currentLoopData = $fg->closureParameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <tbody>
                                                                    <tr>
                                                                        <td style="vertical-align: top"><?php echo e($loop->iteration); ?></td>
                                                                        <td style="vertical-align: top">
                                                                            <p>
                                                                                <strong><?php echo e($f->title); ?></strong>
                                                                                <br>
                                                                                <small><?php echo e($f->description); ?></small>
                                                                            </p>

                                                                        </td>
                                                                        <td style="vertical-align: top"><?php echo e($f->parameterType->title); ?></td>
                                                                        <td style="vertical-align: top">
                                                                            <?php echo Form::open(['method' => 'delete', 'route' => ['ir.closure-configs.delete-parameter',\Illuminate\Support\Facades\Crypt::encrypt($f->id)], 'class' => 'delete', 'style' => 'display:inline']); ?>

                                                                            <?php echo Form::button('<i class="icon-bin"></i> ', array('class'=>'btn btn-danger btn-sm t-ext-danger', 'type'=>'submit', 'style' => 'p-adding: 0px 4px;')); ?>

                                                                            <?php echo Form::close(); ?>

                                                                        </td>
                                                                    </tr>
                                                                    </tbody>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </table>
                                                        </div>


                                                    <?php else: ?>

                                                        <div class="col-md-12">
                                                            <div class="alert alert-warning">
                                                                <h6>
                                                                    <i class="fa fa-warning"></i>
                                                                    <strong>ATTENTION!</strong>
                                                                </h6>

                                                                <p>There are no parameter in this checklist yet.</p>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                </div>

                                            </div>

                                            <div class="col-md-3">
                                                <div class="well">
                                                    <p>
                                                        <strong>
                                                            <i class="fa fa-cogs"></i> Manage Checklist
                                                        </strong>
                                                    </p>
                                                    <hr style="margin: 0px 0px 10px 0px">



                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="1"
                                                           data-field_type="Text Field">
                                                            <i class="icon-font-size"></i> Add Text Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="2"
                                                           data-field_type="Number Field">
                                                            <i class="icon-list-numbered"></i> Add Number Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="3"
                                                           data-field_type="Date Field">
                                                            <i class="icon-calendar52"></i> Add Date Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="4"
                                                           data-field_type="Time Field">
                                                            <i class="icon-watch2"></i> Add Time Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="5"
                                                           data-field_type="File Upload Field">
                                                            <i class="icon-upload"></i> Add File Upload Field
                                                        </a>
                                                    </div>


                                                    <div class="fg_action_link">
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#newField"
                                                           data-field_group_id="<?php echo e($fg->id); ?>"
                                                           data-field_type_id="6"
                                                           data-field_type="Paragraph Field">
                                                            <i class="icon-list-unordered"></i> Add Paragraph Field
                                                        </a>
                                                    </div>

                                                    <div class="fg_action_link" style="border: none">

                                                        <?php echo Form::open(['method' => 'delete', 'route' => ['ir.closure-configs.delete-checklist',\Illuminate\Support\Facades\Crypt::encrypt($fg->id)], 'class' => 'delete', 'style' => 'display:inline']); ?>

                                                        <?php echo Form::button('<i class="icon-bin"></i> Delete Checklist', array('class'=>'btn btn-link text-danger', 'type'=>'submit', 'style' => 'padding: 0px;')); ?>

                                                        <?php echo Form::close(); ?>



                                                    </div>




                                                </div>
                                            </div>

                                        </div>



                                    </div>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>




                <div class="col-md-2" style="position: relative">

                    <div style="-position: fixed">
                        <a href="#" class="btn btn-primary btn-xs btn-block" data-toggle="modal" data-target="#newFg">
                            <i class="fa fa-plus"></i> Add New Checklist
                        </a>
                    </div>

                </div>




            </div>


        <?php else: ?>


            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-warning">
                        <h5><i class="fa fa-warning"></i> ATTENTION!</h5>
                        <p>Currently there are no closure checklist for this department, Please add a checklist to proceed with the configuration.
                            <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#newFg">
                                <i class="fa fa-plus"></i> Add Checklist
                            </a>
                        </p>
                    </div>
                </div>
            </div>

        <?php endif; ?>


    <?php echo $__env->make('incidentreporting::closure_configs._partials.new_checklist_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('incidentreporting::closure_configs._partials.new_parameter_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/closure_configs/show.blade.php ENDPATH**/ ?>