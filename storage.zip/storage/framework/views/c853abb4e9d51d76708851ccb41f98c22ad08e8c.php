<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/ext_plugins/printThis/printThis.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row printable">

                        <div class="col-md-12 text-center show_in_print">
                            <?php echo $__env->make('incidentreporting::reports._partials.report_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="col-12">

                            <div class="table-responsive" style="min-height: 200px">

                                <table class="table table-striped table-bordered table-sm table-condensed" >

                                    <thead>
                                    <tr>
                                        <th rowspan="2">#</th>
                                        <th rowspan="2" style="border-right: 3px solid #e2e2e2">Department Type</th>
                                        <th colspan="4" class="text-center" style="border-right: 3px solid #e2e2e2">Incident Reporting</th>
                                        <th colspan="3" class="text-center">Info Requests</th>

                                    </tr>

                                    <tr>
                                        <th>Total Initiated</th>
                                        <th>Draft</th>
                                        <th>In-progress</th>
                                        <th style="border-right: 3px solid #e2e2e2">Closed</th>

                                        <th>Total Requests</th>
                                        <th>Pending</th>
                                        <th>Complied / Responded</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php
                                        $gt_initiated = 0;
                                        $gt_draft = 0;
                                        $gt_inprogress = 0;
                                        $gt_closed = 0;

                                        $gt_num_requests = 0;
                                        $gt_pending_requests = 0;
                                        $gt_completed_requests = 0;

                                    ?>
                                    <?php $__currentLoopData = $entry_compliance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td style="border-right: 3px solid #e2e2e2">
                                                <a href="<?php echo e(route('ir.reports.department-by-type-entry-compliance', ['department_type_id' => \Illuminate\Support\Facades\Crypt::encrypt($item->department_type_id)])); ?>">
                                                    <strong><?php echo e($item->department_type ?? ""); ?></strong>
                                                </a>
                                            </td>
                                            <td><?php echo e($item->total_initiated); ?></td>
                                            <td><?php echo e($item->draft_incidents); ?></td>
                                            <td><?php echo e($item->in_progress); ?></td>
                                            <td style="border-right: 3px solid #e2e2e2"><?php echo e($item->closed); ?></td>

                                            <td><?php echo e($item->num_requests); ?></td>
                                            <td><?php echo e($item->pending_requests); ?></td>
                                            <td><?php echo e($item->completed_requests); ?></td>

                                        </tr>

                                        <?php
                                            $gt_initiated += $item->total_initiated;
                                            $gt_draft += $item->draft_incidents;
                                            $gt_inprogress += $item->in_progress;
                                            $gt_closed += $item->closed;

                                            $gt_num_requests += $item->num_requests;
                                            $gt_pending_requests += $item->pending_requests;
                                            $gt_completed_requests += $item->completed_requests;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>

                                    <tfoot>
                                    <tr>
                                        <th colspan="2" class="text-center" style="border-right: 3px solid #e2e2e2"><strong>TOTAL</strong></th>
                                        <th><?php echo e($gt_initiated); ?></th>
                                        <th><?php echo e($gt_draft); ?></th>
                                        <th><?php echo e($gt_inprogress); ?></th>
                                        <th style="border-right: 3px solid #e2e2e2"><?php echo e($gt_closed); ?></th>

                                        <th><?php echo e($gt_num_requests); ?></th>
                                        <th><?php echo e($gt_pending_requests); ?></th>
                                        <th><?php echo e($gt_completed_requests); ?></th>
                                    </tr>
                                    </tfoot>

                                </table>

                            </div>

                        </div>

                    </div>




                    <div class="row mt-2">
                        <div class="col-md-12">
                            <a href="javascript:void(0)" class="btn btn-success btn-sm" onclick="$('.printable').printThis({importCSS: true, loadCSS: '<?php echo asset('assets/css/print.css'); ?>'});">
                                <i class="icon-printer mr-1"></i> Print Report
                            </a>
                        </div>
                    </div>


                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/reports/department_type_entry_compliance.blade.php ENDPATH**/ ?>