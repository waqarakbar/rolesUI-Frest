<?php $app_id = config('incidentreporting.app_id') ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $(".select2").select2()

            $("input[name='assignment_type']").click(function(e){
                var assignment_type = $("input[name='assignment_type']:checked").val()
                if(assignment_type == "by_department"){
                    $("#by_type_cont").hide()
                    $("#department_type_id").removeAttr("required")
                    $("#department_level_id").removeAttr("required")

                    $("#by_department_cont").show()
                    $("#department_id").attr('required', 'required')
                }else{
                    $("#by_type_cont").show()
                    $("#department_type_id").attr("required", 'required')
                    $("#department_level_id").attr("required", 'required')

                    $("#by_department_cont").hide()
                    $("#department_id").removeAttr('required')
                }
            })

            <?php if($assignments->count() > 0): ?>
            setTimeout(function(){
                $("#collaps_form").trigger("click")
            }, 500)
            <?php endif; ?>
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title">Stakeholder Spectrum Assignment</h6>

                    <div class="header-elements">
                        <div class="list-icons">
                            <a class="list-icons-item" data-action="collapse" id="collaps_form"></a>
                        </div>
                    </div>

                </div>

                <div class="card-body">

                    <form action="<?php echo e(route('ir.spectrum.save-assignment')); ?>" method="post">

                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-12">


                                <div class="alert alert-info">


                                    <h6><strong>Select Assignment Type</strong></h6>

                                    <div class="form-check form-check-inline">

                                        <label for="assignment_type_by_type" class="form-check-label">
                                            <input type="radio" name="assignment_type" value="by_type" id="assignment_type_by_type" class="form-check-input" checked>
                                            Assign by Department Type
                                        </label>

                                    </div>



                                    <div class="form-check form-check-inline">

                                        <label for="assignment_type_by_department" class="form-check-label">
                                            <input type="radio" name="assignment_type" value="by_department" id="assignment_type_by_department" class="form-check-input">
                                            Assign by Department
                                        </label>

                                    </div>


                                </div>




                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('spectrum_id', 'Select Illegal Spectrum ', ['class' => 'control-label req']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('spectrum_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('spectrum_id', [null=>'Select a Illegal Spectrum']+$spectrums->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'spectrum_id', 'required' => 'required']); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row" id="by_type_cont">

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('department_type_id', 'Select Department Type ', ['class' => 'control-label req']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_type_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('department_type_id', [null=>'Select a Department Type']+$department_types->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'department_type_id', 'required' => 'required']); ?>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('department_level_id', 'Select Department Level ', ['class' => 'control-label req']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_level_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('department_level_id', [null=>'Select a Department Level']+$department_levels->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'department_level_id', 'required' => 'required']); ?>

                                </div>
                            </div>

                        </div>



                        <div class="row" id="by_department_cont" style="display: none">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('department_id', 'Select Department ', ['class' => 'control-label']); ?>


                                    <span
                                        class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_id'); ?> <?php endif; ?></span>
                                    <?php echo Form::select('department_id', [null=>'Select a Department']+$departments->toArray(), NULL, ['class' => 'form-control select2', 'id' => 'department_id']); ?>

                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <?php echo Form::label('remarks', 'Remarks ', ['class' => 'form-label ']); ?>

                                    <span
                                        class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('remarks'); ?><?php endif; ?></span>
                                    <?php echo Form::textarea('remarks', null, ['class' => 'form-control', 'id' => 'remarks', 'rows' => 4]); ?>

                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-12">

                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="icon-database-check mr-1"></i> Save Assignment
                                </button>

                            </div>
                        </div>




                    </form>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>



    <div class="row">
        <div class="col-12">

            <!-- Traffic sources -->
            <div class="card">
                <div class="card-header header-elements-inline">
                    <h6 class="card-title"><?php echo e($title); ?></h6>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="row">


                        <div class="col-12">

                            <?php if($assignments->count() <= 0): ?>

                                <div class="alert alert-warning">
                                    SORRY! There are no assignments in system yet.
                                </div>
                            <?php else: ?>

                                <div class="table-responsive">

                                    <div class="table-responsive" style="min-height: 200px">

                                        <table class="table table-striped" >

                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Spectrum</th>
                                                <th>Assignment Type</th>
                                                <th>Department Type</th>
                                                <th>Department Level</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>

                                            <tbody>
                                            <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><strong><?php echo e($assignment->spectrum->title ?? ""); ?></strong></td>
                                                    <td><span class="badge badge-info"><?php echo e(str_ireplace("_", " ", $assignment->assignment_type)); ?></span></td>

                                                    <?php if($assignment->assignment_type == "by_type"): ?>
                                                        <td><?php echo e($assignment->departmentType->title ?? ""); ?></td>
                                                        <td><?php echo e($assignment->departmentLevel->title ?? ""); ?></td>
                                                    <?php else: ?>
                                                        <td colspan="2"><?php echo e($assignment->department->title ?? ""); ?></td>
                                                    <?php endif; ?>

                                                    <td>

                                                        <?php echo Form::open(['method' => 'delete', 'route' => ['ir.spectrums.delete-assignment',\Illuminate\Support\Facades\Crypt::encrypt($assignment->id)], 'class' => 'dropdown-item delete', 'style' => 'display:inline']); ?>

                                                        <?php echo Form::button('<i class="icon-trash text-danger" style=" margin-right: 12px;color:red;"></i>', array('class'=>'btn btn-link ', 'type'=>'submit', 'style' => 'padding:0px; text-align:center')); ?>

                                                        <?php echo Form::close(); ?>


                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>

                                        </table>

                                    </div>

                                </div>
                            <?php endif; ?>


                        </div>

                    </div>

                </div>


            </div>
            <!-- /traffic sources -->

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/spectrums/spectrum_assignments.blade.php ENDPATH**/ ?>