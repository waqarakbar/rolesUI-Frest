<?php $app_id = config('incidentreporting.app_id') ?>





<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title"><?php echo e($title); ?></h5>
                    <div class="header-elements">
                        <div class="form-check form-check-right form-check-switchery form-check-switchery-sm">

                            
                        </div>
                    </div>
                </div>

                <div class="card-body">


                    <?php echo Form::model($item, [
                           'enctype' => 'multipart/form-data',
                           'method' => $item->exists ? 'put' : 'post',
                           'route' => $item->exists ? ['fm.update', \Illuminate\Support\Facades\Crypt::encrypt($item->id)] : ['fm.store']
                       ]); ?>




                    <div class="row">

                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo Form::label('department_type_id', 'Select Department Type ', ['class' => 'control-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('department_type_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('department_type_id', [null=>'Select a Department Type']+$department_types->toArray(), NULL, ['class' => 'form-control form-control-select2', 'id' => 'department_type_id', 'required' => 'required']); ?>

                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo Form::label('entity_type_id', 'Select Entity Type ', ['class' => 'control-label req']); ?>


                                <span
                                    class="help"><?php if(Session::has('errors')): ?> <?php echo Session::get('errors')->first('entity_type_id'); ?> <?php endif; ?></span>
                                <?php echo Form::select('entity_type_id', [null=>'Select a Entity Type']+$entity_types->toArray(), NULL, ['class' => 'form-control form-control-select2', 'id' => 'entity_type_id', 'required' => 'required']); ?>

                            </div>
                        </div>

                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('title', 'Form Title ', ['class' => 'form-label req']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('title'); ?><?php endif; ?></span>
                                <?php echo Form::text('title', null, ['class' => 'form-control', 'id' => 'title', 'required' => 'required']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo Form::label('description', 'Details ', ['class' => 'form-label']); ?>

                                <span
                                    class="help"><?php if(session()->has('errors')): ?> <?php echo session()->get('errors')->first('description'); ?><?php endif; ?></span>
                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-12">
                            <div class="text-left">

                                <a href="<?php echo e(route('fm.list')); ?>" class="btn btn-sm btn-warning">
                                    <i class="icon-arrow-left16 mr-1"></i> Back
                                </a>

                                <?php echo Form::button('<i class="icon-database-check mr-1"></i> Save', ['class' => 'btn btn-success btn-sm', 'id' => 'btn_submit','type' => 'submit']); ?>


                            </div>
                        </div>
                    </div>

                    <?php echo Form::close(); ?>



                </div>

            </div>

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.config('incidentreporting.active_layout'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/waqarakbar/Sites/KPISW/Modules/IncidentReporting/Resources/views/od_forms/form.blade.php ENDPATH**/ ?>